--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: celery_taskmeta; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE celery_taskmeta (
    id integer NOT NULL,
    task_id character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    result text,
    date_done timestamp with time zone NOT NULL,
    traceback text,
    hidden boolean NOT NULL,
    meta text
);


--
-- Name: celery_taskmeta_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE celery_taskmeta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: celery_taskmeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE celery_taskmeta_id_seq OWNED BY celery_taskmeta.id;


--
-- Name: celery_tasksetmeta; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE celery_tasksetmeta (
    id integer NOT NULL,
    taskset_id character varying(255) NOT NULL,
    result text NOT NULL,
    date_done timestamp with time zone NOT NULL,
    hidden boolean NOT NULL
);


--
-- Name: celery_tasksetmeta_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE celery_tasksetmeta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: celery_tasksetmeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE celery_tasksetmeta_id_seq OWNED BY celery_tasksetmeta.id;


--
-- Name: co2conversions_co2conversion; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE co2conversions_co2conversion (
    id integer NOT NULL,
    subclass_id integer NOT NULL,
    from_timestamp timestamp with time zone NOT NULL,
    to_timestamp timestamp with time zone,
    mainconsumption_id integer NOT NULL
);


--
-- Name: co2conversions_co2conversion_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE co2conversions_co2conversion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: co2conversions_co2conversion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE co2conversions_co2conversion_id_seq OWNED BY co2conversions_co2conversion.id;


--
-- Name: co2conversions_dynamicco2conversion; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE co2conversions_dynamicco2conversion (
    co2conversion_ptr_id integer NOT NULL,
    datasource_id integer NOT NULL
);


--
-- Name: co2conversions_fixedco2conversion; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE co2conversions_fixedco2conversion (
    co2conversion_ptr_id integer NOT NULL,
    value numeric(12,3) NOT NULL,
    unit character varying(100) NOT NULL
);


--
-- Name: condensing_fiveminuteaccumulateddata; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE condensing_fiveminuteaccumulateddata (
    id integer NOT NULL,
    datasource_id integer NOT NULL,
    value bigint NOT NULL,
    "timestamp" timestamp with time zone NOT NULL
);


--
-- Name: condensing_fiveminuteaccumulateddata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE condensing_fiveminuteaccumulateddata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: condensing_fiveminuteaccumulateddata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE condensing_fiveminuteaccumulateddata_id_seq OWNED BY condensing_fiveminuteaccumulateddata.id;


--
-- Name: condensing_houraccumulateddata; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE condensing_houraccumulateddata (
    id integer NOT NULL,
    datasource_id integer NOT NULL,
    value bigint NOT NULL,
    "timestamp" timestamp with time zone NOT NULL
);


--
-- Name: condensing_houraccumulateddata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE condensing_houraccumulateddata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: condensing_houraccumulateddata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE condensing_houraccumulateddata_id_seq OWNED BY condensing_houraccumulateddata.id;


--
-- Name: consumptions_consumption; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE consumptions_consumption (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    subclass_id integer NOT NULL,
    customer_id integer NOT NULL,
    name text NOT NULL,
    unit character varying(100) NOT NULL,
    volumetoenergyconversion_id integer
);


--
-- Name: consumptions_consumption_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE consumptions_consumption_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consumptions_consumption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE consumptions_consumption_id_seq OWNED BY consumptions_consumption.id;


--
-- Name: consumptions_consumptiongroup; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE consumptions_consumptiongroup (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    from_date date NOT NULL,
    to_date date,
    customer_id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    cost_compensation_id integer,
    mainconsumption_id integer NOT NULL
);


--
-- Name: consumptions_consumptiongroup_consumptions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE consumptions_consumptiongroup_consumptions (
    id integer NOT NULL,
    consumptiongroup_id integer NOT NULL,
    consumption_id integer NOT NULL
);


--
-- Name: consumptions_consumptiongroup_consumptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE consumptions_consumptiongroup_consumptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consumptions_consumptiongroup_consumptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE consumptions_consumptiongroup_consumptions_id_seq OWNED BY consumptions_consumptiongroup_consumptions.id;


--
-- Name: consumptions_consumptiongroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE consumptions_consumptiongroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consumptions_consumptiongroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE consumptions_consumptiongroup_id_seq OWNED BY consumptions_consumptiongroup.id;


--
-- Name: consumptions_mainconsumption; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE consumptions_mainconsumption (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    from_date date NOT NULL,
    to_date date,
    customer_id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    cost_compensation_id integer,
    utility_type integer NOT NULL,
    tariff_id integer
);


--
-- Name: consumptions_mainconsumption_consumptions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE consumptions_mainconsumption_consumptions (
    id integer NOT NULL,
    mainconsumption_id integer NOT NULL,
    consumption_id integer NOT NULL
);


--
-- Name: consumptions_mainconsumption_consumptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE consumptions_mainconsumption_consumptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consumptions_mainconsumption_consumptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE consumptions_mainconsumption_consumptions_id_seq OWNED BY consumptions_mainconsumption_consumptions.id;


--
-- Name: consumptions_mainconsumption_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE consumptions_mainconsumption_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consumptions_mainconsumption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE consumptions_mainconsumption_id_seq OWNED BY consumptions_mainconsumption.id;


--
-- Name: consumptions_nonpulseperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE consumptions_nonpulseperiod (
    period_ptr_id integer NOT NULL,
    datasource_id integer NOT NULL
);


--
-- Name: consumptions_offlinetolerance; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE consumptions_offlinetolerance (
    id integer NOT NULL,
    hours integer NOT NULL,
    datasequence_id integer NOT NULL,
    CONSTRAINT consumptions_offlinetolerance_hours_check CHECK ((hours >= 0))
);


--
-- Name: consumptions_offlinetolerance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE consumptions_offlinetolerance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consumptions_offlinetolerance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE consumptions_offlinetolerance_id_seq OWNED BY consumptions_offlinetolerance.id;


--
-- Name: consumptions_period; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE consumptions_period (
    id integer NOT NULL,
    subclass_id integer NOT NULL,
    from_timestamp timestamp with time zone NOT NULL,
    to_timestamp timestamp with time zone,
    datasequence_id integer NOT NULL
);


--
-- Name: consumptions_period_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE consumptions_period_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consumptions_period_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE consumptions_period_id_seq OWNED BY consumptions_period.id;


--
-- Name: consumptions_pulseperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE consumptions_pulseperiod (
    period_ptr_id integer NOT NULL,
    datasource_id integer NOT NULL,
    pulse_quantity integer NOT NULL,
    output_quantity integer NOT NULL,
    output_unit character varying(100) NOT NULL
);


--
-- Name: consumptions_singlevalueperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE consumptions_singlevalueperiod (
    period_ptr_id integer NOT NULL,
    value bigint NOT NULL,
    unit character varying(100) NOT NULL
);


--
-- Name: corsheaders_corsmodel; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE corsheaders_corsmodel (
    id integer NOT NULL,
    cors character varying(255) NOT NULL
);


--
-- Name: corsheaders_corsmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE corsheaders_corsmodel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: corsheaders_corsmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE corsheaders_corsmodel_id_seq OWNED BY corsheaders_corsmodel.id;


--
-- Name: cost_compensations_costcompensation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE cost_compensations_costcompensation (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    subclass_id integer NOT NULL,
    customer_id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: cost_compensations_costcompensation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE cost_compensations_costcompensation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_compensations_costcompensation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE cost_compensations_costcompensation_id_seq OWNED BY cost_compensations_costcompensation.id;


--
-- Name: cost_compensations_fixedcompensationperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE cost_compensations_fixedcompensationperiod (
    period_ptr_id integer NOT NULL,
    value numeric(12,3) NOT NULL,
    unit character varying(100) NOT NULL
);


--
-- Name: cost_compensations_period; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE cost_compensations_period (
    id integer NOT NULL,
    subclass_id integer NOT NULL,
    from_timestamp timestamp with time zone NOT NULL,
    to_timestamp timestamp with time zone,
    datasequence_id integer NOT NULL
);


--
-- Name: cost_compensations_period_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE cost_compensations_period_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_compensations_period_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE cost_compensations_period_id_seq OWNED BY cost_compensations_period.id;


--
-- Name: customer_datasources_customerdatasource; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE customer_datasources_customerdatasource (
    datasource_ptr_id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    customer_id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: customers_collection; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE customers_collection (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    subclass_id integer NOT NULL,
    customer_id integer NOT NULL,
    parent_id integer,
    name text NOT NULL,
    billing_meter_number character varying(20) NOT NULL,
    billing_installation_number character varying(20) NOT NULL,
    role integer NOT NULL,
    utility_type integer NOT NULL,
    gauge_lower_threshold numeric(10,2),
    gauge_upper_threshold numeric(10,2),
    gauge_min numeric(10,2),
    gauge_max numeric(10,2),
    gauge_preferred_unit character varying(50),
    gauge_colours integer,
    relay_id integer,
    hidden_on_details_page boolean NOT NULL,
    hidden_on_reports_page boolean NOT NULL,
    comment text NOT NULL,
    image character varying(100),
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    CONSTRAINT customers_collection_gauge_colours_check CHECK ((gauge_colours >= 0)),
    CONSTRAINT customers_collection_level_check CHECK ((level >= 0)),
    CONSTRAINT customers_collection_lft_check CHECK ((lft >= 0)),
    CONSTRAINT customers_collection_rght_check CHECK ((rght >= 0)),
    CONSTRAINT customers_collection_tree_id_check CHECK ((tree_id >= 0))
);


--
-- Name: customers_collection_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE customers_collection_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_collection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE customers_collection_id_seq OWNED BY customers_collection.id;


--
-- Name: customers_customer; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE customers_customer (
    encryption_data_initialization_vector text NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    id integer NOT NULL,
    provider_id integer NOT NULL,
    name text NOT NULL,
    vat text NOT NULL,
    address text NOT NULL,
    postal_code text NOT NULL,
    city text NOT NULL,
    phone text NOT NULL,
    country_code text NOT NULL,
    timezone character varying(64) NOT NULL,
    contact_name text NOT NULL,
    contact_email text NOT NULL,
    contact_phone text NOT NULL,
    electricity_instantaneous character varying(50) NOT NULL,
    electricity_consumption character varying(50) NOT NULL,
    gas_instantaneous character varying(50) NOT NULL,
    gas_consumption character varying(50) NOT NULL,
    water_instantaneous character varying(50) NOT NULL,
    water_consumption character varying(50) NOT NULL,
    heat_instantaneous character varying(50) NOT NULL,
    heat_consumption character varying(50) NOT NULL,
    temperature character varying(50) NOT NULL,
    oil_instantaneous character varying(50) NOT NULL,
    oil_consumption character varying(50) NOT NULL,
    currency_unit character varying(100) NOT NULL,
    electricity_tariff_id integer,
    gas_tariff_id integer,
    water_tariff_id integer,
    heat_tariff_id integer,
    oil_tariff_id integer,
    is_active boolean NOT NULL,
    production_a_unit text NOT NULL,
    production_b_unit text NOT NULL,
    production_c_unit text NOT NULL,
    production_d_unit text NOT NULL,
    production_e_unit text NOT NULL,
    created_by_id integer
);


--
-- Name: customers_customer_industry_types; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE customers_customer_industry_types (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    industrytype_id integer NOT NULL
);


--
-- Name: customers_customer_industry_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE customers_customer_industry_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_customer_industry_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE customers_customer_industry_types_id_seq OWNED BY customers_customer_industry_types.id;


--
-- Name: customers_location; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE customers_location (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    customer_id integer NOT NULL,
    parent_id integer,
    name text NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    CONSTRAINT customers_location_level_check CHECK ((level >= 0)),
    CONSTRAINT customers_location_lft_check CHECK ((lft >= 0)),
    CONSTRAINT customers_location_rght_check CHECK ((rght >= 0)),
    CONSTRAINT customers_location_tree_id_check CHECK ((tree_id >= 0))
);


--
-- Name: customers_location_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE customers_location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE customers_location_id_seq OWNED BY customers_location.id;


--
-- Name: customers_userprofile; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE customers_userprofile (
    id integer NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: customers_userprofile_collections; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE customers_userprofile_collections (
    id integer NOT NULL,
    userprofile_id integer NOT NULL,
    collection_id integer NOT NULL
);


--
-- Name: customers_userprofile_collections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE customers_userprofile_collections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_userprofile_collections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE customers_userprofile_collections_id_seq OWNED BY customers_userprofile_collections.id;


--
-- Name: customers_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE customers_userprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_userprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE customers_userprofile_id_seq OWNED BY customers_userprofile.id;


--
-- Name: dataneeds_dataneed; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dataneeds_dataneed (
    id integer NOT NULL,
    subclass_id integer NOT NULL,
    customer_id integer NOT NULL
);


--
-- Name: dataneeds_dataneed_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE dataneeds_dataneed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataneeds_dataneed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE dataneeds_dataneed_id_seq OWNED BY dataneeds_dataneed.id;


--
-- Name: dataneeds_energyusedataneed; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dataneeds_energyusedataneed (
    dataneed_ptr_id integer NOT NULL,
    energyuse_id integer NOT NULL
);


--
-- Name: dataneeds_mainconsumptiondataneed; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dataneeds_mainconsumptiondataneed (
    dataneed_ptr_id integer NOT NULL,
    mainconsumption_id integer NOT NULL
);


--
-- Name: dataneeds_productiongroupdataneed; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dataneeds_productiongroupdataneed (
    dataneed_ptr_id integer NOT NULL,
    productiongroup_id integer NOT NULL
);


--
-- Name: datasequence_adapters_consumptionaccumulationadapter; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE datasequence_adapters_consumptionaccumulationadapter (
    dataseries_ptr_id integer NOT NULL,
    datasequence_id integer NOT NULL
);


--
-- Name: datasequence_adapters_nonaccumulationadapter; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE datasequence_adapters_nonaccumulationadapter (
    dataseries_ptr_id integer NOT NULL,
    datasequence_id integer NOT NULL
);


--
-- Name: datasequence_adapters_productionaccumulationadapter; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE datasequence_adapters_productionaccumulationadapter (
    dataseries_ptr_id integer NOT NULL,
    datasequence_id integer NOT NULL
);


--
-- Name: datasequences_energypervolumedatasequence; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE datasequences_energypervolumedatasequence (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    subclass_id integer NOT NULL,
    customer_id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: datasequences_energypervolumedatasequence_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE datasequences_energypervolumedatasequence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datasequences_energypervolumedatasequence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE datasequences_energypervolumedatasequence_id_seq OWNED BY datasequences_energypervolumedatasequence.id;


--
-- Name: datasequences_energypervolumeperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE datasequences_energypervolumeperiod (
    id integer NOT NULL,
    from_timestamp timestamp with time zone NOT NULL,
    to_timestamp timestamp with time zone,
    datasequence_id integer NOT NULL,
    datasource_id integer NOT NULL
);


--
-- Name: datasequences_energypervolumeperiod_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE datasequences_energypervolumeperiod_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datasequences_energypervolumeperiod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE datasequences_energypervolumeperiod_id_seq OWNED BY datasequences_energypervolumeperiod.id;


--
-- Name: datasequences_nonaccumulationdatasequence; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE datasequences_nonaccumulationdatasequence (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    subclass_id integer NOT NULL,
    customer_id integer NOT NULL,
    name text NOT NULL,
    unit character varying(100) NOT NULL
);


--
-- Name: datasequences_nonaccumulationdatasequence_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE datasequences_nonaccumulationdatasequence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datasequences_nonaccumulationdatasequence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE datasequences_nonaccumulationdatasequence_id_seq OWNED BY datasequences_nonaccumulationdatasequence.id;


--
-- Name: datasequences_nonaccumulationofflinetolerance; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE datasequences_nonaccumulationofflinetolerance (
    id integer NOT NULL,
    hours integer NOT NULL,
    datasequence_id integer NOT NULL,
    CONSTRAINT datasequences_nonaccumulationofflinetolerance_hours_check CHECK ((hours >= 0))
);


--
-- Name: datasequences_nonaccumulationofflinetolerance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE datasequences_nonaccumulationofflinetolerance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datasequences_nonaccumulationofflinetolerance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE datasequences_nonaccumulationofflinetolerance_id_seq OWNED BY datasequences_nonaccumulationofflinetolerance.id;


--
-- Name: datasequences_nonaccumulationperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE datasequences_nonaccumulationperiod (
    id integer NOT NULL,
    from_timestamp timestamp with time zone NOT NULL,
    to_timestamp timestamp with time zone,
    datasequence_id integer NOT NULL,
    datasource_id integer NOT NULL
);


--
-- Name: datasequences_nonaccumulationperiod_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE datasequences_nonaccumulationperiod_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datasequences_nonaccumulationperiod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE datasequences_nonaccumulationperiod_id_seq OWNED BY datasequences_nonaccumulationperiod.id;


--
-- Name: datasources_datasource; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE datasources_datasource (
    id integer NOT NULL,
    subclass_id integer NOT NULL,
    unit character varying(100) NOT NULL,
    hardware_id character varying(120) NOT NULL
);


--
-- Name: datasources_datasource_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE datasources_datasource_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datasources_datasource_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE datasources_datasource_id_seq OWNED BY datasources_datasource.id;


--
-- Name: datasources_rawdata; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE datasources_rawdata (
    id bigint NOT NULL,
    value bigint NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    datasource_id integer NOT NULL
);


--
-- Name: datasources_rawdata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE datasources_rawdata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datasources_rawdata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE datasources_rawdata_id_seq OWNED BY datasources_rawdata.id;


--
-- Name: devices_agent; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE devices_agent (
    id integer NOT NULL,
    device_type integer NOT NULL,
    device_serial integer,
    hw_major integer,
    hw_minor integer,
    hw_revision integer,
    hw_subrevision character varying(12) NOT NULL,
    sw_major integer,
    sw_minor integer,
    sw_revision integer,
    sw_subrevision character varying(12) NOT NULL,
    customer_id integer NOT NULL,
    location_id integer,
    mac bigint NOT NULL,
    online boolean NOT NULL,
    online_since timestamp with time zone,
    add_mode boolean NOT NULL,
    no_longer_in_use boolean NOT NULL,
    CONSTRAINT devices_agent_hw_major_check CHECK ((hw_major >= 0)),
    CONSTRAINT devices_agent_hw_minor_check CHECK ((hw_minor >= 0)),
    CONSTRAINT devices_agent_hw_revision_check CHECK ((hw_revision >= 0)),
    CONSTRAINT devices_agent_sw_major_check CHECK ((sw_major >= 0)),
    CONSTRAINT devices_agent_sw_minor_check CHECK ((sw_minor >= 0)),
    CONSTRAINT devices_agent_sw_revision_check CHECK ((sw_revision >= 0))
);


--
-- Name: devices_agent_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE devices_agent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: devices_agent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE devices_agent_id_seq OWNED BY devices_agent.id;


--
-- Name: devices_agentevent; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE devices_agentevent (
    id integer NOT NULL,
    agent_id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    code smallint NOT NULL,
    message character varying(128) NOT NULL
);


--
-- Name: devices_agentevent_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE devices_agentevent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: devices_agentevent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE devices_agentevent_id_seq OWNED BY devices_agentevent.id;


--
-- Name: devices_agentstatechange; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE devices_agentstatechange (
    id integer NOT NULL,
    agent_id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    online boolean NOT NULL,
    add_mode boolean NOT NULL
);


--
-- Name: devices_agentstatechange_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE devices_agentstatechange_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: devices_agentstatechange_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE devices_agentstatechange_id_seq OWNED BY devices_agentstatechange.id;


--
-- Name: devices_meter; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE devices_meter (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    device_type integer NOT NULL,
    device_serial integer,
    hw_major integer,
    hw_minor integer,
    hw_revision integer,
    hw_subrevision character varying(12) NOT NULL,
    sw_major integer,
    sw_minor integer,
    sw_revision integer,
    sw_subrevision character varying(12) NOT NULL,
    agent_id integer NOT NULL,
    customer_id integer NOT NULL,
    manufactoring_id bigint NOT NULL,
    connection_type integer NOT NULL,
    manual_mode boolean NOT NULL,
    relay_on boolean NOT NULL,
    online boolean NOT NULL,
    online_since timestamp with time zone,
    joined boolean NOT NULL,
    location_id integer,
    relay_enabled boolean NOT NULL,
    name text NOT NULL,
    CONSTRAINT devices_meter_hw_major_check CHECK ((hw_major >= 0)),
    CONSTRAINT devices_meter_hw_minor_check CHECK ((hw_minor >= 0)),
    CONSTRAINT devices_meter_hw_revision_check CHECK ((hw_revision >= 0)),
    CONSTRAINT devices_meter_sw_major_check CHECK ((sw_major >= 0)),
    CONSTRAINT devices_meter_sw_minor_check CHECK ((sw_minor >= 0)),
    CONSTRAINT devices_meter_sw_revision_check CHECK ((sw_revision >= 0))
);


--
-- Name: devices_meter_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE devices_meter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: devices_meter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE devices_meter_id_seq OWNED BY devices_meter.id;


--
-- Name: devices_meterstatechange; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE devices_meterstatechange (
    id integer NOT NULL,
    meter_id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    manual_mode boolean NOT NULL,
    relay_on boolean NOT NULL,
    online boolean NOT NULL
);


--
-- Name: devices_meterstatechange_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE devices_meterstatechange_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: devices_meterstatechange_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE devices_meterstatechange_id_seq OWNED BY devices_meterstatechange.id;


--
-- Name: devices_physicalinput; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE devices_physicalinput (
    customerdatasource_ptr_id integer NOT NULL,
    type integer NOT NULL,
    meter_id integer NOT NULL,
    "order" integer NOT NULL,
    store_measurements boolean NOT NULL
);


--
-- Name: devices_softwareimage; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE devices_softwareimage (
    id integer NOT NULL,
    device_type integer NOT NULL,
    hw_major integer NOT NULL,
    hw_minor integer NOT NULL,
    hw_revision integer NOT NULL,
    hw_subrevision character varying(12) NOT NULL,
    sw_major integer NOT NULL,
    sw_minor integer NOT NULL,
    sw_revision integer NOT NULL,
    sw_subrevision character varying(12) NOT NULL,
    CONSTRAINT devices_softwareimage_hw_major_check CHECK ((hw_major >= 0)),
    CONSTRAINT devices_softwareimage_hw_minor_check CHECK ((hw_minor >= 0)),
    CONSTRAINT devices_softwareimage_hw_revision_check CHECK ((hw_revision >= 0)),
    CONSTRAINT devices_softwareimage_sw_major_check CHECK ((sw_major >= 0)),
    CONSTRAINT devices_softwareimage_sw_minor_check CHECK ((sw_minor >= 0)),
    CONSTRAINT devices_softwareimage_sw_revision_check CHECK ((sw_revision >= 0))
);


--
-- Name: devices_softwareimage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE devices_softwareimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: devices_softwareimage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE devices_softwareimage_id_seq OWNED BY devices_softwareimage.id;


--
-- Name: display_widgets_dashboardwidget; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE display_widgets_dashboardwidget (
    id integer NOT NULL,
    user_id integer NOT NULL,
    "column" integer NOT NULL,
    "row" integer NOT NULL,
    collection_id integer,
    index_id integer,
    widget_type integer NOT NULL
);


--
-- Name: display_widgets_dashboardwidget_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE display_widgets_dashboardwidget_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: display_widgets_dashboardwidget_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE display_widgets_dashboardwidget_id_seq OWNED BY display_widgets_dashboardwidget.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


--
-- Name: djcelery_crontabschedule; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djcelery_crontabschedule (
    id integer NOT NULL,
    minute character varying(64) NOT NULL,
    hour character varying(64) NOT NULL,
    day_of_week character varying(64) NOT NULL,
    day_of_month character varying(64) NOT NULL,
    month_of_year character varying(64) NOT NULL
);


--
-- Name: djcelery_crontabschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE djcelery_crontabschedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djcelery_crontabschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE djcelery_crontabschedule_id_seq OWNED BY djcelery_crontabschedule.id;


--
-- Name: djcelery_intervalschedule; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djcelery_intervalschedule (
    id integer NOT NULL,
    every integer NOT NULL,
    period character varying(24) NOT NULL
);


--
-- Name: djcelery_intervalschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE djcelery_intervalschedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djcelery_intervalschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE djcelery_intervalschedule_id_seq OWNED BY djcelery_intervalschedule.id;


--
-- Name: djcelery_periodictask; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djcelery_periodictask (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    task character varying(200) NOT NULL,
    interval_id integer,
    crontab_id integer,
    args text NOT NULL,
    kwargs text NOT NULL,
    queue character varying(200),
    exchange character varying(200),
    routing_key character varying(200),
    expires timestamp with time zone,
    enabled boolean NOT NULL,
    last_run_at timestamp with time zone,
    total_run_count integer NOT NULL,
    date_changed timestamp with time zone NOT NULL,
    description text NOT NULL,
    CONSTRAINT djcelery_periodictask_total_run_count_check CHECK ((total_run_count >= 0))
);


--
-- Name: djcelery_periodictask_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE djcelery_periodictask_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djcelery_periodictask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE djcelery_periodictask_id_seq OWNED BY djcelery_periodictask.id;


--
-- Name: djcelery_periodictasks; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djcelery_periodictasks (
    ident smallint NOT NULL,
    last_update timestamp with time zone NOT NULL
);


--
-- Name: djcelery_taskstate; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djcelery_taskstate (
    id integer NOT NULL,
    state character varying(64) NOT NULL,
    task_id character varying(36) NOT NULL,
    name character varying(200),
    tstamp timestamp with time zone NOT NULL,
    args text,
    kwargs text,
    eta timestamp with time zone,
    expires timestamp with time zone,
    result text,
    traceback text,
    runtime double precision,
    retries integer NOT NULL,
    worker_id integer,
    hidden boolean NOT NULL
);


--
-- Name: djcelery_taskstate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE djcelery_taskstate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djcelery_taskstate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE djcelery_taskstate_id_seq OWNED BY djcelery_taskstate.id;


--
-- Name: djcelery_workerstate; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE djcelery_workerstate (
    id integer NOT NULL,
    hostname character varying(255) NOT NULL,
    last_heartbeat timestamp with time zone
);


--
-- Name: djcelery_workerstate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE djcelery_workerstate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djcelery_workerstate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE djcelery_workerstate_id_seq OWNED BY djcelery_workerstate.id;


--
-- Name: encryption_encryptionkey; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE encryption_encryptionkey (
    id integer NOT NULL,
    key text NOT NULL,
    content_type_id integer NOT NULL,
    object_id integer NOT NULL,
    user_id integer NOT NULL,
    CONSTRAINT encryption_encryptionkey_object_id_check CHECK ((object_id >= 0))
);


--
-- Name: encryption_encryptionkey_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE encryption_encryptionkey_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: encryption_encryptionkey_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE encryption_encryptionkey_id_seq OWNED BY encryption_encryptionkey.id;


--
-- Name: energinet_co2_modelbinding; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energinet_co2_modelbinding (
    id integer NOT NULL,
    index_id integer NOT NULL
);


--
-- Name: energinet_co2_modelbinding_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energinet_co2_modelbinding_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energinet_co2_modelbinding_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energinet_co2_modelbinding_id_seq OWNED BY energinet_co2_modelbinding.id;


--
-- Name: energy_breakdown_districtheatingconsumptionarea; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_breakdown_districtheatingconsumptionarea (
    id integer NOT NULL,
    consumption integer,
    salesopportunity_id integer NOT NULL,
    energyusearea_id integer NOT NULL,
    CONSTRAINT energy_breakdown_districtheatingconsumptionar_consumption_check CHECK ((consumption >= 0))
);


--
-- Name: energy_breakdown_districtheatingconsumptionarea_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_breakdown_districtheatingconsumptionarea_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_breakdown_districtheatingconsumptionarea_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_breakdown_districtheatingconsumptionarea_id_seq OWNED BY energy_breakdown_districtheatingconsumptionarea.id;


--
-- Name: energy_breakdown_districtheatingconsumptiontotal; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_breakdown_districtheatingconsumptiontotal (
    id integer NOT NULL,
    consumption integer,
    salesopportunity_id integer NOT NULL,
    CONSTRAINT energy_breakdown_districtheatingconsumptionto_consumption_check CHECK ((consumption >= 0))
);


--
-- Name: energy_breakdown_districtheatingconsumptiontotal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_breakdown_districtheatingconsumptiontotal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_breakdown_districtheatingconsumptiontotal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_breakdown_districtheatingconsumptiontotal_id_seq OWNED BY energy_breakdown_districtheatingconsumptiontotal.id;


--
-- Name: energy_breakdown_electricityconsumptionarea; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_breakdown_electricityconsumptionarea (
    id integer NOT NULL,
    consumption integer,
    salesopportunity_id integer NOT NULL,
    energyusearea_id integer NOT NULL,
    CONSTRAINT energy_breakdown_electricityconsumptionarea_consumption_check CHECK ((consumption >= 0))
);


--
-- Name: energy_breakdown_electricityconsumptionarea_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_breakdown_electricityconsumptionarea_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_breakdown_electricityconsumptionarea_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_breakdown_electricityconsumptionarea_id_seq OWNED BY energy_breakdown_electricityconsumptionarea.id;


--
-- Name: energy_breakdown_electricityconsumptiontotal; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_breakdown_electricityconsumptiontotal (
    id integer NOT NULL,
    consumption integer,
    salesopportunity_id integer NOT NULL,
    CONSTRAINT energy_breakdown_electricityconsumptiontotal_consumption_check CHECK ((consumption >= 0))
);


--
-- Name: energy_breakdown_electricityconsumptiontotal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_breakdown_electricityconsumptiontotal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_breakdown_electricityconsumptiontotal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_breakdown_electricityconsumptiontotal_id_seq OWNED BY energy_breakdown_electricityconsumptiontotal.id;


--
-- Name: energy_breakdown_fuelconsumptionarea; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_breakdown_fuelconsumptionarea (
    id integer NOT NULL,
    consumption integer,
    salesopportunity_id integer NOT NULL,
    energyusearea_id integer NOT NULL,
    CONSTRAINT energy_breakdown_fuelconsumptionarea_consumption_check CHECK ((consumption >= 0))
);


--
-- Name: energy_breakdown_fuelconsumptionarea_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_breakdown_fuelconsumptionarea_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_breakdown_fuelconsumptionarea_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_breakdown_fuelconsumptionarea_id_seq OWNED BY energy_breakdown_fuelconsumptionarea.id;


--
-- Name: energy_breakdown_fuelconsumptiontotal; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_breakdown_fuelconsumptiontotal (
    id integer NOT NULL,
    consumption integer,
    salesopportunity_id integer NOT NULL,
    CONSTRAINT energy_breakdown_fuelconsumptiontotal_consumption_check CHECK ((consumption >= 0))
);


--
-- Name: energy_breakdown_fuelconsumptiontotal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_breakdown_fuelconsumptiontotal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_breakdown_fuelconsumptiontotal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_breakdown_fuelconsumptiontotal_id_seq OWNED BY energy_breakdown_fuelconsumptiontotal.id;


--
-- Name: energy_breakdown_proposedaction; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_breakdown_proposedaction (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    salesopportunity_id integer NOT NULL,
    energyusearea_id integer NOT NULL,
    name text NOT NULL,
    yearly_consumption_cost integer,
    saving_percent numeric(4,1),
    subsidy integer NOT NULL,
    investment integer,
    description text NOT NULL,
    CONSTRAINT energy_breakdown_proposedaction_investment_check CHECK ((investment >= 0)),
    CONSTRAINT energy_breakdown_proposedaction_subsidy_check CHECK ((subsidy >= 0)),
    CONSTRAINT energy_breakdown_proposedaction_yearly_consumption_cost_check CHECK ((yearly_consumption_cost >= 0))
);


--
-- Name: energy_breakdown_proposedaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_breakdown_proposedaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_breakdown_proposedaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_breakdown_proposedaction_id_seq OWNED BY energy_breakdown_proposedaction.id;


--
-- Name: energy_breakdown_waterconsumptionarea; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_breakdown_waterconsumptionarea (
    id integer NOT NULL,
    consumption integer,
    salesopportunity_id integer NOT NULL,
    energyusearea_id integer NOT NULL,
    CONSTRAINT energy_breakdown_waterconsumptionarea_consumption_check CHECK ((consumption >= 0))
);


--
-- Name: energy_breakdown_waterconsumptionarea_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_breakdown_waterconsumptionarea_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_breakdown_waterconsumptionarea_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_breakdown_waterconsumptionarea_id_seq OWNED BY energy_breakdown_waterconsumptionarea.id;


--
-- Name: energy_breakdown_waterconsumptiontotal; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_breakdown_waterconsumptiontotal (
    id integer NOT NULL,
    consumption integer,
    salesopportunity_id integer NOT NULL,
    CONSTRAINT energy_breakdown_waterconsumptiontotal_consumption_check CHECK ((consumption >= 0))
);


--
-- Name: energy_breakdown_waterconsumptiontotal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_breakdown_waterconsumptiontotal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_breakdown_waterconsumptiontotal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_breakdown_waterconsumptiontotal_id_seq OWNED BY energy_breakdown_waterconsumptiontotal.id;


--
-- Name: energy_use_reports_energyusearea; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_use_reports_energyusearea (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    report_id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: energy_use_reports_energyusearea_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_use_reports_energyusearea_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_use_reports_energyusearea_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_use_reports_energyusearea_id_seq OWNED BY energy_use_reports_energyusearea.id;


--
-- Name: energy_use_reports_energyusearea_measurement_points; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_use_reports_energyusearea_measurement_points (
    id integer NOT NULL,
    energyusearea_id integer NOT NULL,
    consumptionmeasurementpoint_id integer NOT NULL
);


--
-- Name: energy_use_reports_energyusearea_measurement_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_use_reports_energyusearea_measurement_points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_use_reports_energyusearea_measurement_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_use_reports_energyusearea_measurement_points_id_seq OWNED BY energy_use_reports_energyusearea_measurement_points.id;


--
-- Name: energy_use_reports_energyusereport; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_use_reports_energyusereport (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    customer_id integer NOT NULL,
    title text NOT NULL,
    currency_unit character varying(100) NOT NULL,
    utility_type integer NOT NULL
);


--
-- Name: energy_use_reports_energyusereport_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_use_reports_energyusereport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_use_reports_energyusereport_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_use_reports_energyusereport_id_seq OWNED BY energy_use_reports_energyusereport.id;


--
-- Name: energy_use_reports_energyusereport_main_measurement_points; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energy_use_reports_energyusereport_main_measurement_points (
    id integer NOT NULL,
    energyusereport_id integer NOT NULL,
    consumptionmeasurementpoint_id integer NOT NULL
);


--
-- Name: energy_use_reports_energyusereport_main_measurement_poin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energy_use_reports_energyusereport_main_measurement_poin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energy_use_reports_energyusereport_main_measurement_poin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energy_use_reports_energyusereport_main_measurement_poin_id_seq OWNED BY energy_use_reports_energyusereport_main_measurement_points.id;


--
-- Name: energyperformances_energyperformance; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energyperformances_energyperformance (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    subclass_id integer NOT NULL,
    customer_id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL
);


--
-- Name: energyperformances_energyperformance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energyperformances_energyperformance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energyperformances_energyperformance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energyperformances_energyperformance_id_seq OWNED BY energyperformances_energyperformance.id;


--
-- Name: energyperformances_productionenergyperformance; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energyperformances_productionenergyperformance (
    energyperformance_ptr_id integer NOT NULL,
    production_unit character varying(100) NOT NULL
);


--
-- Name: energyperformances_productionenergyperformance_consumptiong23ca; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energyperformances_productionenergyperformance_consumptiong23ca (
    id integer NOT NULL,
    productionenergyperformance_id integer NOT NULL,
    consumptiongroup_id integer NOT NULL
);


--
-- Name: energyperformances_productionenergyperformance_consumpti_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energyperformances_productionenergyperformance_consumpti_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energyperformances_productionenergyperformance_consumpti_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energyperformances_productionenergyperformance_consumpti_id_seq OWNED BY energyperformances_productionenergyperformance_consumptiong23ca.id;


--
-- Name: energyperformances_productionenergyperformance_productiongroups; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energyperformances_productionenergyperformance_productiongroups (
    id integer NOT NULL,
    productionenergyperformance_id integer NOT NULL,
    productiongroup_id integer NOT NULL
);


--
-- Name: energyperformances_productionenergyperformance_productio_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energyperformances_productionenergyperformance_productio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energyperformances_productionenergyperformance_productio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energyperformances_productionenergyperformance_productio_id_seq OWNED BY energyperformances_productionenergyperformance_productiongroups.id;


--
-- Name: energyperformances_timeenergyperformance; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energyperformances_timeenergyperformance (
    energyperformance_ptr_id integer NOT NULL,
    unit character varying(100) NOT NULL
);


--
-- Name: energyperformances_timeenergyperformance_consumptiongroups; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energyperformances_timeenergyperformance_consumptiongroups (
    id integer NOT NULL,
    timeenergyperformance_id integer NOT NULL,
    consumptiongroup_id integer NOT NULL
);


--
-- Name: energyperformances_timeenergyperformance_consumptiongrou_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE energyperformances_timeenergyperformance_consumptiongrou_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: energyperformances_timeenergyperformance_consumptiongrou_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE energyperformances_timeenergyperformance_consumptiongrou_id_seq OWNED BY energyperformances_timeenergyperformance_consumptiongroups.id;


--
-- Name: energyuses_energyuse; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE energyuses_energyuse (
    consumptiongroup_ptr_id integer NOT NULL,
    main_energy_use_area integer NOT NULL
);


--
-- Name: enpi_reports_enpireport; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE enpi_reports_enpireport (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    customer_id integer NOT NULL,
    title text NOT NULL,
    energy_driver_unit character varying(100) NOT NULL
);


--
-- Name: enpi_reports_enpireport_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE enpi_reports_enpireport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enpi_reports_enpireport_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE enpi_reports_enpireport_id_seq OWNED BY enpi_reports_enpireport.id;


--
-- Name: enpi_reports_enpiusearea; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE enpi_reports_enpiusearea (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    report_id integer NOT NULL,
    name text NOT NULL,
    energy_driver_id integer NOT NULL
);


--
-- Name: enpi_reports_enpiusearea_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE enpi_reports_enpiusearea_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enpi_reports_enpiusearea_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE enpi_reports_enpiusearea_id_seq OWNED BY enpi_reports_enpiusearea.id;


--
-- Name: enpi_reports_enpiusearea_measurement_points; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE enpi_reports_enpiusearea_measurement_points (
    id integer NOT NULL,
    enpiusearea_id integer NOT NULL,
    consumptionmeasurementpoint_id integer NOT NULL
);


--
-- Name: enpi_reports_enpiusearea_measurement_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE enpi_reports_enpiusearea_measurement_points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enpi_reports_enpiusearea_measurement_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE enpi_reports_enpiusearea_measurement_points_id_seq OWNED BY enpi_reports_enpiusearea_measurement_points.id;


--
-- Name: global_datasources_globaldatasource; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE global_datasources_globaldatasource (
    datasource_ptr_id integer NOT NULL,
    name character varying(120) NOT NULL,
    app_label character varying(100) NOT NULL,
    codename character varying(100) NOT NULL,
    country character varying(2) NOT NULL
);


--
-- Name: indexes_datasourceindexadapter; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE indexes_datasourceindexadapter (
    index_ptr_id integer NOT NULL,
    datasource_id integer NOT NULL
);


--
-- Name: indexes_derivedindexperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE indexes_derivedindexperiod (
    id integer NOT NULL,
    index_id integer NOT NULL,
    from_date date NOT NULL,
    other_index_id integer NOT NULL,
    coefficient numeric(10,5) NOT NULL,
    constant numeric(10,5) NOT NULL,
    roof numeric(10,5)
);


--
-- Name: indexes_derivedindexperiod_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE indexes_derivedindexperiod_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: indexes_derivedindexperiod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE indexes_derivedindexperiod_id_seq OWNED BY indexes_derivedindexperiod.id;


--
-- Name: indexes_entry; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE indexes_entry (
    id integer NOT NULL,
    index_id integer NOT NULL,
    from_timestamp timestamp with time zone NOT NULL,
    to_timestamp timestamp with time zone NOT NULL,
    value numeric(10,5) NOT NULL
);


--
-- Name: indexes_entry_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE indexes_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: indexes_entry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE indexes_entry_id_seq OWNED BY indexes_entry.id;


--
-- Name: indexes_index; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE indexes_index (
    dataseries_ptr_id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    name text NOT NULL,
    data_format integer NOT NULL,
    collection_id integer,
    timezone character varying(64) NOT NULL
);


--
-- Name: indexes_seasonindexperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE indexes_seasonindexperiod (
    id integer NOT NULL,
    index_id integer NOT NULL,
    from_date date NOT NULL,
    value_at_hour_0 numeric(10,5) NOT NULL,
    value_at_hour_1 numeric(10,5) NOT NULL,
    value_at_hour_2 numeric(10,5) NOT NULL,
    value_at_hour_3 numeric(10,5) NOT NULL,
    value_at_hour_4 numeric(10,5) NOT NULL,
    value_at_hour_5 numeric(10,5) NOT NULL,
    value_at_hour_6 numeric(10,5) NOT NULL,
    value_at_hour_7 numeric(10,5) NOT NULL,
    value_at_hour_8 numeric(10,5) NOT NULL,
    value_at_hour_9 numeric(10,5) NOT NULL,
    value_at_hour_10 numeric(10,5) NOT NULL,
    value_at_hour_11 numeric(10,5) NOT NULL,
    value_at_hour_12 numeric(10,5) NOT NULL,
    value_at_hour_13 numeric(10,5) NOT NULL,
    value_at_hour_14 numeric(10,5) NOT NULL,
    value_at_hour_15 numeric(10,5) NOT NULL,
    value_at_hour_16 numeric(10,5) NOT NULL,
    value_at_hour_17 numeric(10,5) NOT NULL,
    value_at_hour_18 numeric(10,5) NOT NULL,
    value_at_hour_19 numeric(10,5) NOT NULL,
    value_at_hour_20 numeric(10,5) NOT NULL,
    value_at_hour_21 numeric(10,5) NOT NULL,
    value_at_hour_22 numeric(10,5) NOT NULL,
    value_at_hour_23 numeric(10,5) NOT NULL
);


--
-- Name: indexes_seasonindexperiod_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE indexes_seasonindexperiod_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: indexes_seasonindexperiod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE indexes_seasonindexperiod_id_seq OWNED BY indexes_seasonindexperiod.id;


--
-- Name: indexes_spotmapping; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE indexes_spotmapping (
    id integer NOT NULL,
    index_id integer NOT NULL,
    area character varying(3) NOT NULL,
    unit character varying(100) NOT NULL,
    timezone character varying(64) NOT NULL
);


--
-- Name: indexes_spotmapping_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE indexes_spotmapping_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: indexes_spotmapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE indexes_spotmapping_id_seq OWNED BY indexes_spotmapping.id;


--
-- Name: indexes_standardmonthindex; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE indexes_standardmonthindex (
    index_ptr_id integer NOT NULL,
    january numeric(10,3) NOT NULL,
    february numeric(10,3) NOT NULL,
    march numeric(10,3) NOT NULL,
    april numeric(10,3) NOT NULL,
    may numeric(10,3) NOT NULL,
    june numeric(10,3) NOT NULL,
    july numeric(10,3) NOT NULL,
    august numeric(10,3) NOT NULL,
    september numeric(10,3) NOT NULL,
    october numeric(10,3) NOT NULL,
    november numeric(10,3) NOT NULL,
    december numeric(10,3) NOT NULL
);


--
-- Name: installation_surveys_billingmeter; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installation_surveys_billingmeter (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    salesopportunity_id integer NOT NULL,
    utility_type integer NOT NULL,
    description text NOT NULL,
    utility_provider text NOT NULL,
    installation_number text NOT NULL,
    billing_number text NOT NULL
);


--
-- Name: installation_surveys_billingmeter_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installation_surveys_billingmeter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installation_surveys_billingmeter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installation_surveys_billingmeter_id_seq OWNED BY installation_surveys_billingmeter.id;


--
-- Name: installation_surveys_billingmeterappendix; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installation_surveys_billingmeterappendix (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    billingmeter_id integer NOT NULL,
    name text NOT NULL,
    data character varying(100) NOT NULL
);


--
-- Name: installation_surveys_billingmeterappendix_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installation_surveys_billingmeterappendix_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installation_surveys_billingmeterappendix_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installation_surveys_billingmeterappendix_id_seq OWNED BY installation_surveys_billingmeterappendix.id;


--
-- Name: installation_surveys_energyusearea; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installation_surveys_energyusearea (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    salesopportunity_id integer NOT NULL,
    description text NOT NULL,
    electricity boolean NOT NULL,
    district_heating boolean NOT NULL,
    fuel boolean NOT NULL,
    water boolean NOT NULL
);


--
-- Name: installation_surveys_energyusearea_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installation_surveys_energyusearea_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installation_surveys_energyusearea_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installation_surveys_energyusearea_id_seq OWNED BY installation_surveys_energyusearea.id;


--
-- Name: installation_surveys_proposedaction; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installation_surveys_proposedaction (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    salesopportunity_id integer NOT NULL,
    energyusearea_id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL
);


--
-- Name: installation_surveys_proposedaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installation_surveys_proposedaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installation_surveys_proposedaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installation_surveys_proposedaction_id_seq OWNED BY installation_surveys_proposedaction.id;


--
-- Name: installation_surveys_workhours; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installation_surveys_workhours (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    salesopportunity_id integer NOT NULL,
    description text NOT NULL,
    period text NOT NULL
);


--
-- Name: installation_surveys_workhours_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installation_surveys_workhours_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installation_surveys_workhours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installation_surveys_workhours_id_seq OWNED BY installation_surveys_workhours.id;


--
-- Name: installations_floorplan; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_floorplan (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    customer_id integer NOT NULL,
    name text NOT NULL,
    image character varying(100) NOT NULL
);


--
-- Name: installations_floorplan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installations_floorplan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installations_floorplan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installations_floorplan_id_seq OWNED BY installations_floorplan.id;


--
-- Name: installations_gatewayinstallation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_gatewayinstallation (
    productinstallation_ptr_id integer NOT NULL,
    internet_connection integer NOT NULL
);


--
-- Name: installations_installationphoto; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_installationphoto (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    installation_id integer NOT NULL,
    name text NOT NULL,
    data character varying(100) NOT NULL
);


--
-- Name: installations_installationphoto_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installations_installationphoto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installations_installationphoto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installations_installationphoto_id_seq OWNED BY installations_installationphoto.id;


--
-- Name: installations_meterinstallation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_meterinstallation (
    productinstallation_ptr_id integer NOT NULL,
    gateway_id integer
);


--
-- Name: installations_meterinstallation_input_satisfies_dataneeds; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_meterinstallation_input_satisfies_dataneeds (
    id integer NOT NULL,
    meterinstallation_id integer NOT NULL,
    dataneed_id integer NOT NULL
);


--
-- Name: installations_meterinstallation_input_satisfies_dataneed_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installations_meterinstallation_input_satisfies_dataneed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installations_meterinstallation_input_satisfies_dataneed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installations_meterinstallation_input_satisfies_dataneed_id_seq OWNED BY installations_meterinstallation_input_satisfies_dataneeds.id;


--
-- Name: installations_productinstallation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_productinstallation (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    subclass_id integer NOT NULL,
    product_id integer,
    name text NOT NULL,
    purpose text NOT NULL,
    installation_notes text NOT NULL,
    floorplan_id integer NOT NULL,
    installation_number integer NOT NULL,
    marker_x double precision,
    marker_y double precision
);


--
-- Name: installations_productinstallation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installations_productinstallation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installations_productinstallation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installations_productinstallation_id_seq OWNED BY installations_productinstallation.id;


--
-- Name: installations_pulseemitterinstallation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_pulseemitterinstallation (
    productinstallation_ptr_id integer NOT NULL,
    pulse_quantity integer,
    output_quantity integer,
    output_unit character varying(100) NOT NULL
);


--
-- Name: installations_pulseemitterinstallation_input_satisfies_data7b36; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_pulseemitterinstallation_input_satisfies_data7b36 (
    id integer NOT NULL,
    pulseemitterinstallation_id integer NOT NULL,
    dataneed_id integer NOT NULL
);


--
-- Name: installations_pulseemitterinstallation_input_satisfies_d_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installations_pulseemitterinstallation_input_satisfies_d_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installations_pulseemitterinstallation_input_satisfies_d_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installations_pulseemitterinstallation_input_satisfies_d_id_seq OWNED BY installations_pulseemitterinstallation_input_satisfies_data7b36.id;


--
-- Name: installations_repeaterinstallation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_repeaterinstallation (
    productinstallation_ptr_id integer NOT NULL,
    gateway_id integer
);


--
-- Name: installations_tripleinputmeterinstallation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_tripleinputmeterinstallation (
    productinstallation_ptr_id integer NOT NULL,
    gateway_id integer
);


--
-- Name: installations_tripleinputmeterinstallation_input1_satisfies0539; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_tripleinputmeterinstallation_input1_satisfies0539 (
    id integer NOT NULL,
    tripleinputmeterinstallation_id integer NOT NULL,
    dataneed_id integer NOT NULL
);


--
-- Name: installations_tripleinputmeterinstallation_input1_satisf_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installations_tripleinputmeterinstallation_input1_satisf_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installations_tripleinputmeterinstallation_input1_satisf_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installations_tripleinputmeterinstallation_input1_satisf_id_seq OWNED BY installations_tripleinputmeterinstallation_input1_satisfies0539.id;


--
-- Name: installations_tripleinputmeterinstallation_input2_satisfies1aad; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_tripleinputmeterinstallation_input2_satisfies1aad (
    id integer NOT NULL,
    tripleinputmeterinstallation_id integer NOT NULL,
    dataneed_id integer NOT NULL
);


--
-- Name: installations_tripleinputmeterinstallation_input2_satisf_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installations_tripleinputmeterinstallation_input2_satisf_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installations_tripleinputmeterinstallation_input2_satisf_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installations_tripleinputmeterinstallation_input2_satisf_id_seq OWNED BY installations_tripleinputmeterinstallation_input2_satisfies1aad.id;


--
-- Name: installations_tripleinputmeterinstallation_input3_satisfies9eaa; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_tripleinputmeterinstallation_input3_satisfies9eaa (
    id integer NOT NULL,
    tripleinputmeterinstallation_id integer NOT NULL,
    dataneed_id integer NOT NULL
);


--
-- Name: installations_tripleinputmeterinstallation_input3_satisf_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE installations_tripleinputmeterinstallation_input3_satisf_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: installations_tripleinputmeterinstallation_input3_satisf_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE installations_tripleinputmeterinstallation_input3_satisf_id_seq OWNED BY installations_tripleinputmeterinstallation_input3_satisfies9eaa.id;


--
-- Name: installations_triplepulsecollectorinstallation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE installations_triplepulsecollectorinstallation (
    productinstallation_ptr_id integer NOT NULL,
    gateway_id integer,
    input1_pulseemitterinstallation_id integer,
    input2_pulseemitterinstallation_id integer,
    input3_pulseemitterinstallation_id integer
);


--
-- Name: manage_collections_collectionitem; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE manage_collections_collectionitem (
    item_ptr_id integer NOT NULL,
    collection_id integer NOT NULL
);


--
-- Name: manage_collections_floorplan; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE manage_collections_floorplan (
    id integer NOT NULL,
    collection_id integer NOT NULL,
    image character varying(100) NOT NULL
);


--
-- Name: manage_collections_floorplan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE manage_collections_floorplan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: manage_collections_floorplan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE manage_collections_floorplan_id_seq OWNED BY manage_collections_floorplan.id;


--
-- Name: manage_collections_infoitem; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE manage_collections_infoitem (
    item_ptr_id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    info text NOT NULL
);


--
-- Name: manage_collections_item; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE manage_collections_item (
    id integer NOT NULL,
    subclass_id integer NOT NULL,
    floorplan_id integer NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    z integer NOT NULL
);


--
-- Name: manage_collections_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE manage_collections_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: manage_collections_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE manage_collections_item_id_seq OWNED BY manage_collections_item.id;


--
-- Name: manual_reporting_manuallyreportedconsumption; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE manual_reporting_manuallyreportedconsumption (
    consumption_ptr_id integer NOT NULL
);


--
-- Name: manual_reporting_manuallyreportedproduction; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE manual_reporting_manuallyreportedproduction (
    production_ptr_id integer NOT NULL
);


--
-- Name: measurementpoints_chain; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_chain (
    dataseries_ptr_id integer NOT NULL
);


--
-- Name: measurementpoints_chainlink; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_chainlink (
    id integer NOT NULL,
    chain_id integer NOT NULL,
    data_series_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL
);


--
-- Name: measurementpoints_chainlink_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE measurementpoints_chainlink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: measurementpoints_chainlink_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE measurementpoints_chainlink_id_seq OWNED BY measurementpoints_chainlink.id;


--
-- Name: measurementpoints_dataseries; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_dataseries (
    id integer NOT NULL,
    subclass_id integer NOT NULL,
    customer_id integer,
    role integer NOT NULL,
    graph_id integer,
    unit character varying(100) NOT NULL,
    utility_type integer NOT NULL
);


--
-- Name: measurementpoints_dataseries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE measurementpoints_dataseries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: measurementpoints_dataseries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE measurementpoints_dataseries_id_seq OWNED BY measurementpoints_dataseries.id;


--
-- Name: measurementpoints_degreedaycorrection; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_degreedaycorrection (
    dataseries_ptr_id integer NOT NULL,
    consumption_id integer NOT NULL,
    standarddegreedays_id integer NOT NULL,
    degreedays_id integer NOT NULL
);


--
-- Name: measurementpoints_graph; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_graph (
    id integer NOT NULL,
    role integer NOT NULL,
    collection_id integer NOT NULL,
    hidden boolean NOT NULL
);


--
-- Name: measurementpoints_graph_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE measurementpoints_graph_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: measurementpoints_graph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE measurementpoints_graph_id_seq OWNED BY measurementpoints_graph.id;


--
-- Name: measurementpoints_heatingdegreedays; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_heatingdegreedays (
    dataseries_ptr_id integer NOT NULL,
    derived_from_id integer NOT NULL
);


--
-- Name: measurementpoints_indexcalculation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_indexcalculation (
    dataseries_ptr_id integer NOT NULL,
    index_id integer NOT NULL,
    consumption_id integer NOT NULL
);


--
-- Name: measurementpoints_link; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_link (
    dataseries_ptr_id integer NOT NULL,
    target_id integer NOT NULL
);


--
-- Name: measurementpoints_meantemperaturechange; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_meantemperaturechange (
    dataseries_ptr_id integer NOT NULL,
    energy_id integer NOT NULL,
    volume_id integer NOT NULL
);


--
-- Name: measurementpoints_multiplication; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_multiplication (
    dataseries_ptr_id integer NOT NULL,
    multiplier numeric(10,3) NOT NULL,
    source_data_series_id integer NOT NULL
);


--
-- Name: measurementpoints_piecewiseconstantintegral; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_piecewiseconstantintegral (
    dataseries_ptr_id integer NOT NULL,
    data_id integer NOT NULL
);


--
-- Name: measurementpoints_rateconversion; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_rateconversion (
    dataseries_ptr_id integer NOT NULL,
    consumption_id integer NOT NULL
);


--
-- Name: measurementpoints_simplelinearregression; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_simplelinearregression (
    dataseries_ptr_id integer NOT NULL,
    data_id integer NOT NULL
);


--
-- Name: measurementpoints_storeddata; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_storeddata (
    id integer NOT NULL,
    data_series_id integer NOT NULL,
    value bigint NOT NULL,
    "timestamp" timestamp with time zone NOT NULL
);


--
-- Name: measurementpoints_storeddata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE measurementpoints_storeddata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: measurementpoints_storeddata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE measurementpoints_storeddata_id_seq OWNED BY measurementpoints_storeddata.id;


--
-- Name: measurementpoints_summation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_summation (
    dataseries_ptr_id integer NOT NULL
);


--
-- Name: measurementpoints_summationterm; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_summationterm (
    id integer NOT NULL,
    sign integer NOT NULL,
    summation_id integer NOT NULL,
    data_series_id integer NOT NULL
);


--
-- Name: measurementpoints_summationterm_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE measurementpoints_summationterm_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: measurementpoints_summationterm_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE measurementpoints_summationterm_id_seq OWNED BY measurementpoints_summationterm.id;


--
-- Name: measurementpoints_utilization; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE measurementpoints_utilization (
    dataseries_ptr_id integer NOT NULL,
    consumption_id integer NOT NULL,
    needs_id integer NOT NULL
);


--
-- Name: opportunities_opportunity; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE opportunities_opportunity (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    customer_id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    completed boolean NOT NULL
);


--
-- Name: opportunities_opportunity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE opportunities_opportunity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: opportunities_opportunity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE opportunities_opportunity_id_seq OWNED BY opportunities_opportunity.id;


--
-- Name: processperiods_processperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE processperiods_processperiod (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    customer_id integer NOT NULL,
    title text NOT NULL,
    policy text NOT NULL,
    from_date date NOT NULL,
    to_date date NOT NULL
);


--
-- Name: processperiods_processperiod_accepted_opportunities; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE processperiods_processperiod_accepted_opportunities (
    id integer NOT NULL,
    processperiod_id integer NOT NULL,
    opportunity_id integer NOT NULL
);


--
-- Name: processperiods_processperiod_accepted_opportunities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE processperiods_processperiod_accepted_opportunities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: processperiods_processperiod_accepted_opportunities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE processperiods_processperiod_accepted_opportunities_id_seq OWNED BY processperiods_processperiod_accepted_opportunities.id;


--
-- Name: processperiods_processperiod_enpis; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE processperiods_processperiod_enpis (
    id integer NOT NULL,
    processperiod_id integer NOT NULL,
    energyperformance_id integer NOT NULL
);


--
-- Name: processperiods_processperiod_enpis_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE processperiods_processperiod_enpis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: processperiods_processperiod_enpis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE processperiods_processperiod_enpis_id_seq OWNED BY processperiods_processperiod_enpis.id;


--
-- Name: processperiods_processperiod_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE processperiods_processperiod_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: processperiods_processperiod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE processperiods_processperiod_id_seq OWNED BY processperiods_processperiod.id;


--
-- Name: processperiods_processperiod_rejected_opportunities; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE processperiods_processperiod_rejected_opportunities (
    id integer NOT NULL,
    processperiod_id integer NOT NULL,
    opportunity_id integer NOT NULL
);


--
-- Name: processperiods_processperiod_rejected_opportunities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE processperiods_processperiod_rejected_opportunities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: processperiods_processperiod_rejected_opportunities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE processperiods_processperiod_rejected_opportunities_id_seq OWNED BY processperiods_processperiod_rejected_opportunities.id;


--
-- Name: processperiods_processperiod_significant_energyuses; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE processperiods_processperiod_significant_energyuses (
    id integer NOT NULL,
    processperiod_id integer NOT NULL,
    energyuse_id integer NOT NULL
);


--
-- Name: processperiods_processperiod_significant_energyuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE processperiods_processperiod_significant_energyuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: processperiods_processperiod_significant_energyuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE processperiods_processperiod_significant_energyuses_id_seq OWNED BY processperiods_processperiod_significant_energyuses.id;


--
-- Name: processperiods_processperiodgoal; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE processperiods_processperiodgoal (
    id integer NOT NULL,
    energyperformance_id integer NOT NULL,
    baseline_from_date date NOT NULL,
    baseline_to_date date NOT NULL,
    reduction_percent numeric(4,1),
    processperiod_id integer NOT NULL
);


--
-- Name: processperiods_processperiodgoal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE processperiods_processperiodgoal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: processperiods_processperiodgoal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE processperiods_processperiodgoal_id_seq OWNED BY processperiods_processperiodgoal.id;


--
-- Name: productions_nonpulseperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE productions_nonpulseperiod (
    period_ptr_id integer NOT NULL,
    datasource_id integer NOT NULL
);


--
-- Name: productions_offlinetolerance; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE productions_offlinetolerance (
    id integer NOT NULL,
    hours integer NOT NULL,
    datasequence_id integer NOT NULL,
    CONSTRAINT productions_offlinetolerance_hours_check CHECK ((hours >= 0))
);


--
-- Name: productions_offlinetolerance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE productions_offlinetolerance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: productions_offlinetolerance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE productions_offlinetolerance_id_seq OWNED BY productions_offlinetolerance.id;


--
-- Name: productions_period; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE productions_period (
    id integer NOT NULL,
    subclass_id integer NOT NULL,
    from_timestamp timestamp with time zone NOT NULL,
    to_timestamp timestamp with time zone,
    datasequence_id integer NOT NULL
);


--
-- Name: productions_period_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE productions_period_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: productions_period_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE productions_period_id_seq OWNED BY productions_period.id;


--
-- Name: productions_production; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE productions_production (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    subclass_id integer NOT NULL,
    customer_id integer NOT NULL,
    name text NOT NULL,
    unit character varying(100) NOT NULL
);


--
-- Name: productions_production_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE productions_production_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: productions_production_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE productions_production_id_seq OWNED BY productions_production.id;


--
-- Name: productions_productiongroup; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE productions_productiongroup (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    customer_id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    unit character varying(100) NOT NULL
);


--
-- Name: productions_productiongroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE productions_productiongroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: productions_productiongroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE productions_productiongroup_id_seq OWNED BY productions_productiongroup.id;


--
-- Name: productions_productiongroup_productions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE productions_productiongroup_productions (
    id integer NOT NULL,
    productiongroup_id integer NOT NULL,
    production_id integer NOT NULL
);


--
-- Name: productions_productiongroup_productions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE productions_productiongroup_productions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: productions_productiongroup_productions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE productions_productiongroup_productions_id_seq OWNED BY productions_productiongroup_productions.id;


--
-- Name: productions_pulseperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE productions_pulseperiod (
    period_ptr_id integer NOT NULL,
    datasource_id integer NOT NULL,
    pulse_quantity integer NOT NULL,
    output_quantity integer NOT NULL,
    output_unit character varying(100) NOT NULL
);


--
-- Name: productions_singlevalueperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE productions_singlevalueperiod (
    period_ptr_id integer NOT NULL,
    value bigint NOT NULL,
    unit character varying(100) NOT NULL
);


--
-- Name: products_historicalproduct; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE products_historicalproduct (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    provider_id integer NOT NULL,
    supplier_id integer NOT NULL,
    category_id integer NOT NULL,
    part_number text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    price numeric(9,2),
    monthly_license numeric(9,2),
    installation_type_id integer,
    preconfigured_gateway boolean NOT NULL,
    discontinued boolean NOT NULL,
    product_id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: products_historicalproduct_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE products_historicalproduct_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_historicalproduct_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE products_historicalproduct_id_seq OWNED BY products_historicalproduct.id;


--
-- Name: products_product; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE products_product (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    provider_id integer NOT NULL,
    supplier_id integer NOT NULL,
    category_id integer NOT NULL,
    part_number text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    price numeric(9,2),
    monthly_license numeric(9,2),
    installation_type_id integer,
    preconfigured_gateway boolean NOT NULL,
    discontinued boolean NOT NULL
);


--
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE products_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE products_product_id_seq OWNED BY products_product.id;


--
-- Name: products_productcategory; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE products_productcategory (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    provider_id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: products_productcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE products_productcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_productcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE products_productcategory_id_seq OWNED BY products_productcategory.id;


--
-- Name: projects_additionalsaving; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE projects_additionalsaving (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    project_id integer NOT NULL,
    description text NOT NULL,
    before_energy numeric(19,2),
    after_energy numeric(19,2),
    before_cost numeric(19,2),
    after_cost numeric(19,2),
    before_co2 numeric(19,6),
    after_co2 numeric(19,6),
    energy_unit character varying(50) NOT NULL
);


--
-- Name: projects_additionalsaving_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE projects_additionalsaving_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_additionalsaving_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE projects_additionalsaving_id_seq OWNED BY projects_additionalsaving.id;


--
-- Name: projects_benchmarkproject; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE projects_benchmarkproject (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    name text NOT NULL,
    customer_id integer NOT NULL,
    background text NOT NULL,
    expectations text NOT NULL,
    actions text NOT NULL,
    subsidy numeric(19,2),
    result text NOT NULL,
    comments text NOT NULL,
    runtime integer NOT NULL,
    estimated_yearly_consumption_costs_before numeric(19,2),
    estimated_yearly_consumption_before numeric(19,2),
    estimated_co2_emissions_before numeric(19,2),
    expected_savings_in_yearly_total_costs numeric(19,2) NOT NULL,
    expected_savings_in_yearly_consumption_after numeric(19,2) NOT NULL,
    expected_reduction_in_yearly_co2_emissions numeric(19,2) NOT NULL,
    utility_type integer NOT NULL,
    include_measured_costs boolean NOT NULL,
    baseline_from_timestamp timestamp with time zone,
    baseline_to_timestamp timestamp with time zone,
    result_from_timestamp timestamp with time zone,
    result_to_timestamp timestamp with time zone
);


--
-- Name: projects_benchmarkproject_baseline_measurement_points; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE projects_benchmarkproject_baseline_measurement_points (
    id integer NOT NULL,
    benchmarkproject_id integer NOT NULL,
    consumptionmeasurementpoint_id integer NOT NULL
);


--
-- Name: projects_benchmarkproject_baseline_measurement_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE projects_benchmarkproject_baseline_measurement_points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_benchmarkproject_baseline_measurement_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE projects_benchmarkproject_baseline_measurement_points_id_seq OWNED BY projects_benchmarkproject_baseline_measurement_points.id;


--
-- Name: projects_benchmarkproject_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE projects_benchmarkproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_benchmarkproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE projects_benchmarkproject_id_seq OWNED BY projects_benchmarkproject.id;


--
-- Name: projects_benchmarkproject_result_measurement_points; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE projects_benchmarkproject_result_measurement_points (
    id integer NOT NULL,
    benchmarkproject_id integer NOT NULL,
    consumptionmeasurementpoint_id integer NOT NULL
);


--
-- Name: projects_benchmarkproject_result_measurement_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE projects_benchmarkproject_result_measurement_points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_benchmarkproject_result_measurement_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE projects_benchmarkproject_result_measurement_points_id_seq OWNED BY projects_benchmarkproject_result_measurement_points.id;


--
-- Name: projects_cost; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE projects_cost (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    project_id integer NOT NULL,
    description text NOT NULL,
    cost numeric(19,2) NOT NULL,
    amortization_period integer,
    interest_rate numeric(19,2),
    scrap_value numeric(19,2)
);


--
-- Name: projects_cost_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE projects_cost_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_cost_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE projects_cost_id_seq OWNED BY projects_cost.id;


--
-- Name: provider_datasources_providerdatasource; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE provider_datasources_providerdatasource (
    datasource_ptr_id integer NOT NULL,
    provider_id integer NOT NULL
);


--
-- Name: providers_provider; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE providers_provider (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    name text NOT NULL,
    address text NOT NULL,
    zipcode text NOT NULL,
    city text NOT NULL,
    cvr text NOT NULL,
    logo character varying(100)
);


--
-- Name: providers_provider_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE providers_provider_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: providers_provider_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE providers_provider_id_seq OWNED BY providers_provider.id;


--
-- Name: reports_report; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE reports_report (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    customer_id integer,
    title text NOT NULL,
    generation_time timestamp with time zone NOT NULL,
    data_format integer NOT NULL,
    data text NOT NULL,
    size integer NOT NULL,
    CONSTRAINT reports_report_data_format_check CHECK ((data_format >= 0)),
    CONSTRAINT reports_report_size_check CHECK ((size >= 0))
);


--
-- Name: reports_report_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE reports_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reports_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE reports_report_id_seq OWNED BY reports_report.id;


--
-- Name: rules_dateexception; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE rules_dateexception (
    id integer NOT NULL,
    rule_id integer NOT NULL,
    from_date date NOT NULL,
    to_date date NOT NULL
);


--
-- Name: rules_dateexception_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE rules_dateexception_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rules_dateexception_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE rules_dateexception_id_seq OWNED BY rules_dateexception.id;


--
-- Name: rules_emailaction; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE rules_emailaction (
    id integer NOT NULL,
    rule_id integer NOT NULL,
    execution_time smallint NOT NULL,
    recipient character varying(75) NOT NULL,
    message text NOT NULL,
    CONSTRAINT rules_emailaction_execution_time_check CHECK ((execution_time >= 0))
);


--
-- Name: rules_emailaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE rules_emailaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rules_emailaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE rules_emailaction_id_seq OWNED BY rules_emailaction.id;


--
-- Name: rules_indexinvariant; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE rules_indexinvariant (
    id integer NOT NULL,
    rule_id integer NOT NULL,
    operator integer NOT NULL,
    unit character varying(100) NOT NULL,
    index_id integer NOT NULL,
    value numeric(8,3) NOT NULL
);


--
-- Name: rules_indexinvariant_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE rules_indexinvariant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rules_indexinvariant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE rules_indexinvariant_id_seq OWNED BY rules_indexinvariant.id;


--
-- Name: rules_inputinvariant; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE rules_inputinvariant (
    id integer NOT NULL,
    rule_id integer NOT NULL,
    operator integer NOT NULL,
    unit character varying(100) NOT NULL,
    data_series_id integer NOT NULL,
    value bigint NOT NULL
);


--
-- Name: rules_inputinvariant_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE rules_inputinvariant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rules_inputinvariant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE rules_inputinvariant_id_seq OWNED BY rules_inputinvariant.id;


--
-- Name: rules_minimizerule; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE rules_minimizerule (
    userrule_ptr_id integer NOT NULL,
    consecutive boolean NOT NULL,
    activity_duration bigint NOT NULL,
    index_id integer NOT NULL
);


--
-- Name: rules_phoneaction; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE rules_phoneaction (
    id integer NOT NULL,
    rule_id integer NOT NULL,
    execution_time smallint NOT NULL,
    phone_number character varying(20) NOT NULL,
    message text NOT NULL,
    CONSTRAINT rules_phoneaction_execution_time_check CHECK ((execution_time >= 0))
);


--
-- Name: rules_phoneaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE rules_phoneaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rules_phoneaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE rules_phoneaction_id_seq OWNED BY rules_phoneaction.id;


--
-- Name: rules_relayaction; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE rules_relayaction (
    id integer NOT NULL,
    rule_id integer NOT NULL,
    execution_time smallint NOT NULL,
    meter_id integer NOT NULL,
    relay_action smallint NOT NULL,
    CONSTRAINT rules_relayaction_execution_time_check CHECK ((execution_time >= 0)),
    CONSTRAINT rules_relayaction_relay_action_check CHECK ((relay_action >= 0))
);


--
-- Name: rules_relayaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE rules_relayaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rules_relayaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE rules_relayaction_id_seq OWNED BY rules_relayaction.id;


--
-- Name: rules_triggeredrule; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE rules_triggeredrule (
    userrule_ptr_id integer NOT NULL
);


--
-- Name: rules_userrule; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE rules_userrule (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    customer_id integer NOT NULL,
    name text NOT NULL,
    enabled boolean NOT NULL,
    timezone character varying(64) NOT NULL,
    monday boolean NOT NULL,
    tuesday boolean NOT NULL,
    wednesday boolean NOT NULL,
    thursday boolean NOT NULL,
    friday boolean NOT NULL,
    saturday boolean NOT NULL,
    sunday boolean NOT NULL,
    from_time time without time zone NOT NULL,
    to_time time without time zone NOT NULL,
    content_type_id integer NOT NULL
);


--
-- Name: rules_userrule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE rules_userrule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rules_userrule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE rules_userrule_id_seq OWNED BY rules_userrule.id;


--
-- Name: salesopportunities_activityentry; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE salesopportunities_activityentry (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    created timestamp with time zone NOT NULL,
    salesopportunity_id integer NOT NULL,
    creator_id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    title text NOT NULL,
    comment text NOT NULL
);


--
-- Name: salesopportunities_activityentry_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE salesopportunities_activityentry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salesopportunities_activityentry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE salesopportunities_activityentry_id_seq OWNED BY salesopportunities_activityentry.id;


--
-- Name: salesopportunities_industrytype; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE salesopportunities_industrytype (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


--
-- Name: salesopportunities_industrytype_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE salesopportunities_industrytype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salesopportunities_industrytype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE salesopportunities_industrytype_id_seq OWNED BY salesopportunities_industrytype.id;


--
-- Name: salesopportunities_industrytypesavings; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE salesopportunities_industrytypesavings (
    id integer NOT NULL,
    expected numeric(4,1) NOT NULL,
    guaranteed numeric(4,1) NOT NULL,
    industry_type_id integer NOT NULL,
    energy_group integer NOT NULL
);


--
-- Name: salesopportunities_industrytypesavings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE salesopportunities_industrytypesavings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salesopportunities_industrytypesavings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE salesopportunities_industrytypesavings_id_seq OWNED BY salesopportunities_industrytypesavings.id;


--
-- Name: salesopportunities_industrytypeusedistribution; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE salesopportunities_industrytypeusedistribution (
    id integer NOT NULL,
    boiler_network_losses numeric(4,1) NOT NULL,
    heating_cooking numeric(4,1) NOT NULL,
    drying numeric(4,1) NOT NULL,
    evaporation numeric(4,1) NOT NULL,
    distillation numeric(4,1) NOT NULL,
    roasting_sintering numeric(4,1) NOT NULL,
    melting_casting numeric(4,1) NOT NULL,
    other_heating_up_to_150 numeric(4,1) NOT NULL,
    other_heating_above_150 numeric(4,1) NOT NULL,
    work_driving numeric(4,1) NOT NULL,
    lighting numeric(4,1) NOT NULL,
    pumping numeric(4,1) NOT NULL,
    refrigerators_freezers numeric(4,1) NOT NULL,
    ventilation_fans numeric(4,1) NOT NULL,
    compressed_air_process_air numeric(4,1) NOT NULL,
    partitioning numeric(4,1) NOT NULL,
    stirring numeric(4,1) NOT NULL,
    other_electric_motors numeric(4,1) NOT NULL,
    computers_electronics numeric(4,1) NOT NULL,
    other_electricity_use numeric(4,1) NOT NULL,
    space_heating numeric(4,1) NOT NULL,
    industry_type_id integer NOT NULL,
    energy_group integer NOT NULL
);


--
-- Name: salesopportunities_industrytypeusedistribution_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE salesopportunities_industrytypeusedistribution_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salesopportunities_industrytypeusedistribution_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE salesopportunities_industrytypeusedistribution_id_seq OWNED BY salesopportunities_industrytypeusedistribution.id;


--
-- Name: salesopportunities_salesopportunity; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE salesopportunities_salesopportunity (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    status integer NOT NULL,
    customer_id integer NOT NULL,
    description text NOT NULL,
    industry_type_id integer,
    solid_fuel_yearly_cost integer,
    solid_fuel_cost_kwh numeric(6,3) NOT NULL,
    liquid_fuel_yearly_cost integer,
    liquid_fuel_cost_kwh numeric(6,3) NOT NULL,
    gas_yearly_cost integer,
    gas_cost_kwh numeric(6,3) NOT NULL,
    electricity_yearly_cost integer,
    electricity_cost_kwh numeric(6,3) NOT NULL,
    district_heating_yearly_cost integer,
    district_heating_cost_kwh numeric(6,3) NOT NULL,
    water_yearly_cost integer,
    water_cost_m3 numeric(6,3) NOT NULL,
    investment_percent numeric(4,1) NOT NULL,
    investment_payback_years numeric(3,1) NOT NULL,
    sizing_officer_id integer,
    sales_officer_id integer,
    expected_closed date,
    interest_rate numeric(4,2) NOT NULL,
    scrap_value integer,
    life_in_months integer NOT NULL,
    gate_closed timestamp with time zone,
    technical_contact_name text NOT NULL,
    technical_contact_email text NOT NULL,
    technical_contact_phone text NOT NULL,
    monitors integer,
    monitors_notes text NOT NULL,
    tablets integer,
    tablets_notes text NOT NULL,
    internet_connection integer,
    meters_notes text NOT NULL,
    survey_notes text NOT NULL,
    energy_savings_currency_kwh numeric(5,2),
    contract_life_in_months integer NOT NULL,
    contract_budget integer,
    contract_interest_rate numeric(4,1) NOT NULL,
    likelihood_of_closing_sale numeric(4,1) NOT NULL,
    created_by_id integer,
    installation_notes text NOT NULL,
    CONSTRAINT salesopportunities_salesopportuni_contract_life_in_months_check CHECK ((contract_life_in_months >= 0)),
    CONSTRAINT salesopportunities_salesopportunity_life_in_months_check CHECK ((life_in_months >= 0)),
    CONSTRAINT salesopportunities_salesopportunity_monitors_check CHECK ((monitors >= 0)),
    CONSTRAINT salesopportunities_salesopportunity_tablets_check CHECK ((tablets >= 0))
);


--
-- Name: salesopportunities_salesopportunity_floorplans; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE salesopportunities_salesopportunity_floorplans (
    id integer NOT NULL,
    salesopportunity_id integer NOT NULL,
    floorplan_id integer NOT NULL
);


--
-- Name: salesopportunities_salesopportunity_floorplans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE salesopportunities_salesopportunity_floorplans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salesopportunities_salesopportunity_floorplans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE salesopportunities_salesopportunity_floorplans_id_seq OWNED BY salesopportunities_salesopportunity_floorplans.id;


--
-- Name: salesopportunities_salesopportunity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE salesopportunities_salesopportunity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salesopportunities_salesopportunity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE salesopportunities_salesopportunity_id_seq OWNED BY salesopportunities_salesopportunity.id;


--
-- Name: salesopportunities_salesopportunitysavings; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE salesopportunities_salesopportunitysavings (
    id integer NOT NULL,
    expected numeric(4,1) NOT NULL,
    guaranteed numeric(4,1) NOT NULL,
    sales_opportunity_id integer NOT NULL,
    energy_group integer NOT NULL
);


--
-- Name: salesopportunities_salesopportunitysavings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE salesopportunities_salesopportunitysavings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salesopportunities_salesopportunitysavings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE salesopportunities_salesopportunitysavings_id_seq OWNED BY salesopportunities_salesopportunitysavings.id;


--
-- Name: salesopportunities_salesopportunityusedistribution; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE salesopportunities_salesopportunityusedistribution (
    id integer NOT NULL,
    boiler_network_losses numeric(4,1) NOT NULL,
    heating_cooking numeric(4,1) NOT NULL,
    drying numeric(4,1) NOT NULL,
    evaporation numeric(4,1) NOT NULL,
    distillation numeric(4,1) NOT NULL,
    roasting_sintering numeric(4,1) NOT NULL,
    melting_casting numeric(4,1) NOT NULL,
    other_heating_up_to_150 numeric(4,1) NOT NULL,
    other_heating_above_150 numeric(4,1) NOT NULL,
    work_driving numeric(4,1) NOT NULL,
    lighting numeric(4,1) NOT NULL,
    pumping numeric(4,1) NOT NULL,
    refrigerators_freezers numeric(4,1) NOT NULL,
    ventilation_fans numeric(4,1) NOT NULL,
    compressed_air_process_air numeric(4,1) NOT NULL,
    partitioning numeric(4,1) NOT NULL,
    stirring numeric(4,1) NOT NULL,
    other_electric_motors numeric(4,1) NOT NULL,
    computers_electronics numeric(4,1) NOT NULL,
    other_electricity_use numeric(4,1) NOT NULL,
    space_heating numeric(4,1) NOT NULL,
    sales_opportunity_id integer NOT NULL,
    energy_group integer NOT NULL
);


--
-- Name: salesopportunities_salesopportunityusedistribution_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE salesopportunities_salesopportunityusedistribution_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salesopportunities_salesopportunityusedistribution_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE salesopportunities_salesopportunityusedistribution_id_seq OWNED BY salesopportunities_salesopportunityusedistribution.id;


--
-- Name: salesopportunities_surveyinstruction; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE salesopportunities_surveyinstruction (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    sales_opportunity_id integer NOT NULL,
    use integer NOT NULL,
    electricity boolean NOT NULL,
    fuel boolean NOT NULL,
    district_heating boolean NOT NULL,
    water boolean NOT NULL,
    notes text NOT NULL
);


--
-- Name: salesopportunities_surveyinstruction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE salesopportunities_surveyinstruction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salesopportunities_surveyinstruction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE salesopportunities_surveyinstruction_id_seq OWNED BY salesopportunities_surveyinstruction.id;


--
-- Name: salesopportunities_task; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE salesopportunities_task (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    sales_opportunity_id integer NOT NULL,
    date date NOT NULL,
    assigned_id integer NOT NULL,
    description text NOT NULL,
    completed boolean NOT NULL,
    completed_datetime timestamp with time zone
);


--
-- Name: salesopportunities_task_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE salesopportunities_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salesopportunities_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE salesopportunities_task_id_seq OWNED BY salesopportunities_task.id;


--
-- Name: south_migrationhistory; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE south_migrationhistory (
    id integer NOT NULL,
    app_name character varying(255) NOT NULL,
    migration character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE south_migrationhistory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE south_migrationhistory_id_seq OWNED BY south_migrationhistory.id;


--
-- Name: suppliers_supplier; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE suppliers_supplier (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    provider_id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE suppliers_supplier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE suppliers_supplier_id_seq OWNED BY suppliers_supplier.id;


--
-- Name: system_health_site_healthreport; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE system_health_site_healthreport (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    customer_id integer,
    from_date date NOT NULL,
    to_date date NOT NULL,
    data text NOT NULL
);


--
-- Name: system_health_site_healthreport_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE system_health_site_healthreport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_health_site_healthreport_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE system_health_site_healthreport_id_seq OWNED BY system_health_site_healthreport.id;


--
-- Name: tariffs_energytariff; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tariffs_energytariff (
    tariff_ptr_id integer NOT NULL
);


--
-- Name: tariffs_fixedpriceperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tariffs_fixedpriceperiod (
    period_ptr_id integer NOT NULL,
    subscription_fee numeric(12,3) NOT NULL,
    subscription_period integer NOT NULL,
    value numeric(12,3) NOT NULL,
    unit character varying(100) NOT NULL
);


--
-- Name: tariffs_period; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tariffs_period (
    id integer NOT NULL,
    subclass_id integer NOT NULL,
    from_timestamp timestamp with time zone NOT NULL,
    to_timestamp timestamp with time zone,
    datasequence_id integer NOT NULL
);


--
-- Name: tariffs_period_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE tariffs_period_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tariffs_period_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE tariffs_period_id_seq OWNED BY tariffs_period.id;


--
-- Name: tariffs_spotpriceperiod; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tariffs_spotpriceperiod (
    period_ptr_id integer NOT NULL,
    subscription_fee numeric(12,3) NOT NULL,
    subscription_period integer NOT NULL,
    spotprice_id integer NOT NULL,
    coefficient numeric(12,3) NOT NULL,
    unit_for_constant_and_ceiling character varying(100) NOT NULL,
    constant numeric(12,3) NOT NULL,
    ceiling numeric(12,3)
);


--
-- Name: tariffs_tariff; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tariffs_tariff (
    id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    subclass_id integer NOT NULL,
    customer_id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: tariffs_tariff_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE tariffs_tariff_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tariffs_tariff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE tariffs_tariff_id_seq OWNED BY tariffs_tariff.id;


--
-- Name: tariffs_volumetariff; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tariffs_volumetariff (
    tariff_ptr_id integer NOT NULL
);


--
-- Name: token_auth_tokendata; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE token_auth_tokendata (
    key character varying(40) NOT NULL,
    user_id integer NOT NULL,
    cipher bytea NOT NULL
);


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users_user (
    user_ptr_id integer NOT NULL,
    encryption_data_initialization_vector text NOT NULL,
    encryption_public_key text NOT NULL,
    encryption_private_key text NOT NULL,
    encryption_key_initialization_vector text NOT NULL,
    user_type integer,
    e_mail text NOT NULL,
    phone text NOT NULL,
    mobile text NOT NULL,
    name text NOT NULL,
    customer_id integer,
    provider_id integer
);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY celery_taskmeta ALTER COLUMN id SET DEFAULT nextval('celery_taskmeta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY celery_tasksetmeta ALTER COLUMN id SET DEFAULT nextval('celery_tasksetmeta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY co2conversions_co2conversion ALTER COLUMN id SET DEFAULT nextval('co2conversions_co2conversion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY condensing_fiveminuteaccumulateddata ALTER COLUMN id SET DEFAULT nextval('condensing_fiveminuteaccumulateddata_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY condensing_houraccumulateddata ALTER COLUMN id SET DEFAULT nextval('condensing_houraccumulateddata_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_consumption ALTER COLUMN id SET DEFAULT nextval('consumptions_consumption_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_consumptiongroup ALTER COLUMN id SET DEFAULT nextval('consumptions_consumptiongroup_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_consumptiongroup_consumptions ALTER COLUMN id SET DEFAULT nextval('consumptions_consumptiongroup_consumptions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_mainconsumption ALTER COLUMN id SET DEFAULT nextval('consumptions_mainconsumption_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_mainconsumption_consumptions ALTER COLUMN id SET DEFAULT nextval('consumptions_mainconsumption_consumptions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_offlinetolerance ALTER COLUMN id SET DEFAULT nextval('consumptions_offlinetolerance_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_period ALTER COLUMN id SET DEFAULT nextval('consumptions_period_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY corsheaders_corsmodel ALTER COLUMN id SET DEFAULT nextval('corsheaders_corsmodel_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY cost_compensations_costcompensation ALTER COLUMN id SET DEFAULT nextval('cost_compensations_costcompensation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY cost_compensations_period ALTER COLUMN id SET DEFAULT nextval('cost_compensations_period_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_collection ALTER COLUMN id SET DEFAULT nextval('customers_collection_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_customer_industry_types ALTER COLUMN id SET DEFAULT nextval('customers_customer_industry_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_location ALTER COLUMN id SET DEFAULT nextval('customers_location_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_userprofile ALTER COLUMN id SET DEFAULT nextval('customers_userprofile_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_userprofile_collections ALTER COLUMN id SET DEFAULT nextval('customers_userprofile_collections_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY dataneeds_dataneed ALTER COLUMN id SET DEFAULT nextval('dataneeds_dataneed_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_energypervolumedatasequence ALTER COLUMN id SET DEFAULT nextval('datasequences_energypervolumedatasequence_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_energypervolumeperiod ALTER COLUMN id SET DEFAULT nextval('datasequences_energypervolumeperiod_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_nonaccumulationdatasequence ALTER COLUMN id SET DEFAULT nextval('datasequences_nonaccumulationdatasequence_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_nonaccumulationofflinetolerance ALTER COLUMN id SET DEFAULT nextval('datasequences_nonaccumulationofflinetolerance_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_nonaccumulationperiod ALTER COLUMN id SET DEFAULT nextval('datasequences_nonaccumulationperiod_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasources_datasource ALTER COLUMN id SET DEFAULT nextval('datasources_datasource_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasources_rawdata ALTER COLUMN id SET DEFAULT nextval('datasources_rawdata_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_agent ALTER COLUMN id SET DEFAULT nextval('devices_agent_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_agentevent ALTER COLUMN id SET DEFAULT nextval('devices_agentevent_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_agentstatechange ALTER COLUMN id SET DEFAULT nextval('devices_agentstatechange_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_meter ALTER COLUMN id SET DEFAULT nextval('devices_meter_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_meterstatechange ALTER COLUMN id SET DEFAULT nextval('devices_meterstatechange_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_softwareimage ALTER COLUMN id SET DEFAULT nextval('devices_softwareimage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY display_widgets_dashboardwidget ALTER COLUMN id SET DEFAULT nextval('display_widgets_dashboardwidget_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_crontabschedule ALTER COLUMN id SET DEFAULT nextval('djcelery_crontabschedule_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_intervalschedule ALTER COLUMN id SET DEFAULT nextval('djcelery_intervalschedule_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_periodictask ALTER COLUMN id SET DEFAULT nextval('djcelery_periodictask_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_taskstate ALTER COLUMN id SET DEFAULT nextval('djcelery_taskstate_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_workerstate ALTER COLUMN id SET DEFAULT nextval('djcelery_workerstate_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY encryption_encryptionkey ALTER COLUMN id SET DEFAULT nextval('encryption_encryptionkey_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energinet_co2_modelbinding ALTER COLUMN id SET DEFAULT nextval('energinet_co2_modelbinding_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_districtheatingconsumptionarea ALTER COLUMN id SET DEFAULT nextval('energy_breakdown_districtheatingconsumptionarea_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_districtheatingconsumptiontotal ALTER COLUMN id SET DEFAULT nextval('energy_breakdown_districtheatingconsumptiontotal_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_electricityconsumptionarea ALTER COLUMN id SET DEFAULT nextval('energy_breakdown_electricityconsumptionarea_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_electricityconsumptiontotal ALTER COLUMN id SET DEFAULT nextval('energy_breakdown_electricityconsumptiontotal_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_fuelconsumptionarea ALTER COLUMN id SET DEFAULT nextval('energy_breakdown_fuelconsumptionarea_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_fuelconsumptiontotal ALTER COLUMN id SET DEFAULT nextval('energy_breakdown_fuelconsumptiontotal_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_proposedaction ALTER COLUMN id SET DEFAULT nextval('energy_breakdown_proposedaction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_waterconsumptionarea ALTER COLUMN id SET DEFAULT nextval('energy_breakdown_waterconsumptionarea_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_waterconsumptiontotal ALTER COLUMN id SET DEFAULT nextval('energy_breakdown_waterconsumptiontotal_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_use_reports_energyusearea ALTER COLUMN id SET DEFAULT nextval('energy_use_reports_energyusearea_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_use_reports_energyusearea_measurement_points ALTER COLUMN id SET DEFAULT nextval('energy_use_reports_energyusearea_measurement_points_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_use_reports_energyusereport ALTER COLUMN id SET DEFAULT nextval('energy_use_reports_energyusereport_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_use_reports_energyusereport_main_measurement_points ALTER COLUMN id SET DEFAULT nextval('energy_use_reports_energyusereport_main_measurement_poin_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_energyperformance ALTER COLUMN id SET DEFAULT nextval('energyperformances_energyperformance_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_productionenergyperformance_consumptiong23ca ALTER COLUMN id SET DEFAULT nextval('energyperformances_productionenergyperformance_consumpti_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_productionenergyperformance_productiongroups ALTER COLUMN id SET DEFAULT nextval('energyperformances_productionenergyperformance_productio_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_timeenergyperformance_consumptiongroups ALTER COLUMN id SET DEFAULT nextval('energyperformances_timeenergyperformance_consumptiongrou_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY enpi_reports_enpireport ALTER COLUMN id SET DEFAULT nextval('enpi_reports_enpireport_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY enpi_reports_enpiusearea ALTER COLUMN id SET DEFAULT nextval('enpi_reports_enpiusearea_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY enpi_reports_enpiusearea_measurement_points ALTER COLUMN id SET DEFAULT nextval('enpi_reports_enpiusearea_measurement_points_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_derivedindexperiod ALTER COLUMN id SET DEFAULT nextval('indexes_derivedindexperiod_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_entry ALTER COLUMN id SET DEFAULT nextval('indexes_entry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_seasonindexperiod ALTER COLUMN id SET DEFAULT nextval('indexes_seasonindexperiod_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_spotmapping ALTER COLUMN id SET DEFAULT nextval('indexes_spotmapping_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installation_surveys_billingmeter ALTER COLUMN id SET DEFAULT nextval('installation_surveys_billingmeter_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installation_surveys_billingmeterappendix ALTER COLUMN id SET DEFAULT nextval('installation_surveys_billingmeterappendix_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installation_surveys_energyusearea ALTER COLUMN id SET DEFAULT nextval('installation_surveys_energyusearea_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installation_surveys_proposedaction ALTER COLUMN id SET DEFAULT nextval('installation_surveys_proposedaction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installation_surveys_workhours ALTER COLUMN id SET DEFAULT nextval('installation_surveys_workhours_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_floorplan ALTER COLUMN id SET DEFAULT nextval('installations_floorplan_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_installationphoto ALTER COLUMN id SET DEFAULT nextval('installations_installationphoto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_meterinstallation_input_satisfies_dataneeds ALTER COLUMN id SET DEFAULT nextval('installations_meterinstallation_input_satisfies_dataneed_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_productinstallation ALTER COLUMN id SET DEFAULT nextval('installations_productinstallation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_pulseemitterinstallation_input_satisfies_data7b36 ALTER COLUMN id SET DEFAULT nextval('installations_pulseemitterinstallation_input_satisfies_d_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input1_satisfies0539 ALTER COLUMN id SET DEFAULT nextval('installations_tripleinputmeterinstallation_input1_satisf_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input2_satisfies1aad ALTER COLUMN id SET DEFAULT nextval('installations_tripleinputmeterinstallation_input2_satisf_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input3_satisfies9eaa ALTER COLUMN id SET DEFAULT nextval('installations_tripleinputmeterinstallation_input3_satisf_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY manage_collections_floorplan ALTER COLUMN id SET DEFAULT nextval('manage_collections_floorplan_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY manage_collections_item ALTER COLUMN id SET DEFAULT nextval('manage_collections_item_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_chainlink ALTER COLUMN id SET DEFAULT nextval('measurementpoints_chainlink_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_dataseries ALTER COLUMN id SET DEFAULT nextval('measurementpoints_dataseries_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_graph ALTER COLUMN id SET DEFAULT nextval('measurementpoints_graph_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_storeddata ALTER COLUMN id SET DEFAULT nextval('measurementpoints_storeddata_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_summationterm ALTER COLUMN id SET DEFAULT nextval('measurementpoints_summationterm_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY opportunities_opportunity ALTER COLUMN id SET DEFAULT nextval('opportunities_opportunity_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod ALTER COLUMN id SET DEFAULT nextval('processperiods_processperiod_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod_accepted_opportunities ALTER COLUMN id SET DEFAULT nextval('processperiods_processperiod_accepted_opportunities_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod_enpis ALTER COLUMN id SET DEFAULT nextval('processperiods_processperiod_enpis_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod_rejected_opportunities ALTER COLUMN id SET DEFAULT nextval('processperiods_processperiod_rejected_opportunities_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod_significant_energyuses ALTER COLUMN id SET DEFAULT nextval('processperiods_processperiod_significant_energyuses_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiodgoal ALTER COLUMN id SET DEFAULT nextval('processperiods_processperiodgoal_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_offlinetolerance ALTER COLUMN id SET DEFAULT nextval('productions_offlinetolerance_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_period ALTER COLUMN id SET DEFAULT nextval('productions_period_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_production ALTER COLUMN id SET DEFAULT nextval('productions_production_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_productiongroup ALTER COLUMN id SET DEFAULT nextval('productions_productiongroup_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_productiongroup_productions ALTER COLUMN id SET DEFAULT nextval('productions_productiongroup_productions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_historicalproduct ALTER COLUMN id SET DEFAULT nextval('products_historicalproduct_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_product ALTER COLUMN id SET DEFAULT nextval('products_product_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_productcategory ALTER COLUMN id SET DEFAULT nextval('products_productcategory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY projects_additionalsaving ALTER COLUMN id SET DEFAULT nextval('projects_additionalsaving_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY projects_benchmarkproject ALTER COLUMN id SET DEFAULT nextval('projects_benchmarkproject_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY projects_benchmarkproject_baseline_measurement_points ALTER COLUMN id SET DEFAULT nextval('projects_benchmarkproject_baseline_measurement_points_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY projects_benchmarkproject_result_measurement_points ALTER COLUMN id SET DEFAULT nextval('projects_benchmarkproject_result_measurement_points_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY projects_cost ALTER COLUMN id SET DEFAULT nextval('projects_cost_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY providers_provider ALTER COLUMN id SET DEFAULT nextval('providers_provider_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY reports_report ALTER COLUMN id SET DEFAULT nextval('reports_report_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_dateexception ALTER COLUMN id SET DEFAULT nextval('rules_dateexception_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_emailaction ALTER COLUMN id SET DEFAULT nextval('rules_emailaction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_indexinvariant ALTER COLUMN id SET DEFAULT nextval('rules_indexinvariant_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_inputinvariant ALTER COLUMN id SET DEFAULT nextval('rules_inputinvariant_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_phoneaction ALTER COLUMN id SET DEFAULT nextval('rules_phoneaction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_relayaction ALTER COLUMN id SET DEFAULT nextval('rules_relayaction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_userrule ALTER COLUMN id SET DEFAULT nextval('rules_userrule_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_activityentry ALTER COLUMN id SET DEFAULT nextval('salesopportunities_activityentry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_industrytype ALTER COLUMN id SET DEFAULT nextval('salesopportunities_industrytype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_industrytypesavings ALTER COLUMN id SET DEFAULT nextval('salesopportunities_industrytypesavings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_industrytypeusedistribution ALTER COLUMN id SET DEFAULT nextval('salesopportunities_industrytypeusedistribution_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunity ALTER COLUMN id SET DEFAULT nextval('salesopportunities_salesopportunity_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunity_floorplans ALTER COLUMN id SET DEFAULT nextval('salesopportunities_salesopportunity_floorplans_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunitysavings ALTER COLUMN id SET DEFAULT nextval('salesopportunities_salesopportunitysavings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunityusedistribution ALTER COLUMN id SET DEFAULT nextval('salesopportunities_salesopportunityusedistribution_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_surveyinstruction ALTER COLUMN id SET DEFAULT nextval('salesopportunities_surveyinstruction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_task ALTER COLUMN id SET DEFAULT nextval('salesopportunities_task_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY south_migrationhistory ALTER COLUMN id SET DEFAULT nextval('south_migrationhistory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY suppliers_supplier ALTER COLUMN id SET DEFAULT nextval('suppliers_supplier_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY system_health_site_healthreport ALTER COLUMN id SET DEFAULT nextval('system_health_site_healthreport_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY tariffs_period ALTER COLUMN id SET DEFAULT nextval('tariffs_period_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY tariffs_tariff ALTER COLUMN id SET DEFAULT nextval('tariffs_tariff_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add encryption key	1	add_encryptionkey
2	Can change encryption key	1	change_encryptionkey
3	Can delete encryption key	1	delete_encryptionkey
4	Can add user	2	add_user
5	Can change user	2	change_user
6	Can delete user	2	delete_user
7	Can access the sales site	2	access_sales_site
8	Can access the product list site	2	access_product_list_site
9	Can access the configuration site	2	access_configuration_site
10	Can access the system health site	2	access_system_health_site
11	Can access the provider site	2	access_provider_site
12	Can access the energy manager site	2	access_energy_manager_site
13	Can access the survey site	2	access_survey_site
14	Can access the reporting site	2	access_reporting_site
15	Can access the tariff and compensation site	2	access_tariff_and_compensation_site
16	Can access the graph site	2	access_graph_site
17	Can add customer	3	add_customer
18	Can change customer	3	change_customer
19	Can delete customer	3	delete_customer
20	Can add collection	4	add_collection
21	Can change collection	4	change_collection
22	Can delete collection	4	delete_collection
23	Can add collection constraint	5	add_collectionconstraint
24	Can change collection constraint	5	change_collectionconstraint
25	Can delete collection constraint	5	delete_collectionconstraint
26	Can add location	6	add_location
27	Can change location	6	change_location
28	Can delete location	6	delete_location
29	Can add user profile	7	add_userprofile
30	Can change user profile	7	change_userprofile
31	Can delete user profile	7	delete_userprofile
32	Can add Measurement point	4	add_measurementpoint
33	Can change Measurement point	4	change_measurementpoint
34	Can delete Measurement point	4	delete_measurementpoint
35	Can add Consumption measurement point	4	add_consumptionmeasurementpoint
36	Can change Consumption measurement point	4	change_consumptionmeasurementpoint
37	Can delete Consumption measurement point	4	delete_consumptionmeasurementpoint
38	Can add Imported measurement point	4	add_importedmeasurementpoint
39	Can change Imported measurement point	4	change_importedmeasurementpoint
40	Can delete Imported measurement point	4	delete_importedmeasurementpoint
41	Can add Summation measurement point	4	add_consumptionmeasurementpointsummation
42	Can change Summation measurement point	4	change_consumptionmeasurementpointsummation
43	Can delete Summation measurement point	4	delete_consumptionmeasurementpointsummation
44	Can add Multiplication measurement point	4	add_consumptionmultiplicationpoint
45	Can change Multiplication measurement point	4	change_consumptionmultiplicationpoint
46	Can delete Multiplication measurement point	4	delete_consumptionmultiplicationpoint
47	Can add district heating measurement point	4	add_districtheatingmeasurementpoint
48	Can change district heating measurement point	4	change_districtheatingmeasurementpoint
49	Can delete district heating measurement point	4	delete_districtheatingmeasurementpoint
50	Can add Temperature measurement point	4	add_temperaturemeasurementpoint
51	Can change Temperature measurement point	4	change_temperaturemeasurementpoint
52	Can delete Temperature measurement point	4	delete_temperaturemeasurementpoint
53	Can add Production measurement point	4	add_productionmeasurementpoint
54	Can change Production measurement point	4	change_productionmeasurementpoint
55	Can delete Production measurement point	4	delete_productionmeasurementpoint
56	Can add Current measurement point	4	add_currentmeasurementpoint
57	Can change Current measurement point	4	change_currentmeasurementpoint
58	Can delete Current measurement point	4	delete_currentmeasurementpoint
59	Can add Voltage measurement point	4	add_voltagemeasurementpoint
60	Can change Voltage measurement point	4	change_voltagemeasurementpoint
61	Can delete Voltage measurement point	4	delete_voltagemeasurementpoint
62	Can add Power measurement point	4	add_powermeasurementpoint
63	Can change Power measurement point	4	change_powermeasurementpoint
64	Can delete Power measurement point	4	delete_powermeasurementpoint
65	Can add Reactive power measurement point	4	add_reactivepowermeasurementpoint
66	Can change Reactive power measurement point	4	change_reactivepowermeasurementpoint
67	Can delete Reactive power measurement point	4	delete_reactivepowermeasurementpoint
68	Can add Reactive energy measurement point	4	add_reactiveenergymeasurementpoint
69	Can change Reactive energy measurement point	4	change_reactiveenergymeasurementpoint
70	Can delete Reactive energy measurement point	4	delete_reactiveenergymeasurementpoint
71	Can add Power factor measurement point	4	add_powerfactormeasurementpoint
72	Can change Power factor measurement point	4	change_powerfactormeasurementpoint
73	Can delete Power factor measurement point	4	delete_powerfactormeasurementpoint
74	Can add provider	22	add_provider
75	Can change provider	22	change_provider
76	Can delete provider	22	delete_provider
77	Group can be used by providers	22	provider_admin_group
78	Can add hour accumulated data	23	add_houraccumulateddata
79	Can change hour accumulated data	23	change_houraccumulateddata
80	Can delete hour accumulated data	23	delete_houraccumulateddata
81	Can add five minutes accumulated data	24	add_fiveminuteaccumulateddata
82	Can change five minutes accumulated data	24	change_fiveminuteaccumulateddata
83	Can delete five minutes accumulated data	24	delete_fiveminuteaccumulateddata
84	Can add report	25	add_report
85	Can change report	25	change_report
86	Can delete report	25	delete_report
87	Can add data source	26	add_datasource
88	Can change data source	26	change_datasource
89	Can delete data source	26	delete_datasource
90	Can add raw data	27	add_rawdata
91	Can change raw data	27	change_rawdata
92	Can delete raw data	27	delete_rawdata
93	Can add global data source	28	add_globaldatasource
94	Can change global data source	28	change_globaldatasource
95	Can delete global data source	28	delete_globaldatasource
96	Can add provider data source	29	add_providerdatasource
97	Can change provider data source	29	change_providerdatasource
98	Can delete provider data source	29	delete_providerdatasource
99	Can add customer data source	30	add_customerdatasource
100	Can change customer data source	30	change_customerdatasource
101	Can delete customer data source	30	delete_customerdatasource
102	Can add energy conversion data sequence	31	add_energypervolumedatasequence
103	Can change energy conversion data sequence	31	change_energypervolumedatasequence
104	Can delete energy conversion data sequence	31	delete_energypervolumedatasequence
105	Can add volume to energy conversion period	32	add_energypervolumeperiod
106	Can change volume to energy conversion period	32	change_energypervolumeperiod
107	Can delete volume to energy conversion period	32	delete_energypervolumeperiod
108	Can add nonaccumulation data sequence	33	add_nonaccumulationdatasequence
109	Can change nonaccumulation data sequence	33	change_nonaccumulationdatasequence
110	Can delete nonaccumulation data sequence	33	delete_nonaccumulationdatasequence
111	Can add nonaccumulation period	34	add_nonaccumulationperiod
112	Can change nonaccumulation period	34	change_nonaccumulationperiod
113	Can delete nonaccumulation period	34	delete_nonaccumulationperiod
114	Can add nonaccumulation offline tolerance	35	add_nonaccumulationofflinetolerance
115	Can change nonaccumulation offline tolerance	35	change_nonaccumulationofflinetolerance
116	Can delete nonaccumulation offline tolerance	35	delete_nonaccumulationofflinetolerance
117	Can add consumption data sequence	36	add_consumption
118	Can change consumption data sequence	36	change_consumption
119	Can delete consumption data sequence	36	delete_consumption
120	Can add main consumption	37	add_mainconsumption
121	Can change main consumption	37	change_mainconsumption
122	Can delete main consumption	37	delete_mainconsumption
123	Can add consumption group	38	add_consumptiongroup
124	Can change consumption group	38	change_consumptiongroup
125	Can delete consumption group	38	delete_consumptiongroup
126	Can add consumption period	39	add_period
127	Can change consumption period	39	change_period
128	Can delete consumption period	39	delete_period
129	Can add non-pulse consumption period	40	add_nonpulseperiod
130	Can change non-pulse consumption period	40	change_nonpulseperiod
131	Can delete non-pulse consumption period	40	delete_nonpulseperiod
132	Can add pulse consumption period	41	add_pulseperiod
133	Can change pulse consumption period	41	change_pulseperiod
134	Can delete pulse consumption period	41	delete_pulseperiod
135	Can add single value consumption period	42	add_singlevalueperiod
136	Can change single value consumption period	42	change_singlevalueperiod
137	Can delete single value consumption period	42	delete_singlevalueperiod
138	Can add offline tolerance	43	add_offlinetolerance
139	Can change offline tolerance	43	change_offlinetolerance
140	Can delete offline tolerance	43	delete_offlinetolerance
141	Can add production	44	add_production
142	Can change production	44	change_production
143	Can delete production	44	delete_production
144	Can add production group	45	add_productiongroup
145	Can change production group	45	change_productiongroup
146	Can delete production group	45	delete_productiongroup
147	Can add production period	46	add_period
148	Can change production period	46	change_period
149	Can delete production period	46	delete_period
150	Can add non-pulse production period	47	add_nonpulseperiod
151	Can change non-pulse production period	47	change_nonpulseperiod
152	Can delete non-pulse production period	47	delete_nonpulseperiod
153	Can add pulse production period	48	add_pulseperiod
154	Can change pulse production period	48	change_pulseperiod
155	Can delete pulse production period	48	delete_pulseperiod
156	Can add single value production period	49	add_singlevalueperiod
157	Can change single value production period	49	change_singlevalueperiod
158	Can delete single value production period	49	delete_singlevalueperiod
159	Can add offline tolerance	50	add_offlinetolerance
160	Can change offline tolerance	50	change_offlinetolerance
161	Can delete offline tolerance	50	delete_offlinetolerance
162	Can add tariff	51	add_tariff
163	Can change tariff	51	change_tariff
164	Can delete tariff	51	delete_tariff
165	Can add energy tariff	52	add_energytariff
166	Can change energy tariff	52	change_energytariff
167	Can delete energy tariff	52	delete_energytariff
168	Can add volume tariff	53	add_volumetariff
169	Can change volume tariff	53	change_volumetariff
170	Can delete volume tariff	53	delete_volumetariff
171	Can add tariff period	54	add_period
172	Can change tariff period	54	change_period
173	Can delete tariff period	54	delete_period
174	Can add fixed price period	55	add_fixedpriceperiod
175	Can change fixed price period	55	change_fixedpriceperiod
176	Can delete fixed price period	55	delete_fixedpriceperiod
177	Can add spot price period	56	add_spotpriceperiod
178	Can change spot price period	56	change_spotpriceperiod
179	Can delete spot price period	56	delete_spotpriceperiod
180	Can add cost compensation	57	add_costcompensation
181	Can change cost compensation	57	change_costcompensation
182	Can delete cost compensation	57	delete_costcompensation
183	Can add cost compensation period	58	add_period
184	Can change cost compensation period	58	change_period
185	Can delete cost compensation period	58	delete_period
186	Can add fixed compensation period	59	add_fixedcompensationperiod
187	Can change fixed compensation period	59	change_fixedcompensationperiod
188	Can delete fixed compensation period	59	delete_fixedcompensationperiod
189	Can add token data	60	add_tokendata
190	Can change token data	60	change_tokendata
191	Can delete token data	60	delete_tokendata
192	Can add energy performance	61	add_energyperformance
193	Can change energy performance	61	change_energyperformance
194	Can delete energy performance	61	delete_energyperformance
195	Can add production energy performance	62	add_productionenergyperformance
196	Can change production energy performance	62	change_productionenergyperformance
197	Can delete production energy performance	62	delete_productionenergyperformance
198	Can add consumption performance	63	add_timeenergyperformance
199	Can change consumption performance	63	change_timeenergyperformance
200	Can delete consumption performance	63	delete_timeenergyperformance
201	Can add CO₂ conversions	64	add_co2conversion
202	Can change CO₂ conversions	64	change_co2conversion
203	Can delete CO₂ conversions	64	delete_co2conversion
204	Can add dynamic CO₂ conversion	65	add_dynamicco2conversion
205	Can change dynamic CO₂ conversion	65	change_dynamicco2conversion
206	Can delete dynamic CO₂ conversion	65	delete_dynamicco2conversion
207	Can add fixed CO₂ conversion	66	add_fixedco2conversion
208	Can change fixed CO₂ conversion	66	change_fixedco2conversion
209	Can delete fixed CO₂ conversion	66	delete_fixedco2conversion
210	Can add agent	67	add_agent
211	Can change agent	67	change_agent
212	Can delete agent	67	delete_agent
213	Can add agent state change	68	add_agentstatechange
214	Can change agent state change	68	change_agentstatechange
215	Can delete agent state change	68	delete_agentstatechange
216	Can add agent event	69	add_agentevent
217	Can change agent event	69	change_agentevent
218	Can delete agent event	69	delete_agentevent
219	Can add meter	70	add_meter
220	Can change meter	70	change_meter
221	Can delete meter	70	delete_meter
222	Can add meter state change	71	add_meterstatechange
223	Can change meter state change	71	change_meterstatechange
224	Can delete meter state change	71	delete_meterstatechange
225	Can add physical input	72	add_physicalinput
226	Can change physical input	72	change_physicalinput
227	Can delete physical input	72	delete_physicalinput
228	Can add software image	73	add_softwareimage
229	Can change software image	73	change_softwareimage
230	Can delete software image	73	delete_softwareimage
231	Can add dashboard widget	74	add_dashboardwidget
232	Can change dashboard widget	74	change_dashboardwidget
233	Can delete dashboard widget	74	delete_dashboardwidget
234	Can add model binding	76	add_modelbinding
235	Can change model binding	76	change_modelbinding
236	Can delete model binding	76	delete_modelbinding
237	Can add energy use report	77	add_energyusereport
238	Can change energy use report	77	change_energyusereport
239	Can delete energy use report	77	delete_energyusereport
240	Can add energy use area	78	add_energyusearea
241	Can change energy use area	78	change_energyusearea
242	Can delete energy use area	78	delete_energyusearea
243	Can add enpi report	79	add_enpireport
244	Can change enpi report	79	change_enpireport
245	Can delete enpi report	79	delete_enpireport
246	Can add enpi use area	80	add_enpiusearea
247	Can change enpi use area	80	change_enpiusearea
248	Can delete enpi use area	80	delete_enpiusearea
249	Can add index	75	add_index
250	Can change index	75	change_index
251	Can delete index	75	delete_index
252	Can add entry	81	add_entry
253	Can change entry	81	change_entry
254	Can delete entry	81	delete_entry
255	Can add derived index period	82	add_derivedindexperiod
256	Can change derived index period	82	change_derivedindexperiod
257	Can delete derived index period	82	delete_derivedindexperiod
258	Can add season index period	83	add_seasonindexperiod
259	Can change season index period	83	change_seasonindexperiod
260	Can delete season index period	83	delete_seasonindexperiod
261	Can add spot mapping	84	add_spotmapping
262	Can change spot mapping	84	change_spotmapping
263	Can delete spot mapping	84	delete_spotmapping
264	Can add standard month index	85	add_standardmonthindex
265	Can change standard month index	85	change_standardmonthindex
266	Can delete standard month index	85	delete_standardmonthindex
267	Can add data source index adapter	86	add_datasourceindexadapter
268	Can change data source index adapter	86	change_datasourceindexadapter
269	Can delete data source index adapter	86	delete_datasourceindexadapter
270	Can add floorplan	87	add_floorplan
271	Can change floorplan	87	change_floorplan
272	Can delete floorplan	87	delete_floorplan
273	Can add item	88	add_item
274	Can change item	88	change_item
275	Can delete item	88	delete_item
276	Can add collection item	89	add_collectionitem
277	Can change collection item	89	change_collectionitem
278	Can delete collection item	89	delete_collectionitem
279	Can add info item	90	add_infoitem
280	Can change info item	90	change_infoitem
281	Can delete info item	90	delete_infoitem
282	Can add graph	91	add_graph
283	Can change graph	91	change_graph
284	Can delete graph	91	delete_graph
285	Can add dataseries	92	add_dataseries
286	Can change dataseries	92	change_dataseries
287	Can delete dataseries	92	delete_dataseries
288	Can add stored data	93	add_storeddata
289	Can change stored data	93	change_storeddata
290	Can delete stored data	93	delete_storeddata
291	Can add chain	94	add_chain
292	Can change chain	94	change_chain
293	Can delete chain	94	delete_chain
294	Can add chain link	95	add_chainlink
295	Can change chain link	95	change_chainlink
296	Can delete chain link	95	delete_chainlink
297	Can add index calculation	96	add_indexcalculation
298	Can change index calculation	96	change_indexcalculation
299	Can delete index calculation	96	delete_indexcalculation
300	Can add cost calculation	96	add_costcalculation
301	Can change cost calculation	96	change_costcalculation
302	Can delete cost calculation	96	delete_costcalculation
303	Can add CO₂ calculation	96	add_co2calculation
304	Can change CO₂ calculation	96	change_co2calculation
305	Can delete CO₂ calculation	96	delete_co2calculation
306	Can add heating degree days	97	add_heatingdegreedays
307	Can change heating degree days	97	change_heatingdegreedays
308	Can delete heating degree days	97	delete_heatingdegreedays
309	Can add degree day correction	98	add_degreedaycorrection
310	Can change degree day correction	98	change_degreedaycorrection
311	Can delete degree day correction	98	delete_degreedaycorrection
312	Can add piecewise constant integral	99	add_piecewiseconstantintegral
313	Can change piecewise constant integral	99	change_piecewiseconstantintegral
314	Can delete piecewise constant integral	99	delete_piecewiseconstantintegral
315	Can add link	100	add_link
316	Can change link	100	change_link
317	Can delete link	100	delete_link
318	Can add mean temperature change	101	add_meantemperaturechange
319	Can change mean temperature change	101	change_meantemperaturechange
320	Can delete mean temperature change	101	delete_meantemperaturechange
321	Can add mulitplication	102	add_multiplication
322	Can change mulitplication	102	change_multiplication
323	Can delete mulitplication	102	delete_multiplication
324	Can add rate conversion	103	add_rateconversion
325	Can change rate conversion	103	change_rateconversion
326	Can delete rate conversion	103	delete_rateconversion
327	Can add Simple linear regression	104	add_simplelinearregression
328	Can change Simple linear regression	104	change_simplelinearregression
329	Can delete Simple linear regression	104	delete_simplelinearregression
330	Can add stored data series	92	add_storeddataseries
331	Can change stored data series	92	change_storeddataseries
332	Can delete stored data series	92	delete_storeddataseries
333	Can add summation	105	add_summation
334	Can change summation	105	change_summation
335	Can delete summation	105	delete_summation
336	Can add summation term	106	add_summationterm
337	Can change summation term	106	change_summationterm
338	Can delete summation term	106	delete_summationterm
339	Can add normalization	107	add_utilization
340	Can change normalization	107	change_utilization
341	Can delete normalization	107	delete_utilization
342	Can add consumption accumulation adapter	111	add_consumptionaccumulationadapter
343	Can change consumption accumulation adapter	111	change_consumptionaccumulationadapter
344	Can delete consumption accumulation adapter	111	delete_consumptionaccumulationadapter
345	Can add production accumulation adapter	112	add_productionaccumulationadapter
346	Can change production accumulation adapter	112	change_productionaccumulationadapter
347	Can delete production accumulation adapter	112	delete_productionaccumulationadapter
348	Can add nonaccumulation adapter	113	add_nonaccumulationadapter
349	Can change nonaccumulation adapter	113	change_nonaccumulationadapter
350	Can delete nonaccumulation adapter	113	delete_nonaccumulationadapter
351	Can add benchmark project	114	add_benchmarkproject
352	Can change benchmark project	114	change_benchmarkproject
353	Can delete benchmark project	114	delete_benchmarkproject
354	Can add additional saving	115	add_additionalsaving
355	Can change additional saving	115	change_additionalsaving
356	Can delete additional saving	115	delete_additionalsaving
357	Can add cost	116	add_cost
358	Can change cost	116	change_cost
359	Can delete cost	116	delete_cost
360	Can add user rule	117	add_userrule
361	Can change user rule	117	change_userrule
362	Can delete user rule	117	delete_userrule
363	Can add date exception	118	add_dateexception
364	Can change date exception	118	change_dateexception
365	Can delete date exception	118	delete_dateexception
366	Can add relay action	119	add_relayaction
367	Can change relay action	119	change_relayaction
368	Can delete relay action	119	delete_relayaction
369	Can add email action	120	add_emailaction
370	Can change email action	120	change_emailaction
371	Can delete email action	120	delete_emailaction
372	Can add phone action	121	add_phoneaction
373	Can change phone action	121	change_phoneaction
374	Can delete phone action	121	delete_phoneaction
375	Can add minimize rule	122	add_minimizerule
376	Can change minimize rule	122	change_minimizerule
377	Can delete minimize rule	122	delete_minimizerule
378	Can add triggered rule	123	add_triggeredrule
379	Can change triggered rule	123	change_triggeredrule
380	Can delete triggered rule	123	delete_triggeredrule
381	Can add index invariant	124	add_indexinvariant
382	Can change index invariant	124	change_indexinvariant
383	Can delete index invariant	124	delete_indexinvariant
384	Can add input invariant	125	add_inputinvariant
385	Can change input invariant	125	change_inputinvariant
386	Can delete input invariant	125	delete_inputinvariant
387	Can add efficiency link	100	add_efficiencylink
388	Can change efficiency link	100	change_efficiencylink
389	Can delete efficiency link	100	delete_efficiencylink
390	Can add efficiency measurement point	4	add_efficiencymeasurementpoint
391	Can change efficiency measurement point	4	change_efficiencymeasurementpoint
392	Can delete efficiency measurement point	4	delete_efficiencymeasurementpoint
393	Can add data need	128	add_dataneed
394	Can change data need	128	change_dataneed
395	Can delete data need	128	delete_dataneed
396	Can add main consumption data need	129	add_mainconsumptiondataneed
397	Can change main consumption data need	129	change_mainconsumptiondataneed
398	Can delete main consumption data need	129	delete_mainconsumptiondataneed
399	Can add energy use data need	130	add_energyusedataneed
400	Can change energy use data need	130	change_energyusedataneed
401	Can delete energy use data need	130	delete_energyusedataneed
402	Can add production group data need	131	add_productiongroupdataneed
403	Can change production group data need	131	change_productiongroupdataneed
404	Can delete production group data need	131	delete_productiongroupdataneed
405	Can add manually reported production	132	add_manuallyreportedproduction
406	Can change manually reported production	132	change_manuallyreportedproduction
407	Can delete manually reported production	132	delete_manuallyreportedproduction
408	Can add manually reported consumption	133	add_manuallyreportedconsumption
409	Can change manually reported consumption	133	change_manuallyreportedconsumption
410	Can delete manually reported consumption	133	delete_manuallyreportedconsumption
411	Can add energy use	134	add_energyuse
412	Can change energy use	134	change_energyuse
413	Can delete energy use	134	delete_energyuse
414	Can add process period	135	add_processperiod
415	Can change process period	135	change_processperiod
416	Can delete process period	135	delete_processperiod
417	Can add process period goal	136	add_processperiodgoal
418	Can change process period goal	136	change_processperiodgoal
419	Can delete process period goal	136	delete_processperiodgoal
420	Can add opportunity	137	add_opportunity
421	Can change opportunity	137	change_opportunity
422	Can delete opportunity	137	delete_opportunity
423	Can add health report	138	add_healthreport
424	Can change health report	138	change_healthreport
425	Can delete health report	138	delete_healthreport
426	Can add floor plan	139	add_floorplan
427	Can change floor plan	139	change_floorplan
428	Can delete floor plan	139	delete_floorplan
429	Can add product installlation	140	add_productinstallation
430	Can change product installlation	140	change_productinstallation
431	Can delete product installlation	140	delete_productinstallation
432	Can add gateway installlation	141	add_gatewayinstallation
433	Can change gateway installlation	141	change_gatewayinstallation
434	Can delete gateway installlation	141	delete_gatewayinstallation
435	Can add repeater installlation	142	add_repeaterinstallation
436	Can change repeater installlation	142	change_repeaterinstallation
437	Can delete repeater installlation	142	delete_repeaterinstallation
438	Can add meter installlation	143	add_meterinstallation
439	Can change meter installlation	143	change_meterinstallation
440	Can delete meter installlation	143	delete_meterinstallation
441	Can add triple input meter installlation	144	add_tripleinputmeterinstallation
442	Can change triple input meter installlation	144	change_tripleinputmeterinstallation
443	Can delete triple input meter installlation	144	delete_tripleinputmeterinstallation
444	Can add pulse emitter installation	145	add_pulseemitterinstallation
445	Can change pulse emitter installation	145	change_pulseemitterinstallation
446	Can delete pulse emitter installation	145	delete_pulseemitterinstallation
447	Can add triple pulse collector installation	146	add_triplepulsecollectorinstallation
448	Can change triple pulse collector installation	146	change_triplepulsecollectorinstallation
449	Can delete triple pulse collector installation	146	delete_triplepulsecollectorinstallation
450	Can add installation photo	147	add_installationphoto
451	Can change installation photo	147	change_installationphoto
452	Can delete installation photo	147	delete_installationphoto
453	Can add product category	148	add_productcategory
454	Can change product category	148	change_productcategory
455	Can delete product category	148	delete_productcategory
456	Can add Product	149	add_product
457	Can change Product	149	change_product
458	Can delete Product	149	delete_product
459	Can add Historical product	150	add_historicalproduct
460	Can change Historical product	150	change_historicalproduct
461	Can delete Historical product	150	delete_historicalproduct
462	Can add supplier	151	add_supplier
463	Can change supplier	151	change_supplier
464	Can delete supplier	151	delete_supplier
465	Can add industry type	152	add_industrytype
466	Can change industry type	152	change_industrytype
467	Can delete industry type	152	delete_industrytype
468	Can add industry type use distribution	153	add_industrytypeusedistribution
469	Can change industry type use distribution	153	change_industrytypeusedistribution
470	Can delete industry type use distribution	153	delete_industrytypeusedistribution
471	Can add industry type savings	154	add_industrytypesavings
472	Can change industry type savings	154	change_industrytypesavings
473	Can delete industry type savings	154	delete_industrytypesavings
474	Can add sales opportunity	155	add_salesopportunity
475	Can change sales opportunity	155	change_salesopportunity
476	Can delete sales opportunity	155	delete_salesopportunity
477	Can be sales opportunity responsible	155	can_be_sales_opportunity_responsible
478	Can add sales opportunity use distribution	156	add_salesopportunityusedistribution
479	Can change sales opportunity use distribution	156	change_salesopportunityusedistribution
480	Can delete sales opportunity use distribution	156	delete_salesopportunityusedistribution
481	Can add sales opportunity savings	157	add_salesopportunitysavings
482	Can change sales opportunity savings	157	change_salesopportunitysavings
483	Can delete sales opportunity savings	157	delete_salesopportunitysavings
484	Can add survey instruction	158	add_surveyinstruction
485	Can change survey instruction	158	change_surveyinstruction
486	Can delete survey instruction	158	delete_surveyinstruction
487	Can add activity log entry	159	add_activityentry
488	Can change activity log entry	159	change_activityentry
489	Can delete activity log entry	159	delete_activityentry
490	Can add task	160	add_task
491	Can change task	160	change_task
492	Can delete task	160	delete_task
493	Can add work hours	161	add_workhours
494	Can change work hours	161	change_workhours
495	Can delete work hours	161	delete_workhours
496	Can add Billing meter	162	add_billingmeter
497	Can change Billing meter	162	change_billingmeter
498	Can delete Billing meter	162	delete_billingmeter
499	Can add Billing meter appendix	163	add_billingmeterappendix
500	Can change Billing meter appendix	163	change_billingmeterappendix
501	Can delete Billing meter appendix	163	delete_billingmeterappendix
502	Can add Area of energy use	164	add_energyusearea
503	Can change Area of energy use	164	change_energyusearea
504	Can delete Area of energy use	164	delete_energyusearea
505	Can add proposed action	165	add_proposedaction
506	Can change proposed action	165	change_proposedaction
507	Can delete proposed action	165	delete_proposedaction
508	Can add proposed action	166	add_proposedaction
509	Can change proposed action	166	change_proposedaction
510	Can delete proposed action	166	delete_proposedaction
511	Can add electricity consumption total	167	add_electricityconsumptiontotal
512	Can change electricity consumption total	167	change_electricityconsumptiontotal
513	Can delete electricity consumption total	167	delete_electricityconsumptiontotal
514	Can add electricity consumption area	168	add_electricityconsumptionarea
515	Can change electricity consumption area	168	change_electricityconsumptionarea
516	Can delete electricity consumption area	168	delete_electricityconsumptionarea
517	Can add fuel consumption total	169	add_fuelconsumptiontotal
518	Can change fuel consumption total	169	change_fuelconsumptiontotal
519	Can delete fuel consumption total	169	delete_fuelconsumptiontotal
520	Can add fuel consumption area	170	add_fuelconsumptionarea
521	Can change fuel consumption area	170	change_fuelconsumptionarea
522	Can delete fuel consumption area	170	delete_fuelconsumptionarea
523	Can add district heating consumption total	171	add_districtheatingconsumptiontotal
524	Can change district heating consumption total	171	change_districtheatingconsumptiontotal
525	Can delete district heating consumption total	171	delete_districtheatingconsumptiontotal
526	Can add district heating consumption area	172	add_districtheatingconsumptionarea
527	Can change district heating consumption area	172	change_districtheatingconsumptionarea
528	Can delete district heating consumption area	172	delete_districtheatingconsumptionarea
529	Can add water consumption total	173	add_waterconsumptiontotal
530	Can change water consumption total	173	change_waterconsumptiontotal
531	Can delete water consumption total	173	delete_waterconsumptiontotal
532	Can add water consumption area	174	add_waterconsumptionarea
533	Can change water consumption area	174	change_waterconsumptionarea
534	Can delete water consumption area	174	delete_waterconsumptionarea
535	Can add permission	175	add_permission
536	Can change permission	175	change_permission
537	Can delete permission	175	delete_permission
538	Can add group	176	add_group
539	Can change group	176	change_group
540	Can delete group	176	delete_group
541	Can add user	177	add_user
542	Can change user	177	change_user
543	Can delete user	177	delete_user
544	Can add content type	178	add_contenttype
545	Can change content type	178	change_contenttype
546	Can delete content type	178	delete_contenttype
547	Can add session	179	add_session
548	Can change session	179	change_session
549	Can delete session	179	delete_session
550	Can add log entry	180	add_logentry
551	Can change log entry	180	change_logentry
552	Can delete log entry	180	delete_logentry
553	Can add cors model	181	add_corsmodel
554	Can change cors model	181	change_corsmodel
555	Can delete cors model	181	delete_corsmodel
556	Can add migration history	182	add_migrationhistory
557	Can change migration history	182	change_migrationhistory
558	Can delete migration history	182	delete_migrationhistory
559	Can add task state	183	add_taskmeta
560	Can change task state	183	change_taskmeta
561	Can delete task state	183	delete_taskmeta
562	Can add saved group result	184	add_tasksetmeta
563	Can change saved group result	184	change_tasksetmeta
564	Can delete saved group result	184	delete_tasksetmeta
565	Can add interval	185	add_intervalschedule
566	Can change interval	185	change_intervalschedule
567	Can delete interval	185	delete_intervalschedule
568	Can add crontab	186	add_crontabschedule
569	Can change crontab	186	change_crontabschedule
570	Can delete crontab	186	delete_crontabschedule
571	Can add periodic tasks	187	add_periodictasks
572	Can change periodic tasks	187	change_periodictasks
573	Can delete periodic tasks	187	delete_periodictasks
574	Can add periodic task	188	add_periodictask
575	Can change periodic task	188	change_periodictask
576	Can delete periodic task	188	delete_periodictask
577	Can add worker	189	add_workerstate
578	Can change worker	189	change_workerstate
579	Can delete worker	189	delete_workerstate
580	Can add task	190	add_taskstate
581	Can change task	190	change_taskstate
582	Can delete task	190	delete_taskstate
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('auth_permission_id_seq', 582, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('auth_user_id_seq', 1, false);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: celery_taskmeta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY celery_taskmeta (id, task_id, status, result, date_done, traceback, hidden, meta) FROM stdin;
\.


--
-- Name: celery_taskmeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('celery_taskmeta_id_seq', 1, false);


--
-- Data for Name: celery_tasksetmeta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY celery_tasksetmeta (id, taskset_id, result, date_done, hidden) FROM stdin;
\.


--
-- Name: celery_tasksetmeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('celery_tasksetmeta_id_seq', 1, false);


--
-- Data for Name: co2conversions_co2conversion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY co2conversions_co2conversion (id, subclass_id, from_timestamp, to_timestamp, mainconsumption_id) FROM stdin;
\.


--
-- Name: co2conversions_co2conversion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('co2conversions_co2conversion_id_seq', 1, false);


--
-- Data for Name: co2conversions_dynamicco2conversion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY co2conversions_dynamicco2conversion (co2conversion_ptr_id, datasource_id) FROM stdin;
\.


--
-- Data for Name: co2conversions_fixedco2conversion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY co2conversions_fixedco2conversion (co2conversion_ptr_id, value, unit) FROM stdin;
\.


--
-- Data for Name: condensing_fiveminuteaccumulateddata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY condensing_fiveminuteaccumulateddata (id, datasource_id, value, "timestamp") FROM stdin;
\.


--
-- Name: condensing_fiveminuteaccumulateddata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('condensing_fiveminuteaccumulateddata_id_seq', 1, false);


--
-- Data for Name: condensing_houraccumulateddata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY condensing_houraccumulateddata (id, datasource_id, value, "timestamp") FROM stdin;
\.


--
-- Name: condensing_houraccumulateddata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('condensing_houraccumulateddata_id_seq', 1, false);


--
-- Data for Name: consumptions_consumption; Type: TABLE DATA; Schema: public; Owner: -
--

COPY consumptions_consumption (id, encryption_data_initialization_vector, subclass_id, customer_id, name, unit, volumetoenergyconversion_id) FROM stdin;
\.


--
-- Name: consumptions_consumption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('consumptions_consumption_id_seq', 1, false);


--
-- Data for Name: consumptions_consumptiongroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY consumptions_consumptiongroup (id, encryption_data_initialization_vector, from_date, to_date, customer_id, name, description, cost_compensation_id, mainconsumption_id) FROM stdin;
\.


--
-- Data for Name: consumptions_consumptiongroup_consumptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY consumptions_consumptiongroup_consumptions (id, consumptiongroup_id, consumption_id) FROM stdin;
\.


--
-- Name: consumptions_consumptiongroup_consumptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('consumptions_consumptiongroup_consumptions_id_seq', 1, false);


--
-- Name: consumptions_consumptiongroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('consumptions_consumptiongroup_id_seq', 1, false);


--
-- Data for Name: consumptions_mainconsumption; Type: TABLE DATA; Schema: public; Owner: -
--

COPY consumptions_mainconsumption (id, encryption_data_initialization_vector, from_date, to_date, customer_id, name, description, cost_compensation_id, utility_type, tariff_id) FROM stdin;
\.


--
-- Data for Name: consumptions_mainconsumption_consumptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY consumptions_mainconsumption_consumptions (id, mainconsumption_id, consumption_id) FROM stdin;
\.


--
-- Name: consumptions_mainconsumption_consumptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('consumptions_mainconsumption_consumptions_id_seq', 1, false);


--
-- Name: consumptions_mainconsumption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('consumptions_mainconsumption_id_seq', 1, false);


--
-- Data for Name: consumptions_nonpulseperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY consumptions_nonpulseperiod (period_ptr_id, datasource_id) FROM stdin;
\.


--
-- Data for Name: consumptions_offlinetolerance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY consumptions_offlinetolerance (id, hours, datasequence_id) FROM stdin;
\.


--
-- Name: consumptions_offlinetolerance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('consumptions_offlinetolerance_id_seq', 1, false);


--
-- Data for Name: consumptions_period; Type: TABLE DATA; Schema: public; Owner: -
--

COPY consumptions_period (id, subclass_id, from_timestamp, to_timestamp, datasequence_id) FROM stdin;
\.


--
-- Name: consumptions_period_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('consumptions_period_id_seq', 1, false);


--
-- Data for Name: consumptions_pulseperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY consumptions_pulseperiod (period_ptr_id, datasource_id, pulse_quantity, output_quantity, output_unit) FROM stdin;
\.


--
-- Data for Name: consumptions_singlevalueperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY consumptions_singlevalueperiod (period_ptr_id, value, unit) FROM stdin;
\.


--
-- Data for Name: corsheaders_corsmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY corsheaders_corsmodel (id, cors) FROM stdin;
\.


--
-- Name: corsheaders_corsmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('corsheaders_corsmodel_id_seq', 1, false);


--
-- Data for Name: cost_compensations_costcompensation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY cost_compensations_costcompensation (id, encryption_data_initialization_vector, subclass_id, customer_id, name) FROM stdin;
\.


--
-- Name: cost_compensations_costcompensation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('cost_compensations_costcompensation_id_seq', 1, false);


--
-- Data for Name: cost_compensations_fixedcompensationperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY cost_compensations_fixedcompensationperiod (period_ptr_id, value, unit) FROM stdin;
\.


--
-- Data for Name: cost_compensations_period; Type: TABLE DATA; Schema: public; Owner: -
--

COPY cost_compensations_period (id, subclass_id, from_timestamp, to_timestamp, datasequence_id) FROM stdin;
\.


--
-- Name: cost_compensations_period_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('cost_compensations_period_id_seq', 1, false);


--
-- Data for Name: customer_datasources_customerdatasource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY customer_datasources_customerdatasource (datasource_ptr_id, encryption_data_initialization_vector, customer_id, name) FROM stdin;
\.


--
-- Data for Name: customers_collection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY customers_collection (id, encryption_data_initialization_vector, subclass_id, customer_id, parent_id, name, billing_meter_number, billing_installation_number, role, utility_type, gauge_lower_threshold, gauge_upper_threshold, gauge_min, gauge_max, gauge_preferred_unit, gauge_colours, relay_id, hidden_on_details_page, hidden_on_reports_page, comment, image, lft, rght, tree_id, level) FROM stdin;
\.


--
-- Name: customers_collection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('customers_collection_id_seq', 1, false);


--
-- Data for Name: customers_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY customers_customer (encryption_data_initialization_vector, created, modified, id, provider_id, name, vat, address, postal_code, city, phone, country_code, timezone, contact_name, contact_email, contact_phone, electricity_instantaneous, electricity_consumption, gas_instantaneous, gas_consumption, water_instantaneous, water_consumption, heat_instantaneous, heat_consumption, temperature, oil_instantaneous, oil_consumption, currency_unit, electricity_tariff_id, gas_tariff_id, water_tariff_id, heat_tariff_id, oil_tariff_id, is_active, production_a_unit, production_b_unit, production_c_unit, production_d_unit, production_e_unit, created_by_id) FROM stdin;
\.


--
-- Data for Name: customers_customer_industry_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY customers_customer_industry_types (id, customer_id, industrytype_id) FROM stdin;
\.


--
-- Name: customers_customer_industry_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('customers_customer_industry_types_id_seq', 1, false);


--
-- Data for Name: customers_location; Type: TABLE DATA; Schema: public; Owner: -
--

COPY customers_location (id, encryption_data_initialization_vector, customer_id, parent_id, name, lft, rght, tree_id, level) FROM stdin;
\.


--
-- Name: customers_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('customers_location_id_seq', 1, false);


--
-- Data for Name: customers_userprofile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY customers_userprofile (id, user_id) FROM stdin;
\.


--
-- Data for Name: customers_userprofile_collections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY customers_userprofile_collections (id, userprofile_id, collection_id) FROM stdin;
\.


--
-- Name: customers_userprofile_collections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('customers_userprofile_collections_id_seq', 1, false);


--
-- Name: customers_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('customers_userprofile_id_seq', 1, false);


--
-- Data for Name: dataneeds_dataneed; Type: TABLE DATA; Schema: public; Owner: -
--

COPY dataneeds_dataneed (id, subclass_id, customer_id) FROM stdin;
\.


--
-- Name: dataneeds_dataneed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('dataneeds_dataneed_id_seq', 1, false);


--
-- Data for Name: dataneeds_energyusedataneed; Type: TABLE DATA; Schema: public; Owner: -
--

COPY dataneeds_energyusedataneed (dataneed_ptr_id, energyuse_id) FROM stdin;
\.


--
-- Data for Name: dataneeds_mainconsumptiondataneed; Type: TABLE DATA; Schema: public; Owner: -
--

COPY dataneeds_mainconsumptiondataneed (dataneed_ptr_id, mainconsumption_id) FROM stdin;
\.


--
-- Data for Name: dataneeds_productiongroupdataneed; Type: TABLE DATA; Schema: public; Owner: -
--

COPY dataneeds_productiongroupdataneed (dataneed_ptr_id, productiongroup_id) FROM stdin;
\.


--
-- Data for Name: datasequence_adapters_consumptionaccumulationadapter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY datasequence_adapters_consumptionaccumulationadapter (dataseries_ptr_id, datasequence_id) FROM stdin;
\.


--
-- Data for Name: datasequence_adapters_nonaccumulationadapter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY datasequence_adapters_nonaccumulationadapter (dataseries_ptr_id, datasequence_id) FROM stdin;
\.


--
-- Data for Name: datasequence_adapters_productionaccumulationadapter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY datasequence_adapters_productionaccumulationadapter (dataseries_ptr_id, datasequence_id) FROM stdin;
\.


--
-- Data for Name: datasequences_energypervolumedatasequence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY datasequences_energypervolumedatasequence (id, encryption_data_initialization_vector, subclass_id, customer_id, name) FROM stdin;
\.


--
-- Name: datasequences_energypervolumedatasequence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('datasequences_energypervolumedatasequence_id_seq', 1, false);


--
-- Data for Name: datasequences_energypervolumeperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY datasequences_energypervolumeperiod (id, from_timestamp, to_timestamp, datasequence_id, datasource_id) FROM stdin;
\.


--
-- Name: datasequences_energypervolumeperiod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('datasequences_energypervolumeperiod_id_seq', 1, false);


--
-- Data for Name: datasequences_nonaccumulationdatasequence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY datasequences_nonaccumulationdatasequence (id, encryption_data_initialization_vector, subclass_id, customer_id, name, unit) FROM stdin;
\.


--
-- Name: datasequences_nonaccumulationdatasequence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('datasequences_nonaccumulationdatasequence_id_seq', 1, false);


--
-- Data for Name: datasequences_nonaccumulationofflinetolerance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY datasequences_nonaccumulationofflinetolerance (id, hours, datasequence_id) FROM stdin;
\.


--
-- Name: datasequences_nonaccumulationofflinetolerance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('datasequences_nonaccumulationofflinetolerance_id_seq', 1, false);


--
-- Data for Name: datasequences_nonaccumulationperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY datasequences_nonaccumulationperiod (id, from_timestamp, to_timestamp, datasequence_id, datasource_id) FROM stdin;
\.


--
-- Name: datasequences_nonaccumulationperiod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('datasequences_nonaccumulationperiod_id_seq', 1, false);


--
-- Data for Name: datasources_datasource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY datasources_datasource (id, subclass_id, unit, hardware_id) FROM stdin;
\.


--
-- Name: datasources_datasource_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('datasources_datasource_id_seq', 1, false);


--
-- Data for Name: datasources_rawdata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY datasources_rawdata (id, value, "timestamp", datasource_id) FROM stdin;
\.


--
-- Name: datasources_rawdata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('datasources_rawdata_id_seq', 1, false);


--
-- Data for Name: devices_agent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY devices_agent (id, device_type, device_serial, hw_major, hw_minor, hw_revision, hw_subrevision, sw_major, sw_minor, sw_revision, sw_subrevision, customer_id, location_id, mac, online, online_since, add_mode, no_longer_in_use) FROM stdin;
\.


--
-- Name: devices_agent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('devices_agent_id_seq', 1, false);


--
-- Data for Name: devices_agentevent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY devices_agentevent (id, agent_id, "timestamp", code, message) FROM stdin;
\.


--
-- Name: devices_agentevent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('devices_agentevent_id_seq', 1, false);


--
-- Data for Name: devices_agentstatechange; Type: TABLE DATA; Schema: public; Owner: -
--

COPY devices_agentstatechange (id, agent_id, "timestamp", online, add_mode) FROM stdin;
\.


--
-- Name: devices_agentstatechange_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('devices_agentstatechange_id_seq', 1, false);


--
-- Data for Name: devices_meter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY devices_meter (id, encryption_data_initialization_vector, device_type, device_serial, hw_major, hw_minor, hw_revision, hw_subrevision, sw_major, sw_minor, sw_revision, sw_subrevision, agent_id, customer_id, manufactoring_id, connection_type, manual_mode, relay_on, online, online_since, joined, location_id, relay_enabled, name) FROM stdin;
\.


--
-- Name: devices_meter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('devices_meter_id_seq', 1, false);


--
-- Data for Name: devices_meterstatechange; Type: TABLE DATA; Schema: public; Owner: -
--

COPY devices_meterstatechange (id, meter_id, "timestamp", manual_mode, relay_on, online) FROM stdin;
\.


--
-- Name: devices_meterstatechange_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('devices_meterstatechange_id_seq', 1, false);


--
-- Data for Name: devices_physicalinput; Type: TABLE DATA; Schema: public; Owner: -
--

COPY devices_physicalinput (customerdatasource_ptr_id, type, meter_id, "order", store_measurements) FROM stdin;
\.


--
-- Data for Name: devices_softwareimage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY devices_softwareimage (id, device_type, hw_major, hw_minor, hw_revision, hw_subrevision, sw_major, sw_minor, sw_revision, sw_subrevision) FROM stdin;
\.


--
-- Name: devices_softwareimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('devices_softwareimage_id_seq', 1, false);


--
-- Data for Name: display_widgets_dashboardwidget; Type: TABLE DATA; Schema: public; Owner: -
--

COPY display_widgets_dashboardwidget (id, user_id, "column", "row", collection_id, index_id, widget_type) FROM stdin;
\.


--
-- Name: display_widgets_dashboardwidget_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('display_widgets_dashboardwidget_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message) FROM stdin;
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 1, false);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	encryption key	encryption	encryptionkey
2	user	users	user
3	customer	customers	customer
4	collection	customers	collection
5	collection constraint	customers	collectionconstraint
6	location	customers	location
7	user profile	customers	userprofile
8	Current measurement point	customers	currentmeasurementpoint
9	Power measurement point	customers	powermeasurementpoint
10	Production measurement point	customers	productionmeasurementpoint
11	Reactive energy measurement point	customers	reactiveenergymeasurementpoint
12	Measurement point	customers	measurementpoint
13	district heating measurement point	customers	districtheatingmeasurementpoint
14	Voltage measurement point	customers	voltagemeasurementpoint
15	Temperature measurement point	customers	temperaturemeasurementpoint
16	Summation measurement point	customers	consumptionmeasurementpointsummation
17	Reactive power measurement point	customers	reactivepowermeasurementpoint
18	Consumption measurement point	customers	consumptionmeasurementpoint
19	Multiplication measurement point	customers	consumptionmultiplicationpoint
20	Imported measurement point	customers	importedmeasurementpoint
21	Power factor measurement point	customers	powerfactormeasurementpoint
22	provider	providers	provider
23	hour accumulated data	condensing	houraccumulateddata
24	five minutes accumulated data	condensing	fiveminuteaccumulateddata
25	report	reports	report
26	data source	datasources	datasource
27	raw data	datasources	rawdata
28	global data source	global_datasources	globaldatasource
29	provider data source	provider_datasources	providerdatasource
30	customer data source	customer_datasources	customerdatasource
31	energy conversion data sequence	datasequences	energypervolumedatasequence
32	volume to energy conversion period	datasequences	energypervolumeperiod
33	nonaccumulation data sequence	datasequences	nonaccumulationdatasequence
34	nonaccumulation period	datasequences	nonaccumulationperiod
35	nonaccumulation offline tolerance	datasequences	nonaccumulationofflinetolerance
36	consumption data sequence	consumptions	consumption
37	main consumption	consumptions	mainconsumption
38	consumption group	consumptions	consumptiongroup
39	consumption period	consumptions	period
40	non-pulse consumption period	consumptions	nonpulseperiod
41	pulse consumption period	consumptions	pulseperiod
42	single value consumption period	consumptions	singlevalueperiod
43	offline tolerance	consumptions	offlinetolerance
44	production	productions	production
45	production group	productions	productiongroup
46	production period	productions	period
47	non-pulse production period	productions	nonpulseperiod
48	pulse production period	productions	pulseperiod
49	single value production period	productions	singlevalueperiod
50	offline tolerance	productions	offlinetolerance
51	tariff	tariffs	tariff
52	energy tariff	tariffs	energytariff
53	volume tariff	tariffs	volumetariff
54	tariff period	tariffs	period
55	fixed price period	tariffs	fixedpriceperiod
56	spot price period	tariffs	spotpriceperiod
57	cost compensation	cost_compensations	costcompensation
58	cost compensation period	cost_compensations	period
59	fixed compensation period	cost_compensations	fixedcompensationperiod
60	token data	token_auth	tokendata
61	energy performance	energyperformances	energyperformance
62	production energy performance	energyperformances	productionenergyperformance
63	consumption performance	energyperformances	timeenergyperformance
64	CO₂ conversions	co2conversions	co2conversion
65	dynamic CO₂ conversion	co2conversions	dynamicco2conversion
66	fixed CO₂ conversion	co2conversions	fixedco2conversion
67	agent	devices	agent
68	agent state change	devices	agentstatechange
69	agent event	devices	agentevent
70	meter	devices	meter
71	meter state change	devices	meterstatechange
72	physical input	devices	physicalinput
73	software image	devices	softwareimage
74	dashboard widget	display_widgets	dashboardwidget
75	index	indexes	index
76	model binding	energinet_co2	modelbinding
77	energy use report	energy_use_reports	energyusereport
78	energy use area	energy_use_reports	energyusearea
79	enpi report	enpi_reports	enpireport
80	enpi use area	enpi_reports	enpiusearea
81	entry	indexes	entry
82	derived index period	indexes	derivedindexperiod
83	season index period	indexes	seasonindexperiod
84	spot mapping	indexes	spotmapping
85	standard month index	indexes	standardmonthindex
86	data source index adapter	indexes	datasourceindexadapter
87	floorplan	manage_collections	floorplan
88	item	manage_collections	item
89	collection item	manage_collections	collectionitem
90	info item	manage_collections	infoitem
91	graph	measurementpoints	graph
92	dataseries	measurementpoints	dataseries
93	stored data	measurementpoints	storeddata
94	chain	measurementpoints	chain
95	chain link	measurementpoints	chainlink
96	index calculation	measurementpoints	indexcalculation
97	heating degree days	measurementpoints	heatingdegreedays
98	degree day correction	measurementpoints	degreedaycorrection
99	piecewise constant integral	measurementpoints	piecewiseconstantintegral
100	link	measurementpoints	link
101	mean temperature change	measurementpoints	meantemperaturechange
102	mulitplication	measurementpoints	multiplication
103	rate conversion	measurementpoints	rateconversion
104	Simple linear regression	measurementpoints	simplelinearregression
105	summation	measurementpoints	summation
106	summation term	measurementpoints	summationterm
107	normalization	measurementpoints	utilization
108	stored data series	measurementpoints	storeddataseries
109	cost calculation	measurementpoints	costcalculation
110	CO₂ calculation	measurementpoints	co2calculation
111	consumption accumulation adapter	datasequence_adapters	consumptionaccumulationadapter
112	production accumulation adapter	datasequence_adapters	productionaccumulationadapter
113	nonaccumulation adapter	datasequence_adapters	nonaccumulationadapter
114	benchmark project	projects	benchmarkproject
115	additional saving	projects	additionalsaving
116	cost	projects	cost
117	user rule	rules	userrule
118	date exception	rules	dateexception
119	relay action	rules	relayaction
120	email action	rules	emailaction
121	phone action	rules	phoneaction
122	minimize rule	rules	minimizerule
123	triggered rule	rules	triggeredrule
124	index invariant	rules	indexinvariant
125	input invariant	rules	inputinvariant
126	efficiency link	efficiencymeasurementpoints	efficiencylink
127	efficiency measurement point	efficiencymeasurementpoints	efficiencymeasurementpoint
128	data need	dataneeds	dataneed
129	main consumption data need	dataneeds	mainconsumptiondataneed
130	energy use data need	dataneeds	energyusedataneed
131	production group data need	dataneeds	productiongroupdataneed
132	manually reported production	manual_reporting	manuallyreportedproduction
133	manually reported consumption	manual_reporting	manuallyreportedconsumption
134	energy use	energyuses	energyuse
135	process period	processperiods	processperiod
136	process period goal	processperiods	processperiodgoal
137	opportunity	opportunities	opportunity
138	health report	system_health_site	healthreport
139	floor plan	installations	floorplan
140	product installlation	installations	productinstallation
141	gateway installlation	installations	gatewayinstallation
142	repeater installlation	installations	repeaterinstallation
143	meter installlation	installations	meterinstallation
144	triple input meter installlation	installations	tripleinputmeterinstallation
145	pulse emitter installation	installations	pulseemitterinstallation
146	triple pulse collector installation	installations	triplepulsecollectorinstallation
147	installation photo	installations	installationphoto
148	product category	products	productcategory
149	Product	products	product
150	Historical product	products	historicalproduct
151	supplier	suppliers	supplier
152	industry type	salesopportunities	industrytype
153	industry type use distribution	salesopportunities	industrytypeusedistribution
154	industry type savings	salesopportunities	industrytypesavings
155	sales opportunity	salesopportunities	salesopportunity
156	sales opportunity use distribution	salesopportunities	salesopportunityusedistribution
157	sales opportunity savings	salesopportunities	salesopportunitysavings
158	survey instruction	salesopportunities	surveyinstruction
159	activity log entry	salesopportunities	activityentry
160	task	salesopportunities	task
161	work hours	installation_surveys	workhours
162	Billing meter	installation_surveys	billingmeter
163	Billing meter appendix	installation_surveys	billingmeterappendix
164	Area of energy use	installation_surveys	energyusearea
165	proposed action	installation_surveys	proposedaction
166	proposed action	energy_breakdown	proposedaction
167	electricity consumption total	energy_breakdown	electricityconsumptiontotal
168	electricity consumption area	energy_breakdown	electricityconsumptionarea
169	fuel consumption total	energy_breakdown	fuelconsumptiontotal
170	fuel consumption area	energy_breakdown	fuelconsumptionarea
171	district heating consumption total	energy_breakdown	districtheatingconsumptiontotal
172	district heating consumption area	energy_breakdown	districtheatingconsumptionarea
173	water consumption total	energy_breakdown	waterconsumptiontotal
174	water consumption area	energy_breakdown	waterconsumptionarea
175	permission	auth	permission
176	group	auth	group
177	user	auth	user
178	content type	contenttypes	contenttype
179	session	sessions	session
180	log entry	admin	logentry
181	cors model	corsheaders	corsmodel
182	migration history	south	migrationhistory
183	task state	djcelery	taskmeta
184	saved group result	djcelery	tasksetmeta
185	interval	djcelery	intervalschedule
186	crontab	djcelery	crontabschedule
187	periodic tasks	djcelery	periodictasks
188	periodic task	djcelery	periodictask
189	worker	djcelery	workerstate
190	task	djcelery	taskstate
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('django_content_type_id_seq', 190, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Data for Name: djcelery_crontabschedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djcelery_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year) FROM stdin;
\.


--
-- Name: djcelery_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('djcelery_crontabschedule_id_seq', 1, false);


--
-- Data for Name: djcelery_intervalschedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djcelery_intervalschedule (id, every, period) FROM stdin;
\.


--
-- Name: djcelery_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('djcelery_intervalschedule_id_seq', 1, false);


--
-- Data for Name: djcelery_periodictask; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djcelery_periodictask (id, name, task, interval_id, crontab_id, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description) FROM stdin;
\.


--
-- Name: djcelery_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('djcelery_periodictask_id_seq', 1, false);


--
-- Data for Name: djcelery_periodictasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djcelery_periodictasks (ident, last_update) FROM stdin;
\.


--
-- Data for Name: djcelery_taskstate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djcelery_taskstate (id, state, task_id, name, tstamp, args, kwargs, eta, expires, result, traceback, runtime, retries, worker_id, hidden) FROM stdin;
\.


--
-- Name: djcelery_taskstate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('djcelery_taskstate_id_seq', 1, false);


--
-- Data for Name: djcelery_workerstate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY djcelery_workerstate (id, hostname, last_heartbeat) FROM stdin;
\.


--
-- Name: djcelery_workerstate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('djcelery_workerstate_id_seq', 1, false);


--
-- Data for Name: encryption_encryptionkey; Type: TABLE DATA; Schema: public; Owner: -
--

COPY encryption_encryptionkey (id, key, content_type_id, object_id, user_id) FROM stdin;
\.


--
-- Name: encryption_encryptionkey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('encryption_encryptionkey_id_seq', 1, false);


--
-- Data for Name: energinet_co2_modelbinding; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energinet_co2_modelbinding (id, index_id) FROM stdin;
1	1
\.


--
-- Name: energinet_co2_modelbinding_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energinet_co2_modelbinding_id_seq', 1, true);


--
-- Data for Name: energy_breakdown_districtheatingconsumptionarea; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_breakdown_districtheatingconsumptionarea (id, consumption, salesopportunity_id, energyusearea_id) FROM stdin;
\.


--
-- Name: energy_breakdown_districtheatingconsumptionarea_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_breakdown_districtheatingconsumptionarea_id_seq', 1, false);


--
-- Data for Name: energy_breakdown_districtheatingconsumptiontotal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_breakdown_districtheatingconsumptiontotal (id, consumption, salesopportunity_id) FROM stdin;
\.


--
-- Name: energy_breakdown_districtheatingconsumptiontotal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_breakdown_districtheatingconsumptiontotal_id_seq', 1, false);


--
-- Data for Name: energy_breakdown_electricityconsumptionarea; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_breakdown_electricityconsumptionarea (id, consumption, salesopportunity_id, energyusearea_id) FROM stdin;
\.


--
-- Name: energy_breakdown_electricityconsumptionarea_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_breakdown_electricityconsumptionarea_id_seq', 1, false);


--
-- Data for Name: energy_breakdown_electricityconsumptiontotal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_breakdown_electricityconsumptiontotal (id, consumption, salesopportunity_id) FROM stdin;
\.


--
-- Name: energy_breakdown_electricityconsumptiontotal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_breakdown_electricityconsumptiontotal_id_seq', 1, false);


--
-- Data for Name: energy_breakdown_fuelconsumptionarea; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_breakdown_fuelconsumptionarea (id, consumption, salesopportunity_id, energyusearea_id) FROM stdin;
\.


--
-- Name: energy_breakdown_fuelconsumptionarea_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_breakdown_fuelconsumptionarea_id_seq', 1, false);


--
-- Data for Name: energy_breakdown_fuelconsumptiontotal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_breakdown_fuelconsumptiontotal (id, consumption, salesopportunity_id) FROM stdin;
\.


--
-- Name: energy_breakdown_fuelconsumptiontotal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_breakdown_fuelconsumptiontotal_id_seq', 1, false);


--
-- Data for Name: energy_breakdown_proposedaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_breakdown_proposedaction (id, encryption_data_initialization_vector, salesopportunity_id, energyusearea_id, name, yearly_consumption_cost, saving_percent, subsidy, investment, description) FROM stdin;
\.


--
-- Name: energy_breakdown_proposedaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_breakdown_proposedaction_id_seq', 1, false);


--
-- Data for Name: energy_breakdown_waterconsumptionarea; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_breakdown_waterconsumptionarea (id, consumption, salesopportunity_id, energyusearea_id) FROM stdin;
\.


--
-- Name: energy_breakdown_waterconsumptionarea_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_breakdown_waterconsumptionarea_id_seq', 1, false);


--
-- Data for Name: energy_breakdown_waterconsumptiontotal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_breakdown_waterconsumptiontotal (id, consumption, salesopportunity_id) FROM stdin;
\.


--
-- Name: energy_breakdown_waterconsumptiontotal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_breakdown_waterconsumptiontotal_id_seq', 1, false);


--
-- Data for Name: energy_use_reports_energyusearea; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_use_reports_energyusearea (id, encryption_data_initialization_vector, report_id, name) FROM stdin;
\.


--
-- Name: energy_use_reports_energyusearea_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_use_reports_energyusearea_id_seq', 1, false);


--
-- Data for Name: energy_use_reports_energyusearea_measurement_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_use_reports_energyusearea_measurement_points (id, energyusearea_id, consumptionmeasurementpoint_id) FROM stdin;
\.


--
-- Name: energy_use_reports_energyusearea_measurement_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_use_reports_energyusearea_measurement_points_id_seq', 1, false);


--
-- Data for Name: energy_use_reports_energyusereport; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_use_reports_energyusereport (id, encryption_data_initialization_vector, customer_id, title, currency_unit, utility_type) FROM stdin;
\.


--
-- Name: energy_use_reports_energyusereport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_use_reports_energyusereport_id_seq', 1, false);


--
-- Name: energy_use_reports_energyusereport_main_measurement_poin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energy_use_reports_energyusereport_main_measurement_poin_id_seq', 1, false);


--
-- Data for Name: energy_use_reports_energyusereport_main_measurement_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energy_use_reports_energyusereport_main_measurement_points (id, energyusereport_id, consumptionmeasurementpoint_id) FROM stdin;
\.


--
-- Data for Name: energyperformances_energyperformance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energyperformances_energyperformance (id, encryption_data_initialization_vector, subclass_id, customer_id, name, description) FROM stdin;
\.


--
-- Name: energyperformances_energyperformance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energyperformances_energyperformance_id_seq', 1, false);


--
-- Data for Name: energyperformances_productionenergyperformance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energyperformances_productionenergyperformance (energyperformance_ptr_id, production_unit) FROM stdin;
\.


--
-- Name: energyperformances_productionenergyperformance_consumpti_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energyperformances_productionenergyperformance_consumpti_id_seq', 1, false);


--
-- Data for Name: energyperformances_productionenergyperformance_consumptiong23ca; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energyperformances_productionenergyperformance_consumptiong23ca (id, productionenergyperformance_id, consumptiongroup_id) FROM stdin;
\.


--
-- Name: energyperformances_productionenergyperformance_productio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energyperformances_productionenergyperformance_productio_id_seq', 1, false);


--
-- Data for Name: energyperformances_productionenergyperformance_productiongroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energyperformances_productionenergyperformance_productiongroups (id, productionenergyperformance_id, productiongroup_id) FROM stdin;
\.


--
-- Data for Name: energyperformances_timeenergyperformance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energyperformances_timeenergyperformance (energyperformance_ptr_id, unit) FROM stdin;
\.


--
-- Name: energyperformances_timeenergyperformance_consumptiongrou_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('energyperformances_timeenergyperformance_consumptiongrou_id_seq', 1, false);


--
-- Data for Name: energyperformances_timeenergyperformance_consumptiongroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energyperformances_timeenergyperformance_consumptiongroups (id, timeenergyperformance_id, consumptiongroup_id) FROM stdin;
\.


--
-- Data for Name: energyuses_energyuse; Type: TABLE DATA; Schema: public; Owner: -
--

COPY energyuses_energyuse (consumptiongroup_ptr_id, main_energy_use_area) FROM stdin;
\.


--
-- Data for Name: enpi_reports_enpireport; Type: TABLE DATA; Schema: public; Owner: -
--

COPY enpi_reports_enpireport (id, encryption_data_initialization_vector, customer_id, title, energy_driver_unit) FROM stdin;
\.


--
-- Name: enpi_reports_enpireport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('enpi_reports_enpireport_id_seq', 1, false);


--
-- Data for Name: enpi_reports_enpiusearea; Type: TABLE DATA; Schema: public; Owner: -
--

COPY enpi_reports_enpiusearea (id, encryption_data_initialization_vector, report_id, name, energy_driver_id) FROM stdin;
\.


--
-- Name: enpi_reports_enpiusearea_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('enpi_reports_enpiusearea_id_seq', 1, false);


--
-- Data for Name: enpi_reports_enpiusearea_measurement_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY enpi_reports_enpiusearea_measurement_points (id, enpiusearea_id, consumptionmeasurementpoint_id) FROM stdin;
\.


--
-- Name: enpi_reports_enpiusearea_measurement_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('enpi_reports_enpiusearea_measurement_points_id_seq', 1, false);


--
-- Data for Name: global_datasources_globaldatasource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY global_datasources_globaldatasource (datasource_ptr_id, name, app_label, codename, country) FROM stdin;
\.


--
-- Data for Name: indexes_datasourceindexadapter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indexes_datasourceindexadapter (index_ptr_id, datasource_id) FROM stdin;
\.


--
-- Data for Name: indexes_derivedindexperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indexes_derivedindexperiod (id, index_id, from_date, other_index_id, coefficient, constant, roof) FROM stdin;
\.


--
-- Name: indexes_derivedindexperiod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('indexes_derivedindexperiod_id_seq', 1, false);


--
-- Data for Name: indexes_entry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indexes_entry (id, index_id, from_timestamp, to_timestamp, value) FROM stdin;
\.


--
-- Name: indexes_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('indexes_entry_id_seq', 1, false);


--
-- Data for Name: indexes_index; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indexes_index (dataseries_ptr_id, encryption_data_initialization_vector, name, data_format, collection_id, timezone) FROM stdin;
1		Energinet.dk CO₂	0	\N	Europe/Copenhagen
\.


--
-- Data for Name: indexes_seasonindexperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indexes_seasonindexperiod (id, index_id, from_date, value_at_hour_0, value_at_hour_1, value_at_hour_2, value_at_hour_3, value_at_hour_4, value_at_hour_5, value_at_hour_6, value_at_hour_7, value_at_hour_8, value_at_hour_9, value_at_hour_10, value_at_hour_11, value_at_hour_12, value_at_hour_13, value_at_hour_14, value_at_hour_15, value_at_hour_16, value_at_hour_17, value_at_hour_18, value_at_hour_19, value_at_hour_20, value_at_hour_21, value_at_hour_22, value_at_hour_23) FROM stdin;
\.


--
-- Name: indexes_seasonindexperiod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('indexes_seasonindexperiod_id_seq', 1, false);


--
-- Data for Name: indexes_spotmapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indexes_spotmapping (id, index_id, area, unit, timezone) FROM stdin;
\.


--
-- Name: indexes_spotmapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('indexes_spotmapping_id_seq', 1, false);


--
-- Data for Name: indexes_standardmonthindex; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indexes_standardmonthindex (index_ptr_id, january, february, march, april, may, june, july, august, september, october, november, december) FROM stdin;
\.


--
-- Data for Name: installation_surveys_billingmeter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installation_surveys_billingmeter (id, encryption_data_initialization_vector, salesopportunity_id, utility_type, description, utility_provider, installation_number, billing_number) FROM stdin;
\.


--
-- Name: installation_surveys_billingmeter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installation_surveys_billingmeter_id_seq', 1, false);


--
-- Data for Name: installation_surveys_billingmeterappendix; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installation_surveys_billingmeterappendix (id, encryption_data_initialization_vector, billingmeter_id, name, data) FROM stdin;
\.


--
-- Name: installation_surveys_billingmeterappendix_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installation_surveys_billingmeterappendix_id_seq', 1, false);


--
-- Data for Name: installation_surveys_energyusearea; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installation_surveys_energyusearea (id, encryption_data_initialization_vector, salesopportunity_id, description, electricity, district_heating, fuel, water) FROM stdin;
\.


--
-- Name: installation_surveys_energyusearea_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installation_surveys_energyusearea_id_seq', 1, false);


--
-- Data for Name: installation_surveys_proposedaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installation_surveys_proposedaction (id, encryption_data_initialization_vector, salesopportunity_id, energyusearea_id, name, description) FROM stdin;
\.


--
-- Name: installation_surveys_proposedaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installation_surveys_proposedaction_id_seq', 1, false);


--
-- Data for Name: installation_surveys_workhours; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installation_surveys_workhours (id, encryption_data_initialization_vector, salesopportunity_id, description, period) FROM stdin;
\.


--
-- Name: installation_surveys_workhours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installation_surveys_workhours_id_seq', 1, false);


--
-- Data for Name: installations_floorplan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_floorplan (id, encryption_data_initialization_vector, created, modified, customer_id, name, image) FROM stdin;
\.


--
-- Name: installations_floorplan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installations_floorplan_id_seq', 1, false);


--
-- Data for Name: installations_gatewayinstallation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_gatewayinstallation (productinstallation_ptr_id, internet_connection) FROM stdin;
\.


--
-- Data for Name: installations_installationphoto; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_installationphoto (id, encryption_data_initialization_vector, created, modified, installation_id, name, data) FROM stdin;
\.


--
-- Name: installations_installationphoto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installations_installationphoto_id_seq', 1, false);


--
-- Data for Name: installations_meterinstallation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_meterinstallation (productinstallation_ptr_id, gateway_id) FROM stdin;
\.


--
-- Name: installations_meterinstallation_input_satisfies_dataneed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installations_meterinstallation_input_satisfies_dataneed_id_seq', 1, false);


--
-- Data for Name: installations_meterinstallation_input_satisfies_dataneeds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_meterinstallation_input_satisfies_dataneeds (id, meterinstallation_id, dataneed_id) FROM stdin;
\.


--
-- Data for Name: installations_productinstallation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_productinstallation (id, encryption_data_initialization_vector, subclass_id, product_id, name, purpose, installation_notes, floorplan_id, installation_number, marker_x, marker_y) FROM stdin;
\.


--
-- Name: installations_productinstallation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installations_productinstallation_id_seq', 1, false);


--
-- Data for Name: installations_pulseemitterinstallation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_pulseemitterinstallation (productinstallation_ptr_id, pulse_quantity, output_quantity, output_unit) FROM stdin;
\.


--
-- Name: installations_pulseemitterinstallation_input_satisfies_d_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installations_pulseemitterinstallation_input_satisfies_d_id_seq', 1, false);


--
-- Data for Name: installations_pulseemitterinstallation_input_satisfies_data7b36; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_pulseemitterinstallation_input_satisfies_data7b36 (id, pulseemitterinstallation_id, dataneed_id) FROM stdin;
\.


--
-- Data for Name: installations_repeaterinstallation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_repeaterinstallation (productinstallation_ptr_id, gateway_id) FROM stdin;
\.


--
-- Data for Name: installations_tripleinputmeterinstallation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_tripleinputmeterinstallation (productinstallation_ptr_id, gateway_id) FROM stdin;
\.


--
-- Name: installations_tripleinputmeterinstallation_input1_satisf_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installations_tripleinputmeterinstallation_input1_satisf_id_seq', 1, false);


--
-- Data for Name: installations_tripleinputmeterinstallation_input1_satisfies0539; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_tripleinputmeterinstallation_input1_satisfies0539 (id, tripleinputmeterinstallation_id, dataneed_id) FROM stdin;
\.


--
-- Name: installations_tripleinputmeterinstallation_input2_satisf_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installations_tripleinputmeterinstallation_input2_satisf_id_seq', 1, false);


--
-- Data for Name: installations_tripleinputmeterinstallation_input2_satisfies1aad; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_tripleinputmeterinstallation_input2_satisfies1aad (id, tripleinputmeterinstallation_id, dataneed_id) FROM stdin;
\.


--
-- Name: installations_tripleinputmeterinstallation_input3_satisf_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('installations_tripleinputmeterinstallation_input3_satisf_id_seq', 1, false);


--
-- Data for Name: installations_tripleinputmeterinstallation_input3_satisfies9eaa; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_tripleinputmeterinstallation_input3_satisfies9eaa (id, tripleinputmeterinstallation_id, dataneed_id) FROM stdin;
\.


--
-- Data for Name: installations_triplepulsecollectorinstallation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY installations_triplepulsecollectorinstallation (productinstallation_ptr_id, gateway_id, input1_pulseemitterinstallation_id, input2_pulseemitterinstallation_id, input3_pulseemitterinstallation_id) FROM stdin;
\.


--
-- Data for Name: manage_collections_collectionitem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY manage_collections_collectionitem (item_ptr_id, collection_id) FROM stdin;
\.


--
-- Data for Name: manage_collections_floorplan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY manage_collections_floorplan (id, collection_id, image) FROM stdin;
\.


--
-- Name: manage_collections_floorplan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('manage_collections_floorplan_id_seq', 1, false);


--
-- Data for Name: manage_collections_infoitem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY manage_collections_infoitem (item_ptr_id, encryption_data_initialization_vector, info) FROM stdin;
\.


--
-- Data for Name: manage_collections_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY manage_collections_item (id, subclass_id, floorplan_id, x, y, z) FROM stdin;
\.


--
-- Name: manage_collections_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('manage_collections_item_id_seq', 1, false);


--
-- Data for Name: manual_reporting_manuallyreportedconsumption; Type: TABLE DATA; Schema: public; Owner: -
--

COPY manual_reporting_manuallyreportedconsumption (consumption_ptr_id) FROM stdin;
\.


--
-- Data for Name: manual_reporting_manuallyreportedproduction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY manual_reporting_manuallyreportedproduction (production_ptr_id) FROM stdin;
\.


--
-- Data for Name: measurementpoints_chain; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_chain (dataseries_ptr_id) FROM stdin;
\.


--
-- Data for Name: measurementpoints_chainlink; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_chainlink (id, chain_id, data_series_id, valid_from) FROM stdin;
\.


--
-- Name: measurementpoints_chainlink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('measurementpoints_chainlink_id_seq', 1, false);


--
-- Data for Name: measurementpoints_dataseries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_dataseries (id, subclass_id, customer_id, role, graph_id, unit, utility_type) FROM stdin;
1	75	\N	16	\N	gram*kilowatt^-1*hour^-1	2000
\.


--
-- Name: measurementpoints_dataseries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('measurementpoints_dataseries_id_seq', 1, true);


--
-- Data for Name: measurementpoints_degreedaycorrection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_degreedaycorrection (dataseries_ptr_id, consumption_id, standarddegreedays_id, degreedays_id) FROM stdin;
\.


--
-- Data for Name: measurementpoints_graph; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_graph (id, role, collection_id, hidden) FROM stdin;
\.


--
-- Name: measurementpoints_graph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('measurementpoints_graph_id_seq', 1, false);


--
-- Data for Name: measurementpoints_heatingdegreedays; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_heatingdegreedays (dataseries_ptr_id, derived_from_id) FROM stdin;
\.


--
-- Data for Name: measurementpoints_indexcalculation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_indexcalculation (dataseries_ptr_id, index_id, consumption_id) FROM stdin;
\.


--
-- Data for Name: measurementpoints_link; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_link (dataseries_ptr_id, target_id) FROM stdin;
\.


--
-- Data for Name: measurementpoints_meantemperaturechange; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_meantemperaturechange (dataseries_ptr_id, energy_id, volume_id) FROM stdin;
\.


--
-- Data for Name: measurementpoints_multiplication; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_multiplication (dataseries_ptr_id, multiplier, source_data_series_id) FROM stdin;
\.


--
-- Data for Name: measurementpoints_piecewiseconstantintegral; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_piecewiseconstantintegral (dataseries_ptr_id, data_id) FROM stdin;
\.


--
-- Data for Name: measurementpoints_rateconversion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_rateconversion (dataseries_ptr_id, consumption_id) FROM stdin;
\.


--
-- Data for Name: measurementpoints_simplelinearregression; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_simplelinearregression (dataseries_ptr_id, data_id) FROM stdin;
\.


--
-- Data for Name: measurementpoints_storeddata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_storeddata (id, data_series_id, value, "timestamp") FROM stdin;
\.


--
-- Name: measurementpoints_storeddata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('measurementpoints_storeddata_id_seq', 1, false);


--
-- Data for Name: measurementpoints_summation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_summation (dataseries_ptr_id) FROM stdin;
\.


--
-- Data for Name: measurementpoints_summationterm; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_summationterm (id, sign, summation_id, data_series_id) FROM stdin;
\.


--
-- Name: measurementpoints_summationterm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('measurementpoints_summationterm_id_seq', 1, false);


--
-- Data for Name: measurementpoints_utilization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY measurementpoints_utilization (dataseries_ptr_id, consumption_id, needs_id) FROM stdin;
\.


--
-- Data for Name: opportunities_opportunity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY opportunities_opportunity (id, encryption_data_initialization_vector, customer_id, name, description, completed) FROM stdin;
\.


--
-- Name: opportunities_opportunity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('opportunities_opportunity_id_seq', 1, false);


--
-- Data for Name: processperiods_processperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY processperiods_processperiod (id, encryption_data_initialization_vector, customer_id, title, policy, from_date, to_date) FROM stdin;
\.


--
-- Data for Name: processperiods_processperiod_accepted_opportunities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY processperiods_processperiod_accepted_opportunities (id, processperiod_id, opportunity_id) FROM stdin;
\.


--
-- Name: processperiods_processperiod_accepted_opportunities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('processperiods_processperiod_accepted_opportunities_id_seq', 1, false);


--
-- Data for Name: processperiods_processperiod_enpis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY processperiods_processperiod_enpis (id, processperiod_id, energyperformance_id) FROM stdin;
\.


--
-- Name: processperiods_processperiod_enpis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('processperiods_processperiod_enpis_id_seq', 1, false);


--
-- Name: processperiods_processperiod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('processperiods_processperiod_id_seq', 1, false);


--
-- Data for Name: processperiods_processperiod_rejected_opportunities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY processperiods_processperiod_rejected_opportunities (id, processperiod_id, opportunity_id) FROM stdin;
\.


--
-- Name: processperiods_processperiod_rejected_opportunities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('processperiods_processperiod_rejected_opportunities_id_seq', 1, false);


--
-- Data for Name: processperiods_processperiod_significant_energyuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY processperiods_processperiod_significant_energyuses (id, processperiod_id, energyuse_id) FROM stdin;
\.


--
-- Name: processperiods_processperiod_significant_energyuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('processperiods_processperiod_significant_energyuses_id_seq', 1, false);


--
-- Data for Name: processperiods_processperiodgoal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY processperiods_processperiodgoal (id, energyperformance_id, baseline_from_date, baseline_to_date, reduction_percent, processperiod_id) FROM stdin;
\.


--
-- Name: processperiods_processperiodgoal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('processperiods_processperiodgoal_id_seq', 1, false);


--
-- Data for Name: productions_nonpulseperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY productions_nonpulseperiod (period_ptr_id, datasource_id) FROM stdin;
\.


--
-- Data for Name: productions_offlinetolerance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY productions_offlinetolerance (id, hours, datasequence_id) FROM stdin;
\.


--
-- Name: productions_offlinetolerance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('productions_offlinetolerance_id_seq', 1, false);


--
-- Data for Name: productions_period; Type: TABLE DATA; Schema: public; Owner: -
--

COPY productions_period (id, subclass_id, from_timestamp, to_timestamp, datasequence_id) FROM stdin;
\.


--
-- Name: productions_period_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('productions_period_id_seq', 1, false);


--
-- Data for Name: productions_production; Type: TABLE DATA; Schema: public; Owner: -
--

COPY productions_production (id, encryption_data_initialization_vector, subclass_id, customer_id, name, unit) FROM stdin;
\.


--
-- Name: productions_production_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('productions_production_id_seq', 1, false);


--
-- Data for Name: productions_productiongroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY productions_productiongroup (id, encryption_data_initialization_vector, customer_id, name, description, unit) FROM stdin;
\.


--
-- Name: productions_productiongroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('productions_productiongroup_id_seq', 1, false);


--
-- Data for Name: productions_productiongroup_productions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY productions_productiongroup_productions (id, productiongroup_id, production_id) FROM stdin;
\.


--
-- Name: productions_productiongroup_productions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('productions_productiongroup_productions_id_seq', 1, false);


--
-- Data for Name: productions_pulseperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY productions_pulseperiod (period_ptr_id, datasource_id, pulse_quantity, output_quantity, output_unit) FROM stdin;
\.


--
-- Data for Name: productions_singlevalueperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY productions_singlevalueperiod (period_ptr_id, value, unit) FROM stdin;
\.


--
-- Data for Name: products_historicalproduct; Type: TABLE DATA; Schema: public; Owner: -
--

COPY products_historicalproduct (id, encryption_data_initialization_vector, provider_id, supplier_id, category_id, part_number, name, description, price, monthly_license, installation_type_id, preconfigured_gateway, discontinued, product_id, "timestamp", user_id) FROM stdin;
\.


--
-- Name: products_historicalproduct_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('products_historicalproduct_id_seq', 1, false);


--
-- Data for Name: products_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY products_product (id, encryption_data_initialization_vector, provider_id, supplier_id, category_id, part_number, name, description, price, monthly_license, installation_type_id, preconfigured_gateway, discontinued) FROM stdin;
\.


--
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('products_product_id_seq', 1, false);


--
-- Data for Name: products_productcategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY products_productcategory (id, encryption_data_initialization_vector, provider_id, name) FROM stdin;
\.


--
-- Name: products_productcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('products_productcategory_id_seq', 1, false);


--
-- Data for Name: projects_additionalsaving; Type: TABLE DATA; Schema: public; Owner: -
--

COPY projects_additionalsaving (id, encryption_data_initialization_vector, project_id, description, before_energy, after_energy, before_cost, after_cost, before_co2, after_co2, energy_unit) FROM stdin;
\.


--
-- Name: projects_additionalsaving_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('projects_additionalsaving_id_seq', 1, false);


--
-- Data for Name: projects_benchmarkproject; Type: TABLE DATA; Schema: public; Owner: -
--

COPY projects_benchmarkproject (id, encryption_data_initialization_vector, name, customer_id, background, expectations, actions, subsidy, result, comments, runtime, estimated_yearly_consumption_costs_before, estimated_yearly_consumption_before, estimated_co2_emissions_before, expected_savings_in_yearly_total_costs, expected_savings_in_yearly_consumption_after, expected_reduction_in_yearly_co2_emissions, utility_type, include_measured_costs, baseline_from_timestamp, baseline_to_timestamp, result_from_timestamp, result_to_timestamp) FROM stdin;
\.


--
-- Data for Name: projects_benchmarkproject_baseline_measurement_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY projects_benchmarkproject_baseline_measurement_points (id, benchmarkproject_id, consumptionmeasurementpoint_id) FROM stdin;
\.


--
-- Name: projects_benchmarkproject_baseline_measurement_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('projects_benchmarkproject_baseline_measurement_points_id_seq', 1, false);


--
-- Name: projects_benchmarkproject_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('projects_benchmarkproject_id_seq', 1, false);


--
-- Data for Name: projects_benchmarkproject_result_measurement_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY projects_benchmarkproject_result_measurement_points (id, benchmarkproject_id, consumptionmeasurementpoint_id) FROM stdin;
\.


--
-- Name: projects_benchmarkproject_result_measurement_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('projects_benchmarkproject_result_measurement_points_id_seq', 1, false);


--
-- Data for Name: projects_cost; Type: TABLE DATA; Schema: public; Owner: -
--

COPY projects_cost (id, encryption_data_initialization_vector, project_id, description, cost, amortization_period, interest_rate, scrap_value) FROM stdin;
\.


--
-- Name: projects_cost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('projects_cost_id_seq', 1, false);


--
-- Data for Name: provider_datasources_providerdatasource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY provider_datasources_providerdatasource (datasource_ptr_id, provider_id) FROM stdin;
\.


--
-- Data for Name: providers_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY providers_provider (id, encryption_data_initialization_vector, name, address, zipcode, city, cvr, logo) FROM stdin;
\.


--
-- Name: providers_provider_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('providers_provider_id_seq', 1, false);


--
-- Data for Name: reports_report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY reports_report (id, encryption_data_initialization_vector, customer_id, title, generation_time, data_format, data, size) FROM stdin;
\.


--
-- Name: reports_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('reports_report_id_seq', 1, false);


--
-- Data for Name: rules_dateexception; Type: TABLE DATA; Schema: public; Owner: -
--

COPY rules_dateexception (id, rule_id, from_date, to_date) FROM stdin;
\.


--
-- Name: rules_dateexception_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('rules_dateexception_id_seq', 1, false);


--
-- Data for Name: rules_emailaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY rules_emailaction (id, rule_id, execution_time, recipient, message) FROM stdin;
\.


--
-- Name: rules_emailaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('rules_emailaction_id_seq', 1, false);


--
-- Data for Name: rules_indexinvariant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY rules_indexinvariant (id, rule_id, operator, unit, index_id, value) FROM stdin;
\.


--
-- Name: rules_indexinvariant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('rules_indexinvariant_id_seq', 1, false);


--
-- Data for Name: rules_inputinvariant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY rules_inputinvariant (id, rule_id, operator, unit, data_series_id, value) FROM stdin;
\.


--
-- Name: rules_inputinvariant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('rules_inputinvariant_id_seq', 1, false);


--
-- Data for Name: rules_minimizerule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY rules_minimizerule (userrule_ptr_id, consecutive, activity_duration, index_id) FROM stdin;
\.


--
-- Data for Name: rules_phoneaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY rules_phoneaction (id, rule_id, execution_time, phone_number, message) FROM stdin;
\.


--
-- Name: rules_phoneaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('rules_phoneaction_id_seq', 1, false);


--
-- Data for Name: rules_relayaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY rules_relayaction (id, rule_id, execution_time, meter_id, relay_action) FROM stdin;
\.


--
-- Name: rules_relayaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('rules_relayaction_id_seq', 1, false);


--
-- Data for Name: rules_triggeredrule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY rules_triggeredrule (userrule_ptr_id) FROM stdin;
\.


--
-- Data for Name: rules_userrule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY rules_userrule (id, encryption_data_initialization_vector, customer_id, name, enabled, timezone, monday, tuesday, wednesday, thursday, friday, saturday, sunday, from_time, to_time, content_type_id) FROM stdin;
\.


--
-- Name: rules_userrule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('rules_userrule_id_seq', 1, false);


--
-- Data for Name: salesopportunities_activityentry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY salesopportunities_activityentry (id, encryption_data_initialization_vector, created, salesopportunity_id, creator_id, "timestamp", title, comment) FROM stdin;
\.


--
-- Name: salesopportunities_activityentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('salesopportunities_activityentry_id_seq', 1, false);


--
-- Data for Name: salesopportunities_industrytype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY salesopportunities_industrytype (id, name) FROM stdin;
\.


--
-- Name: salesopportunities_industrytype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('salesopportunities_industrytype_id_seq', 1, false);


--
-- Data for Name: salesopportunities_industrytypesavings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY salesopportunities_industrytypesavings (id, expected, guaranteed, industry_type_id, energy_group) FROM stdin;
\.


--
-- Name: salesopportunities_industrytypesavings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('salesopportunities_industrytypesavings_id_seq', 1, false);


--
-- Data for Name: salesopportunities_industrytypeusedistribution; Type: TABLE DATA; Schema: public; Owner: -
--

COPY salesopportunities_industrytypeusedistribution (id, boiler_network_losses, heating_cooking, drying, evaporation, distillation, roasting_sintering, melting_casting, other_heating_up_to_150, other_heating_above_150, work_driving, lighting, pumping, refrigerators_freezers, ventilation_fans, compressed_air_process_air, partitioning, stirring, other_electric_motors, computers_electronics, other_electricity_use, space_heating, industry_type_id, energy_group) FROM stdin;
\.


--
-- Name: salesopportunities_industrytypeusedistribution_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('salesopportunities_industrytypeusedistribution_id_seq', 1, false);


--
-- Data for Name: salesopportunities_salesopportunity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY salesopportunities_salesopportunity (id, encryption_data_initialization_vector, created, modified, status, customer_id, description, industry_type_id, solid_fuel_yearly_cost, solid_fuel_cost_kwh, liquid_fuel_yearly_cost, liquid_fuel_cost_kwh, gas_yearly_cost, gas_cost_kwh, electricity_yearly_cost, electricity_cost_kwh, district_heating_yearly_cost, district_heating_cost_kwh, water_yearly_cost, water_cost_m3, investment_percent, investment_payback_years, sizing_officer_id, sales_officer_id, expected_closed, interest_rate, scrap_value, life_in_months, gate_closed, technical_contact_name, technical_contact_email, technical_contact_phone, monitors, monitors_notes, tablets, tablets_notes, internet_connection, meters_notes, survey_notes, energy_savings_currency_kwh, contract_life_in_months, contract_budget, contract_interest_rate, likelihood_of_closing_sale, created_by_id, installation_notes) FROM stdin;
\.


--
-- Data for Name: salesopportunities_salesopportunity_floorplans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY salesopportunities_salesopportunity_floorplans (id, salesopportunity_id, floorplan_id) FROM stdin;
\.


--
-- Name: salesopportunities_salesopportunity_floorplans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('salesopportunities_salesopportunity_floorplans_id_seq', 1, false);


--
-- Name: salesopportunities_salesopportunity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('salesopportunities_salesopportunity_id_seq', 1, false);


--
-- Data for Name: salesopportunities_salesopportunitysavings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY salesopportunities_salesopportunitysavings (id, expected, guaranteed, sales_opportunity_id, energy_group) FROM stdin;
\.


--
-- Name: salesopportunities_salesopportunitysavings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('salesopportunities_salesopportunitysavings_id_seq', 1, false);


--
-- Data for Name: salesopportunities_salesopportunityusedistribution; Type: TABLE DATA; Schema: public; Owner: -
--

COPY salesopportunities_salesopportunityusedistribution (id, boiler_network_losses, heating_cooking, drying, evaporation, distillation, roasting_sintering, melting_casting, other_heating_up_to_150, other_heating_above_150, work_driving, lighting, pumping, refrigerators_freezers, ventilation_fans, compressed_air_process_air, partitioning, stirring, other_electric_motors, computers_electronics, other_electricity_use, space_heating, sales_opportunity_id, energy_group) FROM stdin;
\.


--
-- Name: salesopportunities_salesopportunityusedistribution_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('salesopportunities_salesopportunityusedistribution_id_seq', 1, false);


--
-- Data for Name: salesopportunities_surveyinstruction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY salesopportunities_surveyinstruction (id, encryption_data_initialization_vector, sales_opportunity_id, use, electricity, fuel, district_heating, water, notes) FROM stdin;
\.


--
-- Name: salesopportunities_surveyinstruction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('salesopportunities_surveyinstruction_id_seq', 1, false);


--
-- Data for Name: salesopportunities_task; Type: TABLE DATA; Schema: public; Owner: -
--

COPY salesopportunities_task (id, encryption_data_initialization_vector, sales_opportunity_id, date, assigned_id, description, completed, completed_datetime) FROM stdin;
\.


--
-- Name: salesopportunities_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('salesopportunities_task_id_seq', 1, false);


--
-- Data for Name: south_migrationhistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY south_migrationhistory (id, app_name, migration, applied) FROM stdin;
1	djcelery	0001_initial	2014-10-27 12:20:14.160141+01
2	djcelery	0002_v25_changes	2014-10-27 12:20:14.164325+01
3	djcelery	0003_v26_changes	2014-10-27 12:20:14.167483+01
4	djcelery	0004_v30_changes	2014-10-27 12:20:14.175304+01
\.


--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('south_migrationhistory_id_seq', 4, true);


--
-- Data for Name: suppliers_supplier; Type: TABLE DATA; Schema: public; Owner: -
--

COPY suppliers_supplier (id, encryption_data_initialization_vector, provider_id, name) FROM stdin;
\.


--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('suppliers_supplier_id_seq', 1, false);


--
-- Data for Name: system_health_site_healthreport; Type: TABLE DATA; Schema: public; Owner: -
--

COPY system_health_site_healthreport (id, created, modified, customer_id, from_date, to_date, data) FROM stdin;
\.


--
-- Name: system_health_site_healthreport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('system_health_site_healthreport_id_seq', 1, false);


--
-- Data for Name: tariffs_energytariff; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tariffs_energytariff (tariff_ptr_id) FROM stdin;
\.


--
-- Data for Name: tariffs_fixedpriceperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tariffs_fixedpriceperiod (period_ptr_id, subscription_fee, subscription_period, value, unit) FROM stdin;
\.


--
-- Data for Name: tariffs_period; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tariffs_period (id, subclass_id, from_timestamp, to_timestamp, datasequence_id) FROM stdin;
\.


--
-- Name: tariffs_period_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('tariffs_period_id_seq', 1, false);


--
-- Data for Name: tariffs_spotpriceperiod; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tariffs_spotpriceperiod (period_ptr_id, subscription_fee, subscription_period, spotprice_id, coefficient, unit_for_constant_and_ceiling, constant, ceiling) FROM stdin;
\.


--
-- Data for Name: tariffs_tariff; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tariffs_tariff (id, encryption_data_initialization_vector, subclass_id, customer_id, name) FROM stdin;
\.


--
-- Name: tariffs_tariff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('tariffs_tariff_id_seq', 1, false);


--
-- Data for Name: tariffs_volumetariff; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tariffs_volumetariff (tariff_ptr_id) FROM stdin;
\.


--
-- Data for Name: token_auth_tokendata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY token_auth_tokendata (key, user_id, cipher) FROM stdin;
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users_user (user_ptr_id, encryption_data_initialization_vector, encryption_public_key, encryption_private_key, encryption_key_initialization_vector, user_type, e_mail, phone, mobile, name, customer_id, provider_id) FROM stdin;
\.


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: celery_taskmeta_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY celery_taskmeta
    ADD CONSTRAINT celery_taskmeta_pkey PRIMARY KEY (id);


--
-- Name: celery_taskmeta_task_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY celery_taskmeta
    ADD CONSTRAINT celery_taskmeta_task_id_key UNIQUE (task_id);


--
-- Name: celery_tasksetmeta_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY celery_tasksetmeta
    ADD CONSTRAINT celery_tasksetmeta_pkey PRIMARY KEY (id);


--
-- Name: celery_tasksetmeta_taskset_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY celery_tasksetmeta
    ADD CONSTRAINT celery_tasksetmeta_taskset_id_key UNIQUE (taskset_id);


--
-- Name: co2conversions_co2conversion_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY co2conversions_co2conversion
    ADD CONSTRAINT co2conversions_co2conversion_pkey PRIMARY KEY (id);


--
-- Name: co2conversions_dynamicco2conversion_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY co2conversions_dynamicco2conversion
    ADD CONSTRAINT co2conversions_dynamicco2conversion_pkey PRIMARY KEY (co2conversion_ptr_id);


--
-- Name: co2conversions_fixedco2conversion_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY co2conversions_fixedco2conversion
    ADD CONSTRAINT co2conversions_fixedco2conversion_pkey PRIMARY KEY (co2conversion_ptr_id);


--
-- Name: condensing_fiveminuteaccumulateddat_datasource_id_timestamp_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY condensing_fiveminuteaccumulateddata
    ADD CONSTRAINT condensing_fiveminuteaccumulateddat_datasource_id_timestamp_key UNIQUE (datasource_id, "timestamp");


--
-- Name: condensing_fiveminuteaccumulateddata_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY condensing_fiveminuteaccumulateddata
    ADD CONSTRAINT condensing_fiveminuteaccumulateddata_pkey PRIMARY KEY (id);


--
-- Name: condensing_houraccumulateddata_datasource_id_timestamp_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY condensing_houraccumulateddata
    ADD CONSTRAINT condensing_houraccumulateddata_datasource_id_timestamp_key UNIQUE (datasource_id, "timestamp");


--
-- Name: condensing_houraccumulateddata_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY condensing_houraccumulateddata
    ADD CONSTRAINT condensing_houraccumulateddata_pkey PRIMARY KEY (id);


--
-- Name: consumptions_consumption_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_consumption
    ADD CONSTRAINT consumptions_consumption_pkey PRIMARY KEY (id);


--
-- Name: consumptions_consumptiongroup_consumptiongroup_id_consumpti_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_consumptiongroup_consumptions
    ADD CONSTRAINT consumptions_consumptiongroup_consumptiongroup_id_consumpti_key UNIQUE (consumptiongroup_id, consumption_id);


--
-- Name: consumptions_consumptiongroup_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_consumptiongroup_consumptions
    ADD CONSTRAINT consumptions_consumptiongroup_consumptions_pkey PRIMARY KEY (id);


--
-- Name: consumptions_consumptiongroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_consumptiongroup
    ADD CONSTRAINT consumptions_consumptiongroup_pkey PRIMARY KEY (id);


--
-- Name: consumptions_mainconsumption__mainconsumption_id_consumptio_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_mainconsumption_consumptions
    ADD CONSTRAINT consumptions_mainconsumption__mainconsumption_id_consumptio_key UNIQUE (mainconsumption_id, consumption_id);


--
-- Name: consumptions_mainconsumption_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_mainconsumption_consumptions
    ADD CONSTRAINT consumptions_mainconsumption_consumptions_pkey PRIMARY KEY (id);


--
-- Name: consumptions_mainconsumption_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_mainconsumption
    ADD CONSTRAINT consumptions_mainconsumption_pkey PRIMARY KEY (id);


--
-- Name: consumptions_nonpulseperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_nonpulseperiod
    ADD CONSTRAINT consumptions_nonpulseperiod_pkey PRIMARY KEY (period_ptr_id);


--
-- Name: consumptions_offlinetolerance_datasequence_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_offlinetolerance
    ADD CONSTRAINT consumptions_offlinetolerance_datasequence_id_key UNIQUE (datasequence_id);


--
-- Name: consumptions_offlinetolerance_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_offlinetolerance
    ADD CONSTRAINT consumptions_offlinetolerance_pkey PRIMARY KEY (id);


--
-- Name: consumptions_period_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_period
    ADD CONSTRAINT consumptions_period_pkey PRIMARY KEY (id);


--
-- Name: consumptions_pulseperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_pulseperiod
    ADD CONSTRAINT consumptions_pulseperiod_pkey PRIMARY KEY (period_ptr_id);


--
-- Name: consumptions_singlevalueperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY consumptions_singlevalueperiod
    ADD CONSTRAINT consumptions_singlevalueperiod_pkey PRIMARY KEY (period_ptr_id);


--
-- Name: corsheaders_corsmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY corsheaders_corsmodel
    ADD CONSTRAINT corsheaders_corsmodel_pkey PRIMARY KEY (id);


--
-- Name: cost_compensations_costcompensation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY cost_compensations_costcompensation
    ADD CONSTRAINT cost_compensations_costcompensation_pkey PRIMARY KEY (id);


--
-- Name: cost_compensations_fixedcompensationperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY cost_compensations_fixedcompensationperiod
    ADD CONSTRAINT cost_compensations_fixedcompensationperiod_pkey PRIMARY KEY (period_ptr_id);


--
-- Name: cost_compensations_period_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY cost_compensations_period
    ADD CONSTRAINT cost_compensations_period_pkey PRIMARY KEY (id);


--
-- Name: customer_datasources_customerdatasource_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY customer_datasources_customerdatasource
    ADD CONSTRAINT customer_datasources_customerdatasource_pkey PRIMARY KEY (datasource_ptr_id);


--
-- Name: customers_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY customers_collection
    ADD CONSTRAINT customers_collection_pkey PRIMARY KEY (id);


--
-- Name: customers_customer_industry_typ_customer_id_industrytype_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY customers_customer_industry_types
    ADD CONSTRAINT customers_customer_industry_typ_customer_id_industrytype_id_key UNIQUE (customer_id, industrytype_id);


--
-- Name: customers_customer_industry_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY customers_customer_industry_types
    ADD CONSTRAINT customers_customer_industry_types_pkey PRIMARY KEY (id);


--
-- Name: customers_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY customers_customer
    ADD CONSTRAINT customers_customer_pkey PRIMARY KEY (id);


--
-- Name: customers_location_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY customers_location
    ADD CONSTRAINT customers_location_pkey PRIMARY KEY (id);


--
-- Name: customers_userprofile_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY customers_userprofile_collections
    ADD CONSTRAINT customers_userprofile_collections_pkey PRIMARY KEY (id);


--
-- Name: customers_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY customers_userprofile
    ADD CONSTRAINT customers_userprofile_pkey PRIMARY KEY (id);


--
-- Name: customers_userprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY customers_userprofile
    ADD CONSTRAINT customers_userprofile_user_id_key UNIQUE (user_id);


--
-- Name: dataneeds_dataneed_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dataneeds_dataneed
    ADD CONSTRAINT dataneeds_dataneed_pkey PRIMARY KEY (id);


--
-- Name: dataneeds_energyusedataneed_energyuse_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dataneeds_energyusedataneed
    ADD CONSTRAINT dataneeds_energyusedataneed_energyuse_id_key UNIQUE (energyuse_id);


--
-- Name: dataneeds_energyusedataneed_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dataneeds_energyusedataneed
    ADD CONSTRAINT dataneeds_energyusedataneed_pkey PRIMARY KEY (dataneed_ptr_id);


--
-- Name: dataneeds_mainconsumptiondataneed_mainconsumption_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dataneeds_mainconsumptiondataneed
    ADD CONSTRAINT dataneeds_mainconsumptiondataneed_mainconsumption_id_key UNIQUE (mainconsumption_id);


--
-- Name: dataneeds_mainconsumptiondataneed_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dataneeds_mainconsumptiondataneed
    ADD CONSTRAINT dataneeds_mainconsumptiondataneed_pkey PRIMARY KEY (dataneed_ptr_id);


--
-- Name: dataneeds_productiongroupdataneed_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dataneeds_productiongroupdataneed
    ADD CONSTRAINT dataneeds_productiongroupdataneed_pkey PRIMARY KEY (dataneed_ptr_id);


--
-- Name: dataneeds_productiongroupdataneed_productiongroup_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dataneeds_productiongroupdataneed
    ADD CONSTRAINT dataneeds_productiongroupdataneed_productiongroup_id_key UNIQUE (productiongroup_id);


--
-- Name: datasequence_adapters_consumptionaccumulationadapter_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY datasequence_adapters_consumptionaccumulationadapter
    ADD CONSTRAINT datasequence_adapters_consumptionaccumulationadapter_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: datasequence_adapters_nonaccumulationadapter_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY datasequence_adapters_nonaccumulationadapter
    ADD CONSTRAINT datasequence_adapters_nonaccumulationadapter_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: datasequence_adapters_productionaccumulationadapter_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY datasequence_adapters_productionaccumulationadapter
    ADD CONSTRAINT datasequence_adapters_productionaccumulationadapter_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: datasequences_energypervolumedatasequence_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY datasequences_energypervolumedatasequence
    ADD CONSTRAINT datasequences_energypervolumedatasequence_pkey PRIMARY KEY (id);


--
-- Name: datasequences_energypervolumeperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY datasequences_energypervolumeperiod
    ADD CONSTRAINT datasequences_energypervolumeperiod_pkey PRIMARY KEY (id);


--
-- Name: datasequences_nonaccumulationdatasequence_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY datasequences_nonaccumulationdatasequence
    ADD CONSTRAINT datasequences_nonaccumulationdatasequence_pkey PRIMARY KEY (id);


--
-- Name: datasequences_nonaccumulationofflinetoleran_datasequence_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY datasequences_nonaccumulationofflinetolerance
    ADD CONSTRAINT datasequences_nonaccumulationofflinetoleran_datasequence_id_key UNIQUE (datasequence_id);


--
-- Name: datasequences_nonaccumulationofflinetolerance_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY datasequences_nonaccumulationofflinetolerance
    ADD CONSTRAINT datasequences_nonaccumulationofflinetolerance_pkey PRIMARY KEY (id);


--
-- Name: datasequences_nonaccumulationperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY datasequences_nonaccumulationperiod
    ADD CONSTRAINT datasequences_nonaccumulationperiod_pkey PRIMARY KEY (id);


--
-- Name: datasources_datasource_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY datasources_datasource
    ADD CONSTRAINT datasources_datasource_pkey PRIMARY KEY (id);


--
-- Name: datasources_rawdata_datasource_id_timestamp_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY datasources_rawdata
    ADD CONSTRAINT datasources_rawdata_datasource_id_timestamp_key UNIQUE (datasource_id, "timestamp");


--
-- Name: datasources_rawdata_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY datasources_rawdata
    ADD CONSTRAINT datasources_rawdata_pkey PRIMARY KEY (id);


--
-- Name: devices_agent_mac_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY devices_agent
    ADD CONSTRAINT devices_agent_mac_key UNIQUE (mac);


--
-- Name: devices_agent_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY devices_agent
    ADD CONSTRAINT devices_agent_pkey PRIMARY KEY (id);


--
-- Name: devices_agentevent_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY devices_agentevent
    ADD CONSTRAINT devices_agentevent_pkey PRIMARY KEY (id);


--
-- Name: devices_agentstatechange_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY devices_agentstatechange
    ADD CONSTRAINT devices_agentstatechange_pkey PRIMARY KEY (id);


--
-- Name: devices_meter_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY devices_meter
    ADD CONSTRAINT devices_meter_pkey PRIMARY KEY (id);


--
-- Name: devices_meterstatechange_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY devices_meterstatechange
    ADD CONSTRAINT devices_meterstatechange_pkey PRIMARY KEY (id);


--
-- Name: devices_physicalinput_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY devices_physicalinput
    ADD CONSTRAINT devices_physicalinput_pkey PRIMARY KEY (customerdatasource_ptr_id);


--
-- Name: devices_softwareimage_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY devices_softwareimage
    ADD CONSTRAINT devices_softwareimage_pkey PRIMARY KEY (id);


--
-- Name: display_widgets_dashboardwidget_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY display_widgets_dashboardwidget
    ADD CONSTRAINT display_widgets_dashboardwidget_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_model_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: djcelery_crontabschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_crontabschedule
    ADD CONSTRAINT djcelery_crontabschedule_pkey PRIMARY KEY (id);


--
-- Name: djcelery_intervalschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_intervalschedule
    ADD CONSTRAINT djcelery_intervalschedule_pkey PRIMARY KEY (id);


--
-- Name: djcelery_periodictask_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_periodictask
    ADD CONSTRAINT djcelery_periodictask_name_key UNIQUE (name);


--
-- Name: djcelery_periodictask_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_periodictask
    ADD CONSTRAINT djcelery_periodictask_pkey PRIMARY KEY (id);


--
-- Name: djcelery_periodictasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_periodictasks
    ADD CONSTRAINT djcelery_periodictasks_pkey PRIMARY KEY (ident);


--
-- Name: djcelery_taskstate_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_taskstate
    ADD CONSTRAINT djcelery_taskstate_pkey PRIMARY KEY (id);


--
-- Name: djcelery_taskstate_task_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_taskstate
    ADD CONSTRAINT djcelery_taskstate_task_id_key UNIQUE (task_id);


--
-- Name: djcelery_workerstate_hostname_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_workerstate
    ADD CONSTRAINT djcelery_workerstate_hostname_key UNIQUE (hostname);


--
-- Name: djcelery_workerstate_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY djcelery_workerstate
    ADD CONSTRAINT djcelery_workerstate_pkey PRIMARY KEY (id);


--
-- Name: encryption_encryptionkey_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY encryption_encryptionkey
    ADD CONSTRAINT encryption_encryptionkey_pkey PRIMARY KEY (id);


--
-- Name: energinet_co2_modelbinding_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energinet_co2_modelbinding
    ADD CONSTRAINT energinet_co2_modelbinding_pkey PRIMARY KEY (id);


--
-- Name: energy_breakdown_districtheatingconsump_salesopportunity_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_districtheatingconsumptiontotal
    ADD CONSTRAINT energy_breakdown_districtheatingconsump_salesopportunity_id_key UNIQUE (salesopportunity_id);


--
-- Name: energy_breakdown_districtheatingconsumptio_energyusearea_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_districtheatingconsumptionarea
    ADD CONSTRAINT energy_breakdown_districtheatingconsumptio_energyusearea_id_key UNIQUE (energyusearea_id);


--
-- Name: energy_breakdown_districtheatingconsumptionarea_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_districtheatingconsumptionarea
    ADD CONSTRAINT energy_breakdown_districtheatingconsumptionarea_pkey PRIMARY KEY (id);


--
-- Name: energy_breakdown_districtheatingconsumptiontotal_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_districtheatingconsumptiontotal
    ADD CONSTRAINT energy_breakdown_districtheatingconsumptiontotal_pkey PRIMARY KEY (id);


--
-- Name: energy_breakdown_electricityconsumption_salesopportunity_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_electricityconsumptiontotal
    ADD CONSTRAINT energy_breakdown_electricityconsumption_salesopportunity_id_key UNIQUE (salesopportunity_id);


--
-- Name: energy_breakdown_electricityconsumptionare_energyusearea_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_electricityconsumptionarea
    ADD CONSTRAINT energy_breakdown_electricityconsumptionare_energyusearea_id_key UNIQUE (energyusearea_id);


--
-- Name: energy_breakdown_electricityconsumptionarea_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_electricityconsumptionarea
    ADD CONSTRAINT energy_breakdown_electricityconsumptionarea_pkey PRIMARY KEY (id);


--
-- Name: energy_breakdown_electricityconsumptiontotal_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_electricityconsumptiontotal
    ADD CONSTRAINT energy_breakdown_electricityconsumptiontotal_pkey PRIMARY KEY (id);


--
-- Name: energy_breakdown_fuelconsumptionarea_energyusearea_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_fuelconsumptionarea
    ADD CONSTRAINT energy_breakdown_fuelconsumptionarea_energyusearea_id_key UNIQUE (energyusearea_id);


--
-- Name: energy_breakdown_fuelconsumptionarea_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_fuelconsumptionarea
    ADD CONSTRAINT energy_breakdown_fuelconsumptionarea_pkey PRIMARY KEY (id);


--
-- Name: energy_breakdown_fuelconsumptiontotal_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_fuelconsumptiontotal
    ADD CONSTRAINT energy_breakdown_fuelconsumptiontotal_pkey PRIMARY KEY (id);


--
-- Name: energy_breakdown_fuelconsumptiontotal_salesopportunity_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_fuelconsumptiontotal
    ADD CONSTRAINT energy_breakdown_fuelconsumptiontotal_salesopportunity_id_key UNIQUE (salesopportunity_id);


--
-- Name: energy_breakdown_proposedaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_proposedaction
    ADD CONSTRAINT energy_breakdown_proposedaction_pkey PRIMARY KEY (id);


--
-- Name: energy_breakdown_waterconsumptionarea_energyusearea_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_waterconsumptionarea
    ADD CONSTRAINT energy_breakdown_waterconsumptionarea_energyusearea_id_key UNIQUE (energyusearea_id);


--
-- Name: energy_breakdown_waterconsumptionarea_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_waterconsumptionarea
    ADD CONSTRAINT energy_breakdown_waterconsumptionarea_pkey PRIMARY KEY (id);


--
-- Name: energy_breakdown_waterconsumptiontotal_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_waterconsumptiontotal
    ADD CONSTRAINT energy_breakdown_waterconsumptiontotal_pkey PRIMARY KEY (id);


--
-- Name: energy_breakdown_waterconsumptiontotal_salesopportunity_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_breakdown_waterconsumptiontotal
    ADD CONSTRAINT energy_breakdown_waterconsumptiontotal_salesopportunity_id_key UNIQUE (salesopportunity_id);


--
-- Name: energy_use_reports_energyusea_energyusearea_id_consumptionm_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_use_reports_energyusearea_measurement_points
    ADD CONSTRAINT energy_use_reports_energyusea_energyusearea_id_consumptionm_key UNIQUE (energyusearea_id, consumptionmeasurementpoint_id);


--
-- Name: energy_use_reports_energyusearea_measurement_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_use_reports_energyusearea_measurement_points
    ADD CONSTRAINT energy_use_reports_energyusearea_measurement_points_pkey PRIMARY KEY (id);


--
-- Name: energy_use_reports_energyusearea_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_use_reports_energyusearea
    ADD CONSTRAINT energy_use_reports_energyusearea_pkey PRIMARY KEY (id);


--
-- Name: energy_use_reports_energyuser_energyusereport_id_consumptio_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_use_reports_energyusereport_main_measurement_points
    ADD CONSTRAINT energy_use_reports_energyuser_energyusereport_id_consumptio_key UNIQUE (energyusereport_id, consumptionmeasurementpoint_id);


--
-- Name: energy_use_reports_energyusereport_main_measurement_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_use_reports_energyusereport_main_measurement_points
    ADD CONSTRAINT energy_use_reports_energyusereport_main_measurement_points_pkey PRIMARY KEY (id);


--
-- Name: energy_use_reports_energyusereport_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energy_use_reports_energyusereport
    ADD CONSTRAINT energy_use_reports_energyusereport_pkey PRIMARY KEY (id);


--
-- Name: energyperformances_energyperformance_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energyperformances_energyperformance
    ADD CONSTRAINT energyperformances_energyperformance_pkey PRIMARY KEY (id);


--
-- Name: energyperformances_production_productionenergyperformance__key1; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energyperformances_productionenergyperformance_consumptiong23ca
    ADD CONSTRAINT energyperformances_production_productionenergyperformance__key1 UNIQUE (productionenergyperformance_id, consumptiongroup_id);


--
-- Name: energyperformances_production_productionenergyperformance_i_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energyperformances_productionenergyperformance_productiongroups
    ADD CONSTRAINT energyperformances_production_productionenergyperformance_i_key UNIQUE (productionenergyperformance_id, productiongroup_id);


--
-- Name: energyperformances_productionenergyperformance_consumption_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energyperformances_productionenergyperformance_consumptiong23ca
    ADD CONSTRAINT energyperformances_productionenergyperformance_consumption_pkey PRIMARY KEY (id);


--
-- Name: energyperformances_productionenergyperformance_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energyperformances_productionenergyperformance
    ADD CONSTRAINT energyperformances_productionenergyperformance_pkey PRIMARY KEY (energyperformance_ptr_id);


--
-- Name: energyperformances_productionenergyperformance_productiong_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energyperformances_productionenergyperformance_productiongroups
    ADD CONSTRAINT energyperformances_productionenergyperformance_productiong_pkey PRIMARY KEY (id);


--
-- Name: energyperformances_timeenergy_timeenergyperformance_id_cons_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energyperformances_timeenergyperformance_consumptiongroups
    ADD CONSTRAINT energyperformances_timeenergy_timeenergyperformance_id_cons_key UNIQUE (timeenergyperformance_id, consumptiongroup_id);


--
-- Name: energyperformances_timeenergyperformance_consumptiongroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energyperformances_timeenergyperformance_consumptiongroups
    ADD CONSTRAINT energyperformances_timeenergyperformance_consumptiongroups_pkey PRIMARY KEY (id);


--
-- Name: energyperformances_timeenergyperformance_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energyperformances_timeenergyperformance
    ADD CONSTRAINT energyperformances_timeenergyperformance_pkey PRIMARY KEY (energyperformance_ptr_id);


--
-- Name: energyuses_energyuse_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY energyuses_energyuse
    ADD CONSTRAINT energyuses_energyuse_pkey PRIMARY KEY (consumptiongroup_ptr_id);


--
-- Name: enpi_reports_enpireport_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY enpi_reports_enpireport
    ADD CONSTRAINT enpi_reports_enpireport_pkey PRIMARY KEY (id);


--
-- Name: enpi_reports_enpiusearea_meas_enpiusearea_id_consumptionmea_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY enpi_reports_enpiusearea_measurement_points
    ADD CONSTRAINT enpi_reports_enpiusearea_meas_enpiusearea_id_consumptionmea_key UNIQUE (enpiusearea_id, consumptionmeasurementpoint_id);


--
-- Name: enpi_reports_enpiusearea_measurement_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY enpi_reports_enpiusearea_measurement_points
    ADD CONSTRAINT enpi_reports_enpiusearea_measurement_points_pkey PRIMARY KEY (id);


--
-- Name: enpi_reports_enpiusearea_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY enpi_reports_enpiusearea
    ADD CONSTRAINT enpi_reports_enpiusearea_pkey PRIMARY KEY (id);


--
-- Name: global_datasources_globaldatasou_app_label_codename_country_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY global_datasources_globaldatasource
    ADD CONSTRAINT global_datasources_globaldatasou_app_label_codename_country_key UNIQUE (app_label, codename, country);


--
-- Name: global_datasources_globaldatasource_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY global_datasources_globaldatasource
    ADD CONSTRAINT global_datasources_globaldatasource_pkey PRIMARY KEY (datasource_ptr_id);


--
-- Name: indexes_datasourceindexadapter_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY indexes_datasourceindexadapter
    ADD CONSTRAINT indexes_datasourceindexadapter_pkey PRIMARY KEY (index_ptr_id);


--
-- Name: indexes_derivedindexperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY indexes_derivedindexperiod
    ADD CONSTRAINT indexes_derivedindexperiod_pkey PRIMARY KEY (id);


--
-- Name: indexes_entry_index_id_from_timestamp_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY indexes_entry
    ADD CONSTRAINT indexes_entry_index_id_from_timestamp_key UNIQUE (index_id, from_timestamp);


--
-- Name: indexes_entry_index_id_to_timestamp_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY indexes_entry
    ADD CONSTRAINT indexes_entry_index_id_to_timestamp_key UNIQUE (index_id, to_timestamp);


--
-- Name: indexes_entry_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY indexes_entry
    ADD CONSTRAINT indexes_entry_pkey PRIMARY KEY (id);


--
-- Name: indexes_index_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY indexes_index
    ADD CONSTRAINT indexes_index_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: indexes_seasonindexperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY indexes_seasonindexperiod
    ADD CONSTRAINT indexes_seasonindexperiod_pkey PRIMARY KEY (id);


--
-- Name: indexes_spotmapping_index_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY indexes_spotmapping
    ADD CONSTRAINT indexes_spotmapping_index_id_key UNIQUE (index_id);


--
-- Name: indexes_spotmapping_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY indexes_spotmapping
    ADD CONSTRAINT indexes_spotmapping_pkey PRIMARY KEY (id);


--
-- Name: indexes_standardmonthindex_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY indexes_standardmonthindex
    ADD CONSTRAINT indexes_standardmonthindex_pkey PRIMARY KEY (index_ptr_id);


--
-- Name: installation_surveys_billingmeter_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installation_surveys_billingmeter
    ADD CONSTRAINT installation_surveys_billingmeter_pkey PRIMARY KEY (id);


--
-- Name: installation_surveys_billingmeterappendix_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installation_surveys_billingmeterappendix
    ADD CONSTRAINT installation_surveys_billingmeterappendix_pkey PRIMARY KEY (id);


--
-- Name: installation_surveys_energyusearea_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installation_surveys_energyusearea
    ADD CONSTRAINT installation_surveys_energyusearea_pkey PRIMARY KEY (id);


--
-- Name: installation_surveys_proposedaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installation_surveys_proposedaction
    ADD CONSTRAINT installation_surveys_proposedaction_pkey PRIMARY KEY (id);


--
-- Name: installation_surveys_workhours_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installation_surveys_workhours
    ADD CONSTRAINT installation_surveys_workhours_pkey PRIMARY KEY (id);


--
-- Name: installations_floorplan_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_floorplan
    ADD CONSTRAINT installations_floorplan_pkey PRIMARY KEY (id);


--
-- Name: installations_gatewayinstallation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_gatewayinstallation
    ADD CONSTRAINT installations_gatewayinstallation_pkey PRIMARY KEY (productinstallation_ptr_id);


--
-- Name: installations_installationphoto_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_installationphoto
    ADD CONSTRAINT installations_installationphoto_pkey PRIMARY KEY (id);


--
-- Name: installations_meterinstallati_meterinstallation_id_dataneed_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_meterinstallation_input_satisfies_dataneeds
    ADD CONSTRAINT installations_meterinstallati_meterinstallation_id_dataneed_key UNIQUE (meterinstallation_id, dataneed_id);


--
-- Name: installations_meterinstallation_input_satisfies_dataneeds_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_meterinstallation_input_satisfies_dataneeds
    ADD CONSTRAINT installations_meterinstallation_input_satisfies_dataneeds_pkey PRIMARY KEY (id);


--
-- Name: installations_meterinstallation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_meterinstallation
    ADD CONSTRAINT installations_meterinstallation_pkey PRIMARY KEY (productinstallation_ptr_id);


--
-- Name: installations_productinstalla_floorplan_id_installation_num_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_productinstallation
    ADD CONSTRAINT installations_productinstalla_floorplan_id_installation_num_key UNIQUE (floorplan_id, installation_number);


--
-- Name: installations_productinstallation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_productinstallation
    ADD CONSTRAINT installations_productinstallation_pkey PRIMARY KEY (id);


--
-- Name: installations_pulseemitterins_pulseemitterinstallation_id_d_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_pulseemitterinstallation_input_satisfies_data7b36
    ADD CONSTRAINT installations_pulseemitterins_pulseemitterinstallation_id_d_key UNIQUE (pulseemitterinstallation_id, dataneed_id);


--
-- Name: installations_pulseemitterinstallation_input_satisfies_dat_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_pulseemitterinstallation_input_satisfies_data7b36
    ADD CONSTRAINT installations_pulseemitterinstallation_input_satisfies_dat_pkey PRIMARY KEY (id);


--
-- Name: installations_pulseemitterinstallation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_pulseemitterinstallation
    ADD CONSTRAINT installations_pulseemitterinstallation_pkey PRIMARY KEY (productinstallation_ptr_id);


--
-- Name: installations_repeaterinstallation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_repeaterinstallation
    ADD CONSTRAINT installations_repeaterinstallation_pkey PRIMARY KEY (productinstallation_ptr_id);


--
-- Name: installations_tripleinputmete_tripleinputmeterinstallation__key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input3_satisfies9eaa
    ADD CONSTRAINT installations_tripleinputmete_tripleinputmeterinstallation__key UNIQUE (tripleinputmeterinstallation_id, dataneed_id);


--
-- Name: installations_tripleinputmete_tripleinputmeterinstallation_key1; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input2_satisfies1aad
    ADD CONSTRAINT installations_tripleinputmete_tripleinputmeterinstallation_key1 UNIQUE (tripleinputmeterinstallation_id, dataneed_id);


--
-- Name: installations_tripleinputmete_tripleinputmeterinstallation_key2; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input1_satisfies0539
    ADD CONSTRAINT installations_tripleinputmete_tripleinputmeterinstallation_key2 UNIQUE (tripleinputmeterinstallation_id, dataneed_id);


--
-- Name: installations_tripleinputmeterinstallation_input1_satisfie_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input1_satisfies0539
    ADD CONSTRAINT installations_tripleinputmeterinstallation_input1_satisfie_pkey PRIMARY KEY (id);


--
-- Name: installations_tripleinputmeterinstallation_input2_satisfie_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input2_satisfies1aad
    ADD CONSTRAINT installations_tripleinputmeterinstallation_input2_satisfie_pkey PRIMARY KEY (id);


--
-- Name: installations_tripleinputmeterinstallation_input3_satisfie_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input3_satisfies9eaa
    ADD CONSTRAINT installations_tripleinputmeterinstallation_input3_satisfie_pkey PRIMARY KEY (id);


--
-- Name: installations_tripleinputmeterinstallation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation
    ADD CONSTRAINT installations_tripleinputmeterinstallation_pkey PRIMARY KEY (productinstallation_ptr_id);


--
-- Name: installations_triplepulsecollectorinstallation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY installations_triplepulsecollectorinstallation
    ADD CONSTRAINT installations_triplepulsecollectorinstallation_pkey PRIMARY KEY (productinstallation_ptr_id);


--
-- Name: manage_collections_collectionitem_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY manage_collections_collectionitem
    ADD CONSTRAINT manage_collections_collectionitem_pkey PRIMARY KEY (item_ptr_id);


--
-- Name: manage_collections_floorplan_collection_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY manage_collections_floorplan
    ADD CONSTRAINT manage_collections_floorplan_collection_id_key UNIQUE (collection_id);


--
-- Name: manage_collections_floorplan_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY manage_collections_floorplan
    ADD CONSTRAINT manage_collections_floorplan_pkey PRIMARY KEY (id);


--
-- Name: manage_collections_infoitem_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY manage_collections_infoitem
    ADD CONSTRAINT manage_collections_infoitem_pkey PRIMARY KEY (item_ptr_id);


--
-- Name: manage_collections_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY manage_collections_item
    ADD CONSTRAINT manage_collections_item_pkey PRIMARY KEY (id);


--
-- Name: manual_reporting_manuallyreportedconsumption_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY manual_reporting_manuallyreportedconsumption
    ADD CONSTRAINT manual_reporting_manuallyreportedconsumption_pkey PRIMARY KEY (consumption_ptr_id);


--
-- Name: manual_reporting_manuallyreportedproduction_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY manual_reporting_manuallyreportedproduction
    ADD CONSTRAINT manual_reporting_manuallyreportedproduction_pkey PRIMARY KEY (production_ptr_id);


--
-- Name: measurementpoints_chain_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_chain
    ADD CONSTRAINT measurementpoints_chain_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: measurementpoints_chainlink_chain_id_valid_from_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_chainlink
    ADD CONSTRAINT measurementpoints_chainlink_chain_id_valid_from_key UNIQUE (chain_id, valid_from);


--
-- Name: measurementpoints_chainlink_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_chainlink
    ADD CONSTRAINT measurementpoints_chainlink_pkey PRIMARY KEY (id);


--
-- Name: measurementpoints_dataseries_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_dataseries
    ADD CONSTRAINT measurementpoints_dataseries_pkey PRIMARY KEY (id);


--
-- Name: measurementpoints_degreedaycorrection_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_degreedaycorrection
    ADD CONSTRAINT measurementpoints_degreedaycorrection_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: measurementpoints_graph_collection_id_role_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_graph
    ADD CONSTRAINT measurementpoints_graph_collection_id_role_key UNIQUE (collection_id, role);


--
-- Name: measurementpoints_graph_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_graph
    ADD CONSTRAINT measurementpoints_graph_pkey PRIMARY KEY (id);


--
-- Name: measurementpoints_heatingdegreedays_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_heatingdegreedays
    ADD CONSTRAINT measurementpoints_heatingdegreedays_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: measurementpoints_indexcalculation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_indexcalculation
    ADD CONSTRAINT measurementpoints_indexcalculation_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: measurementpoints_link_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_link
    ADD CONSTRAINT measurementpoints_link_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: measurementpoints_meantemperaturechange_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_meantemperaturechange
    ADD CONSTRAINT measurementpoints_meantemperaturechange_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: measurementpoints_multiplication_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_multiplication
    ADD CONSTRAINT measurementpoints_multiplication_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: measurementpoints_piecewiseconstantintegral_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_piecewiseconstantintegral
    ADD CONSTRAINT measurementpoints_piecewiseconstantintegral_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: measurementpoints_rateconversion_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_rateconversion
    ADD CONSTRAINT measurementpoints_rateconversion_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: measurementpoints_simplelinearregression_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_simplelinearregression
    ADD CONSTRAINT measurementpoints_simplelinearregression_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: measurementpoints_storeddata_data_series_id_timestamp_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_storeddata
    ADD CONSTRAINT measurementpoints_storeddata_data_series_id_timestamp_key UNIQUE (data_series_id, "timestamp");


--
-- Name: measurementpoints_storeddata_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_storeddata
    ADD CONSTRAINT measurementpoints_storeddata_pkey PRIMARY KEY (id);


--
-- Name: measurementpoints_summation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_summation
    ADD CONSTRAINT measurementpoints_summation_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: measurementpoints_summationterm_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_summationterm
    ADD CONSTRAINT measurementpoints_summationterm_pkey PRIMARY KEY (id);


--
-- Name: measurementpoints_utilization_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY measurementpoints_utilization
    ADD CONSTRAINT measurementpoints_utilization_pkey PRIMARY KEY (dataseries_ptr_id);


--
-- Name: opportunities_opportunity_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY opportunities_opportunity
    ADD CONSTRAINT opportunities_opportunity_pkey PRIMARY KEY (id);


--
-- Name: processperiods_processperiod__processperiod_id_energyperfor_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY processperiods_processperiod_enpis
    ADD CONSTRAINT processperiods_processperiod__processperiod_id_energyperfor_key UNIQUE (processperiod_id, energyperformance_id);


--
-- Name: processperiods_processperiod__processperiod_id_energyuse_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY processperiods_processperiod_significant_energyuses
    ADD CONSTRAINT processperiods_processperiod__processperiod_id_energyuse_id_key UNIQUE (processperiod_id, energyuse_id);


--
-- Name: processperiods_processperiod__processperiod_id_opportunity__key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY processperiods_processperiod_rejected_opportunities
    ADD CONSTRAINT processperiods_processperiod__processperiod_id_opportunity__key UNIQUE (processperiod_id, opportunity_id);


--
-- Name: processperiods_processperiod__processperiod_id_opportunity_key1; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY processperiods_processperiod_accepted_opportunities
    ADD CONSTRAINT processperiods_processperiod__processperiod_id_opportunity_key1 UNIQUE (processperiod_id, opportunity_id);


--
-- Name: processperiods_processperiod_accepted_opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY processperiods_processperiod_accepted_opportunities
    ADD CONSTRAINT processperiods_processperiod_accepted_opportunities_pkey PRIMARY KEY (id);


--
-- Name: processperiods_processperiod_enpis_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY processperiods_processperiod_enpis
    ADD CONSTRAINT processperiods_processperiod_enpis_pkey PRIMARY KEY (id);


--
-- Name: processperiods_processperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY processperiods_processperiod
    ADD CONSTRAINT processperiods_processperiod_pkey PRIMARY KEY (id);


--
-- Name: processperiods_processperiod_rejected_opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY processperiods_processperiod_rejected_opportunities
    ADD CONSTRAINT processperiods_processperiod_rejected_opportunities_pkey PRIMARY KEY (id);


--
-- Name: processperiods_processperiod_significant_energyuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY processperiods_processperiod_significant_energyuses
    ADD CONSTRAINT processperiods_processperiod_significant_energyuses_pkey PRIMARY KEY (id);


--
-- Name: processperiods_processperiodgoal_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY processperiods_processperiodgoal
    ADD CONSTRAINT processperiods_processperiodgoal_pkey PRIMARY KEY (id);


--
-- Name: productions_nonpulseperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY productions_nonpulseperiod
    ADD CONSTRAINT productions_nonpulseperiod_pkey PRIMARY KEY (period_ptr_id);


--
-- Name: productions_offlinetolerance_datasequence_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY productions_offlinetolerance
    ADD CONSTRAINT productions_offlinetolerance_datasequence_id_key UNIQUE (datasequence_id);


--
-- Name: productions_offlinetolerance_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY productions_offlinetolerance
    ADD CONSTRAINT productions_offlinetolerance_pkey PRIMARY KEY (id);


--
-- Name: productions_period_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY productions_period
    ADD CONSTRAINT productions_period_pkey PRIMARY KEY (id);


--
-- Name: productions_production_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY productions_production
    ADD CONSTRAINT productions_production_pkey PRIMARY KEY (id);


--
-- Name: productions_productiongroup_p_productiongroup_id_production_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY productions_productiongroup_productions
    ADD CONSTRAINT productions_productiongroup_p_productiongroup_id_production_key UNIQUE (productiongroup_id, production_id);


--
-- Name: productions_productiongroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY productions_productiongroup
    ADD CONSTRAINT productions_productiongroup_pkey PRIMARY KEY (id);


--
-- Name: productions_productiongroup_productions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY productions_productiongroup_productions
    ADD CONSTRAINT productions_productiongroup_productions_pkey PRIMARY KEY (id);


--
-- Name: productions_pulseperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY productions_pulseperiod
    ADD CONSTRAINT productions_pulseperiod_pkey PRIMARY KEY (period_ptr_id);


--
-- Name: productions_singlevalueperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY productions_singlevalueperiod
    ADD CONSTRAINT productions_singlevalueperiod_pkey PRIMARY KEY (period_ptr_id);


--
-- Name: products_historicalproduct_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY products_historicalproduct
    ADD CONSTRAINT products_historicalproduct_pkey PRIMARY KEY (id);


--
-- Name: products_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY products_product
    ADD CONSTRAINT products_product_pkey PRIMARY KEY (id);


--
-- Name: products_productcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY products_productcategory
    ADD CONSTRAINT products_productcategory_pkey PRIMARY KEY (id);


--
-- Name: projects_additionalsaving_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY projects_additionalsaving
    ADD CONSTRAINT projects_additionalsaving_pkey PRIMARY KEY (id);


--
-- Name: projects_benchmarkproject_bas_benchmarkproject_id_consumpti_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY projects_benchmarkproject_baseline_measurement_points
    ADD CONSTRAINT projects_benchmarkproject_bas_benchmarkproject_id_consumpti_key UNIQUE (benchmarkproject_id, consumptionmeasurementpoint_id);


--
-- Name: projects_benchmarkproject_baseline_measurement_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY projects_benchmarkproject_baseline_measurement_points
    ADD CONSTRAINT projects_benchmarkproject_baseline_measurement_points_pkey PRIMARY KEY (id);


--
-- Name: projects_benchmarkproject_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY projects_benchmarkproject
    ADD CONSTRAINT projects_benchmarkproject_pkey PRIMARY KEY (id);


--
-- Name: projects_benchmarkproject_res_benchmarkproject_id_consumpti_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY projects_benchmarkproject_result_measurement_points
    ADD CONSTRAINT projects_benchmarkproject_res_benchmarkproject_id_consumpti_key UNIQUE (benchmarkproject_id, consumptionmeasurementpoint_id);


--
-- Name: projects_benchmarkproject_result_measurement_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY projects_benchmarkproject_result_measurement_points
    ADD CONSTRAINT projects_benchmarkproject_result_measurement_points_pkey PRIMARY KEY (id);


--
-- Name: projects_cost_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY projects_cost
    ADD CONSTRAINT projects_cost_pkey PRIMARY KEY (id);


--
-- Name: provider_datasources_providerdatasource_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY provider_datasources_providerdatasource
    ADD CONSTRAINT provider_datasources_providerdatasource_pkey PRIMARY KEY (datasource_ptr_id);


--
-- Name: providers_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY providers_provider
    ADD CONSTRAINT providers_provider_pkey PRIMARY KEY (id);


--
-- Name: reports_report_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY reports_report
    ADD CONSTRAINT reports_report_pkey PRIMARY KEY (id);


--
-- Name: rules_dateexception_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY rules_dateexception
    ADD CONSTRAINT rules_dateexception_pkey PRIMARY KEY (id);


--
-- Name: rules_emailaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY rules_emailaction
    ADD CONSTRAINT rules_emailaction_pkey PRIMARY KEY (id);


--
-- Name: rules_indexinvariant_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY rules_indexinvariant
    ADD CONSTRAINT rules_indexinvariant_pkey PRIMARY KEY (id);


--
-- Name: rules_inputinvariant_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY rules_inputinvariant
    ADD CONSTRAINT rules_inputinvariant_pkey PRIMARY KEY (id);


--
-- Name: rules_minimizerule_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY rules_minimizerule
    ADD CONSTRAINT rules_minimizerule_pkey PRIMARY KEY (userrule_ptr_id);


--
-- Name: rules_phoneaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY rules_phoneaction
    ADD CONSTRAINT rules_phoneaction_pkey PRIMARY KEY (id);


--
-- Name: rules_relayaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY rules_relayaction
    ADD CONSTRAINT rules_relayaction_pkey PRIMARY KEY (id);


--
-- Name: rules_triggeredrule_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY rules_triggeredrule
    ADD CONSTRAINT rules_triggeredrule_pkey PRIMARY KEY (userrule_ptr_id);


--
-- Name: rules_userrule_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY rules_userrule
    ADD CONSTRAINT rules_userrule_pkey PRIMARY KEY (id);


--
-- Name: salesopportunities_activityentry_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_activityentry
    ADD CONSTRAINT salesopportunities_activityentry_pkey PRIMARY KEY (id);


--
-- Name: salesopportunities_industryty_industry_type_id_energy_grou_key1; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_industrytypesavings
    ADD CONSTRAINT salesopportunities_industryty_industry_type_id_energy_grou_key1 UNIQUE (industry_type_id, energy_group);


--
-- Name: salesopportunities_industryty_industry_type_id_energy_group_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_industrytypeusedistribution
    ADD CONSTRAINT salesopportunities_industryty_industry_type_id_energy_group_key UNIQUE (industry_type_id, energy_group);


--
-- Name: salesopportunities_industrytype_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_industrytype
    ADD CONSTRAINT salesopportunities_industrytype_pkey PRIMARY KEY (id);


--
-- Name: salesopportunities_industrytypesavings_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_industrytypesavings
    ADD CONSTRAINT salesopportunities_industrytypesavings_pkey PRIMARY KEY (id);


--
-- Name: salesopportunities_industrytypeusedistribution_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_industrytypeusedistribution
    ADD CONSTRAINT salesopportunities_industrytypeusedistribution_pkey PRIMARY KEY (id);


--
-- Name: salesopportunities_salesoppor_sales_opportunity_id_energy__key1; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_salesopportunitysavings
    ADD CONSTRAINT salesopportunities_salesoppor_sales_opportunity_id_energy__key1 UNIQUE (sales_opportunity_id, energy_group);


--
-- Name: salesopportunities_salesoppor_sales_opportunity_id_energy_g_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_salesopportunityusedistribution
    ADD CONSTRAINT salesopportunities_salesoppor_sales_opportunity_id_energy_g_key UNIQUE (sales_opportunity_id, energy_group);


--
-- Name: salesopportunities_salesoppor_salesopportunity_id_floorplan_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_salesopportunity_floorplans
    ADD CONSTRAINT salesopportunities_salesoppor_salesopportunity_id_floorplan_key UNIQUE (salesopportunity_id, floorplan_id);


--
-- Name: salesopportunities_salesopportunity_floorplans_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_salesopportunity_floorplans
    ADD CONSTRAINT salesopportunities_salesopportunity_floorplans_pkey PRIMARY KEY (id);


--
-- Name: salesopportunities_salesopportunity_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_salesopportunity
    ADD CONSTRAINT salesopportunities_salesopportunity_pkey PRIMARY KEY (id);


--
-- Name: salesopportunities_salesopportunitysavings_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_salesopportunitysavings
    ADD CONSTRAINT salesopportunities_salesopportunitysavings_pkey PRIMARY KEY (id);


--
-- Name: salesopportunities_salesopportunityusedistribution_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_salesopportunityusedistribution
    ADD CONSTRAINT salesopportunities_salesopportunityusedistribution_pkey PRIMARY KEY (id);


--
-- Name: salesopportunities_surveyinstructi_sales_opportunity_id_use_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_surveyinstruction
    ADD CONSTRAINT salesopportunities_surveyinstructi_sales_opportunity_id_use_key UNIQUE (sales_opportunity_id, use);


--
-- Name: salesopportunities_surveyinstruction_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_surveyinstruction
    ADD CONSTRAINT salesopportunities_surveyinstruction_pkey PRIMARY KEY (id);


--
-- Name: salesopportunities_task_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salesopportunities_task
    ADD CONSTRAINT salesopportunities_task_pkey PRIMARY KEY (id);


--
-- Name: south_migrationhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY south_migrationhistory
    ADD CONSTRAINT south_migrationhistory_pkey PRIMARY KEY (id);


--
-- Name: suppliers_supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY suppliers_supplier
    ADD CONSTRAINT suppliers_supplier_pkey PRIMARY KEY (id);


--
-- Name: system_health_site_healthreport_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY system_health_site_healthreport
    ADD CONSTRAINT system_health_site_healthreport_pkey PRIMARY KEY (id);


--
-- Name: tariffs_energytariff_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tariffs_energytariff
    ADD CONSTRAINT tariffs_energytariff_pkey PRIMARY KEY (tariff_ptr_id);


--
-- Name: tariffs_fixedpriceperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tariffs_fixedpriceperiod
    ADD CONSTRAINT tariffs_fixedpriceperiod_pkey PRIMARY KEY (period_ptr_id);


--
-- Name: tariffs_period_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tariffs_period
    ADD CONSTRAINT tariffs_period_pkey PRIMARY KEY (id);


--
-- Name: tariffs_spotpriceperiod_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tariffs_spotpriceperiod
    ADD CONSTRAINT tariffs_spotpriceperiod_pkey PRIMARY KEY (period_ptr_id);


--
-- Name: tariffs_tariff_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tariffs_tariff
    ADD CONSTRAINT tariffs_tariff_pkey PRIMARY KEY (id);


--
-- Name: tariffs_volumetariff_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tariffs_volumetariff
    ADD CONSTRAINT tariffs_volumetariff_pkey PRIMARY KEY (tariff_ptr_id);


--
-- Name: token_auth_tokendata_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY token_auth_tokendata
    ADD CONSTRAINT token_auth_tokendata_pkey PRIMARY KEY (key);


--
-- Name: token_auth_tokendata_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY token_auth_tokendata
    ADD CONSTRAINT token_auth_tokendata_user_id_key UNIQUE (user_id);


--
-- Name: users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (user_ptr_id);


--
-- Name: auth_group_name_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_group_name_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_user_groups_group_id ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_user_groups_user_id ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_permission_id ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_user_id ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX auth_user_username_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: celery_taskmeta_hidden; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX celery_taskmeta_hidden ON celery_taskmeta USING btree (hidden);


--
-- Name: celery_taskmeta_task_id_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX celery_taskmeta_task_id_like ON celery_taskmeta USING btree (task_id varchar_pattern_ops);


--
-- Name: celery_tasksetmeta_hidden; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX celery_tasksetmeta_hidden ON celery_tasksetmeta USING btree (hidden);


--
-- Name: celery_tasksetmeta_taskset_id_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX celery_tasksetmeta_taskset_id_like ON celery_tasksetmeta USING btree (taskset_id varchar_pattern_ops);


--
-- Name: co2conversions_co2conversion_mainconsumption_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX co2conversions_co2conversion_mainconsumption_id ON co2conversions_co2conversion USING btree (mainconsumption_id);


--
-- Name: co2conversions_co2conversion_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX co2conversions_co2conversion_subclass_id ON co2conversions_co2conversion USING btree (subclass_id);


--
-- Name: co2conversions_dynamicco2conversion_datasource_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX co2conversions_dynamicco2conversion_datasource_id ON co2conversions_dynamicco2conversion USING btree (datasource_id);


--
-- Name: consumptions_consumption_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_consumption_customer_id ON consumptions_consumption USING btree (customer_id);


--
-- Name: consumptions_consumption_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_consumption_subclass_id ON consumptions_consumption USING btree (subclass_id);


--
-- Name: consumptions_consumption_volumetoenergyconversion_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_consumption_volumetoenergyconversion_id ON consumptions_consumption USING btree (volumetoenergyconversion_id);


--
-- Name: consumptions_consumptiongroup_consumptions_consumption_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_consumptiongroup_consumptions_consumption_id ON consumptions_consumptiongroup_consumptions USING btree (consumption_id);


--
-- Name: consumptions_consumptiongroup_consumptions_consumptiongroup_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_consumptiongroup_consumptions_consumptiongroup_id ON consumptions_consumptiongroup_consumptions USING btree (consumptiongroup_id);


--
-- Name: consumptions_consumptiongroup_cost_compensation_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_consumptiongroup_cost_compensation_id ON consumptions_consumptiongroup USING btree (cost_compensation_id);


--
-- Name: consumptions_consumptiongroup_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_consumptiongroup_customer_id ON consumptions_consumptiongroup USING btree (customer_id);


--
-- Name: consumptions_consumptiongroup_mainconsumption_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_consumptiongroup_mainconsumption_id ON consumptions_consumptiongroup USING btree (mainconsumption_id);


--
-- Name: consumptions_mainconsumption_consumptions_consumption_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_mainconsumption_consumptions_consumption_id ON consumptions_mainconsumption_consumptions USING btree (consumption_id);


--
-- Name: consumptions_mainconsumption_consumptions_mainconsumption_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_mainconsumption_consumptions_mainconsumption_id ON consumptions_mainconsumption_consumptions USING btree (mainconsumption_id);


--
-- Name: consumptions_mainconsumption_cost_compensation_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_mainconsumption_cost_compensation_id ON consumptions_mainconsumption USING btree (cost_compensation_id);


--
-- Name: consumptions_mainconsumption_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_mainconsumption_customer_id ON consumptions_mainconsumption USING btree (customer_id);


--
-- Name: consumptions_mainconsumption_tariff_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_mainconsumption_tariff_id ON consumptions_mainconsumption USING btree (tariff_id);


--
-- Name: consumptions_nonpulseperiod_datasource_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_nonpulseperiod_datasource_id ON consumptions_nonpulseperiod USING btree (datasource_id);


--
-- Name: consumptions_period_datasequence_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_period_datasequence_id ON consumptions_period USING btree (datasequence_id);


--
-- Name: consumptions_period_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_period_subclass_id ON consumptions_period USING btree (subclass_id);


--
-- Name: consumptions_pulseperiod_datasource_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX consumptions_pulseperiod_datasource_id ON consumptions_pulseperiod USING btree (datasource_id);


--
-- Name: cost_compensations_costcompensation_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX cost_compensations_costcompensation_customer_id ON cost_compensations_costcompensation USING btree (customer_id);


--
-- Name: cost_compensations_costcompensation_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX cost_compensations_costcompensation_subclass_id ON cost_compensations_costcompensation USING btree (subclass_id);


--
-- Name: cost_compensations_period_datasequence_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX cost_compensations_period_datasequence_id ON cost_compensations_period USING btree (datasequence_id);


--
-- Name: cost_compensations_period_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX cost_compensations_period_subclass_id ON cost_compensations_period USING btree (subclass_id);


--
-- Name: customer_datasources_customerdatasource_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customer_datasources_customerdatasource_customer_id ON customer_datasources_customerdatasource USING btree (customer_id);


--
-- Name: customers_collection_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_collection_customer_id ON customers_collection USING btree (customer_id);


--
-- Name: customers_collection_level; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_collection_level ON customers_collection USING btree (level);


--
-- Name: customers_collection_lft; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_collection_lft ON customers_collection USING btree (lft);


--
-- Name: customers_collection_parent_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_collection_parent_id ON customers_collection USING btree (parent_id);


--
-- Name: customers_collection_relay_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_collection_relay_id ON customers_collection USING btree (relay_id);


--
-- Name: customers_collection_rght; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_collection_rght ON customers_collection USING btree (rght);


--
-- Name: customers_collection_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_collection_subclass_id ON customers_collection USING btree (subclass_id);


--
-- Name: customers_collection_tree_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_collection_tree_id ON customers_collection USING btree (tree_id);


--
-- Name: customers_customer_created_by_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_customer_created_by_id ON customers_customer USING btree (created_by_id);


--
-- Name: customers_customer_electricity_tariff_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_customer_electricity_tariff_id ON customers_customer USING btree (electricity_tariff_id);


--
-- Name: customers_customer_gas_tariff_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_customer_gas_tariff_id ON customers_customer USING btree (gas_tariff_id);


--
-- Name: customers_customer_heat_tariff_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_customer_heat_tariff_id ON customers_customer USING btree (heat_tariff_id);


--
-- Name: customers_customer_industry_types_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_customer_industry_types_customer_id ON customers_customer_industry_types USING btree (customer_id);


--
-- Name: customers_customer_industry_types_industrytype_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_customer_industry_types_industrytype_id ON customers_customer_industry_types USING btree (industrytype_id);


--
-- Name: customers_customer_oil_tariff_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_customer_oil_tariff_id ON customers_customer USING btree (oil_tariff_id);


--
-- Name: customers_customer_provider_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_customer_provider_id ON customers_customer USING btree (provider_id);


--
-- Name: customers_customer_water_tariff_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_customer_water_tariff_id ON customers_customer USING btree (water_tariff_id);


--
-- Name: customers_location_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_location_customer_id ON customers_location USING btree (customer_id);


--
-- Name: customers_location_level; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_location_level ON customers_location USING btree (level);


--
-- Name: customers_location_lft; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_location_lft ON customers_location USING btree (lft);


--
-- Name: customers_location_parent_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_location_parent_id ON customers_location USING btree (parent_id);


--
-- Name: customers_location_rght; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_location_rght ON customers_location USING btree (rght);


--
-- Name: customers_location_tree_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_location_tree_id ON customers_location USING btree (tree_id);


--
-- Name: customers_userprofile_collections_collection_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_userprofile_collections_collection_id ON customers_userprofile_collections USING btree (collection_id);


--
-- Name: customers_userprofile_collections_userprofile_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customers_userprofile_collections_userprofile_id ON customers_userprofile_collections USING btree (userprofile_id);


--
-- Name: dataneeds_dataneed_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX dataneeds_dataneed_customer_id ON dataneeds_dataneed USING btree (customer_id);


--
-- Name: dataneeds_dataneed_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX dataneeds_dataneed_subclass_id ON dataneeds_dataneed USING btree (subclass_id);


--
-- Name: datasequence_adapters_consumptionaccumulationadapter_datase1fda; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX datasequence_adapters_consumptionaccumulationadapter_datase1fda ON datasequence_adapters_consumptionaccumulationadapter USING btree (datasequence_id);


--
-- Name: datasequence_adapters_nonaccumulationadapter_datasequence_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX datasequence_adapters_nonaccumulationadapter_datasequence_id ON datasequence_adapters_nonaccumulationadapter USING btree (datasequence_id);


--
-- Name: datasequence_adapters_productionaccumulationadapter_dataseqb632; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX datasequence_adapters_productionaccumulationadapter_dataseqb632 ON datasequence_adapters_productionaccumulationadapter USING btree (datasequence_id);


--
-- Name: datasequences_energypervolumedatasequence_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX datasequences_energypervolumedatasequence_customer_id ON datasequences_energypervolumedatasequence USING btree (customer_id);


--
-- Name: datasequences_energypervolumedatasequence_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX datasequences_energypervolumedatasequence_subclass_id ON datasequences_energypervolumedatasequence USING btree (subclass_id);


--
-- Name: datasequences_energypervolumeperiod_datasequence_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX datasequences_energypervolumeperiod_datasequence_id ON datasequences_energypervolumeperiod USING btree (datasequence_id);


--
-- Name: datasequences_energypervolumeperiod_datasource_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX datasequences_energypervolumeperiod_datasource_id ON datasequences_energypervolumeperiod USING btree (datasource_id);


--
-- Name: datasequences_nonaccumulationdatasequence_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX datasequences_nonaccumulationdatasequence_customer_id ON datasequences_nonaccumulationdatasequence USING btree (customer_id);


--
-- Name: datasequences_nonaccumulationdatasequence_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX datasequences_nonaccumulationdatasequence_subclass_id ON datasequences_nonaccumulationdatasequence USING btree (subclass_id);


--
-- Name: datasequences_nonaccumulationperiod_datasequence_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX datasequences_nonaccumulationperiod_datasequence_id ON datasequences_nonaccumulationperiod USING btree (datasequence_id);


--
-- Name: datasequences_nonaccumulationperiod_datasource_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX datasequences_nonaccumulationperiod_datasource_id ON datasequences_nonaccumulationperiod USING btree (datasource_id);


--
-- Name: datasources_datasource_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX datasources_datasource_subclass_id ON datasources_datasource USING btree (subclass_id);


--
-- Name: devices_agent_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX devices_agent_customer_id ON devices_agent USING btree (customer_id);


--
-- Name: devices_agent_location_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX devices_agent_location_id ON devices_agent USING btree (location_id);


--
-- Name: devices_agentevent_agent_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX devices_agentevent_agent_id ON devices_agentevent USING btree (agent_id);


--
-- Name: devices_agentstatechange_agent_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX devices_agentstatechange_agent_id ON devices_agentstatechange USING btree (agent_id);


--
-- Name: devices_meter_agent_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX devices_meter_agent_id ON devices_meter USING btree (agent_id);


--
-- Name: devices_meter_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX devices_meter_customer_id ON devices_meter USING btree (customer_id);


--
-- Name: devices_meter_location_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX devices_meter_location_id ON devices_meter USING btree (location_id);


--
-- Name: devices_meterstatechange_meter_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX devices_meterstatechange_meter_id ON devices_meterstatechange USING btree (meter_id);


--
-- Name: devices_physicalinput_meter_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX devices_physicalinput_meter_id ON devices_physicalinput USING btree (meter_id);


--
-- Name: display_widgets_dashboardwidget_collection_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX display_widgets_dashboardwidget_collection_id ON display_widgets_dashboardwidget USING btree (collection_id);


--
-- Name: display_widgets_dashboardwidget_index_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX display_widgets_dashboardwidget_index_id ON display_widgets_dashboardwidget USING btree (index_id);


--
-- Name: display_widgets_dashboardwidget_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX display_widgets_dashboardwidget_user_id ON display_widgets_dashboardwidget USING btree (user_id);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX django_session_expire_date ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX django_session_session_key_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: djcelery_periodictask_crontab_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_periodictask_crontab_id ON djcelery_periodictask USING btree (crontab_id);


--
-- Name: djcelery_periodictask_interval_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_periodictask_interval_id ON djcelery_periodictask USING btree (interval_id);


--
-- Name: djcelery_periodictask_name_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_periodictask_name_like ON djcelery_periodictask USING btree (name varchar_pattern_ops);


--
-- Name: djcelery_taskstate_hidden; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_hidden ON djcelery_taskstate USING btree (hidden);


--
-- Name: djcelery_taskstate_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_name ON djcelery_taskstate USING btree (name);


--
-- Name: djcelery_taskstate_name_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_name_like ON djcelery_taskstate USING btree (name varchar_pattern_ops);


--
-- Name: djcelery_taskstate_state; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_state ON djcelery_taskstate USING btree (state);


--
-- Name: djcelery_taskstate_state_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_state_like ON djcelery_taskstate USING btree (state varchar_pattern_ops);


--
-- Name: djcelery_taskstate_task_id_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_task_id_like ON djcelery_taskstate USING btree (task_id varchar_pattern_ops);


--
-- Name: djcelery_taskstate_tstamp; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_tstamp ON djcelery_taskstate USING btree (tstamp);


--
-- Name: djcelery_taskstate_worker_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_taskstate_worker_id ON djcelery_taskstate USING btree (worker_id);


--
-- Name: djcelery_workerstate_hostname_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_workerstate_hostname_like ON djcelery_workerstate USING btree (hostname varchar_pattern_ops);


--
-- Name: djcelery_workerstate_last_heartbeat; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX djcelery_workerstate_last_heartbeat ON djcelery_workerstate USING btree (last_heartbeat);


--
-- Name: encryption_encryptionkey_content_type_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX encryption_encryptionkey_content_type_id ON encryption_encryptionkey USING btree (content_type_id);


--
-- Name: encryption_encryptionkey_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX encryption_encryptionkey_user_id ON encryption_encryptionkey USING btree (user_id);


--
-- Name: energinet_co2_modelbinding_index_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energinet_co2_modelbinding_index_id ON energinet_co2_modelbinding USING btree (index_id);


--
-- Name: energy_breakdown_districtheatingconsumptionarea_salesopportf089; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energy_breakdown_districtheatingconsumptionarea_salesopportf089 ON energy_breakdown_districtheatingconsumptionarea USING btree (salesopportunity_id);


--
-- Name: energy_breakdown_electricityconsumptionarea_salesopportunity_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energy_breakdown_electricityconsumptionarea_salesopportunity_id ON energy_breakdown_electricityconsumptionarea USING btree (salesopportunity_id);


--
-- Name: energy_breakdown_fuelconsumptionarea_salesopportunity_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energy_breakdown_fuelconsumptionarea_salesopportunity_id ON energy_breakdown_fuelconsumptionarea USING btree (salesopportunity_id);


--
-- Name: energy_breakdown_proposedaction_energyusearea_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energy_breakdown_proposedaction_energyusearea_id ON energy_breakdown_proposedaction USING btree (energyusearea_id);


--
-- Name: energy_breakdown_proposedaction_salesopportunity_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energy_breakdown_proposedaction_salesopportunity_id ON energy_breakdown_proposedaction USING btree (salesopportunity_id);


--
-- Name: energy_breakdown_waterconsumptionarea_salesopportunity_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energy_breakdown_waterconsumptionarea_salesopportunity_id ON energy_breakdown_waterconsumptionarea USING btree (salesopportunity_id);


--
-- Name: energy_use_reports_energyusearea_measurement_points_consumpd1ba; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energy_use_reports_energyusearea_measurement_points_consumpd1ba ON energy_use_reports_energyusearea_measurement_points USING btree (consumptionmeasurementpoint_id);


--
-- Name: energy_use_reports_energyusearea_measurement_points_energyub419; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energy_use_reports_energyusearea_measurement_points_energyub419 ON energy_use_reports_energyusearea_measurement_points USING btree (energyusearea_id);


--
-- Name: energy_use_reports_energyusearea_report_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energy_use_reports_energyusearea_report_id ON energy_use_reports_energyusearea USING btree (report_id);


--
-- Name: energy_use_reports_energyusereport_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energy_use_reports_energyusereport_customer_id ON energy_use_reports_energyusereport USING btree (customer_id);


--
-- Name: energy_use_reports_energyusereport_main_measurement_points_313d; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energy_use_reports_energyusereport_main_measurement_points_313d ON energy_use_reports_energyusereport_main_measurement_points USING btree (consumptionmeasurementpoint_id);


--
-- Name: energy_use_reports_energyusereport_main_measurement_points_4a82; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energy_use_reports_energyusereport_main_measurement_points_4a82 ON energy_use_reports_energyusereport_main_measurement_points USING btree (energyusereport_id);


--
-- Name: energyperformances_energyperformance_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energyperformances_energyperformance_customer_id ON energyperformances_energyperformance USING btree (customer_id);


--
-- Name: energyperformances_energyperformance_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energyperformances_energyperformance_subclass_id ON energyperformances_energyperformance USING btree (subclass_id);


--
-- Name: energyperformances_productionenergyperformance_consumptiong1cf7; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energyperformances_productionenergyperformance_consumptiong1cf7 ON energyperformances_productionenergyperformance_consumptiong23ca USING btree (consumptiongroup_id);


--
-- Name: energyperformances_productionenergyperformance_consumptiongd8f2; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energyperformances_productionenergyperformance_consumptiongd8f2 ON energyperformances_productionenergyperformance_consumptiong23ca USING btree (productionenergyperformance_id);


--
-- Name: energyperformances_productionenergyperformance_productiongr92f7; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energyperformances_productionenergyperformance_productiongr92f7 ON energyperformances_productionenergyperformance_productiongroups USING btree (productionenergyperformance_id);


--
-- Name: energyperformances_productionenergyperformance_productiongre336; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energyperformances_productionenergyperformance_productiongre336 ON energyperformances_productionenergyperformance_productiongroups USING btree (productiongroup_id);


--
-- Name: energyperformances_timeenergyperformance_consumptiongroups_273d; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energyperformances_timeenergyperformance_consumptiongroups_273d ON energyperformances_timeenergyperformance_consumptiongroups USING btree (consumptiongroup_id);


--
-- Name: energyperformances_timeenergyperformance_consumptiongroups_c730; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX energyperformances_timeenergyperformance_consumptiongroups_c730 ON energyperformances_timeenergyperformance_consumptiongroups USING btree (timeenergyperformance_id);


--
-- Name: enpi_reports_enpireport_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX enpi_reports_enpireport_customer_id ON enpi_reports_enpireport USING btree (customer_id);


--
-- Name: enpi_reports_enpiusearea_energy_driver_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX enpi_reports_enpiusearea_energy_driver_id ON enpi_reports_enpiusearea USING btree (energy_driver_id);


--
-- Name: enpi_reports_enpiusearea_measurement_points_consumptionmeas8b22; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX enpi_reports_enpiusearea_measurement_points_consumptionmeas8b22 ON enpi_reports_enpiusearea_measurement_points USING btree (consumptionmeasurementpoint_id);


--
-- Name: enpi_reports_enpiusearea_measurement_points_enpiusearea_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX enpi_reports_enpiusearea_measurement_points_enpiusearea_id ON enpi_reports_enpiusearea_measurement_points USING btree (enpiusearea_id);


--
-- Name: enpi_reports_enpiusearea_report_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX enpi_reports_enpiusearea_report_id ON enpi_reports_enpiusearea USING btree (report_id);


--
-- Name: indexes_datasourceindexadapter_datasource_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX indexes_datasourceindexadapter_datasource_id ON indexes_datasourceindexadapter USING btree (datasource_id);


--
-- Name: indexes_derivedindexperiod_index_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX indexes_derivedindexperiod_index_id ON indexes_derivedindexperiod USING btree (index_id);


--
-- Name: indexes_derivedindexperiod_other_index_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX indexes_derivedindexperiod_other_index_id ON indexes_derivedindexperiod USING btree (other_index_id);


--
-- Name: indexes_entry_index_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX indexes_entry_index_id ON indexes_entry USING btree (index_id);


--
-- Name: indexes_index_collection_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX indexes_index_collection_id ON indexes_index USING btree (collection_id);


--
-- Name: indexes_seasonindexperiod_index_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX indexes_seasonindexperiod_index_id ON indexes_seasonindexperiod USING btree (index_id);


--
-- Name: installation_surveys_billingmeter_salesopportunity_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installation_surveys_billingmeter_salesopportunity_id ON installation_surveys_billingmeter USING btree (salesopportunity_id);


--
-- Name: installation_surveys_billingmeterappendix_billingmeter_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installation_surveys_billingmeterappendix_billingmeter_id ON installation_surveys_billingmeterappendix USING btree (billingmeter_id);


--
-- Name: installation_surveys_energyusearea_salesopportunity_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installation_surveys_energyusearea_salesopportunity_id ON installation_surveys_energyusearea USING btree (salesopportunity_id);


--
-- Name: installation_surveys_proposedaction_energyusearea_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installation_surveys_proposedaction_energyusearea_id ON installation_surveys_proposedaction USING btree (energyusearea_id);


--
-- Name: installation_surveys_proposedaction_salesopportunity_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installation_surveys_proposedaction_salesopportunity_id ON installation_surveys_proposedaction USING btree (salesopportunity_id);


--
-- Name: installation_surveys_workhours_salesopportunity_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installation_surveys_workhours_salesopportunity_id ON installation_surveys_workhours USING btree (salesopportunity_id);


--
-- Name: installations_floorplan_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_floorplan_customer_id ON installations_floorplan USING btree (customer_id);


--
-- Name: installations_installationphoto_installation_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_installationphoto_installation_id ON installations_installationphoto USING btree (installation_id);


--
-- Name: installations_meterinstallation_gateway_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_meterinstallation_gateway_id ON installations_meterinstallation USING btree (gateway_id);


--
-- Name: installations_meterinstallation_input_satisfies_dataneeds_d1223; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_meterinstallation_input_satisfies_dataneeds_d1223 ON installations_meterinstallation_input_satisfies_dataneeds USING btree (dataneed_id);


--
-- Name: installations_meterinstallation_input_satisfies_dataneeds_m98e5; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_meterinstallation_input_satisfies_dataneeds_m98e5 ON installations_meterinstallation_input_satisfies_dataneeds USING btree (meterinstallation_id);


--
-- Name: installations_productinstallation_floorplan_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_productinstallation_floorplan_id ON installations_productinstallation USING btree (floorplan_id);


--
-- Name: installations_productinstallation_product_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_productinstallation_product_id ON installations_productinstallation USING btree (product_id);


--
-- Name: installations_productinstallation_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_productinstallation_subclass_id ON installations_productinstallation USING btree (subclass_id);


--
-- Name: installations_pulseemitterinstallation_input_satisfies_data487f; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_pulseemitterinstallation_input_satisfies_data487f ON installations_pulseemitterinstallation_input_satisfies_data7b36 USING btree (pulseemitterinstallation_id);


--
-- Name: installations_pulseemitterinstallation_input_satisfies_datacb3e; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_pulseemitterinstallation_input_satisfies_datacb3e ON installations_pulseemitterinstallation_input_satisfies_data7b36 USING btree (dataneed_id);


--
-- Name: installations_repeaterinstallation_gateway_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_repeaterinstallation_gateway_id ON installations_repeaterinstallation USING btree (gateway_id);


--
-- Name: installations_tripleinputmeterinstallation_gateway_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_tripleinputmeterinstallation_gateway_id ON installations_tripleinputmeterinstallation USING btree (gateway_id);


--
-- Name: installations_tripleinputmeterinstallation_input1_satisfies69ae; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_tripleinputmeterinstallation_input1_satisfies69ae ON installations_tripleinputmeterinstallation_input1_satisfies0539 USING btree (dataneed_id);


--
-- Name: installations_tripleinputmeterinstallation_input1_satisfies94d0; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_tripleinputmeterinstallation_input1_satisfies94d0 ON installations_tripleinputmeterinstallation_input1_satisfies0539 USING btree (tripleinputmeterinstallation_id);


--
-- Name: installations_tripleinputmeterinstallation_input2_satisfies5b2e; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_tripleinputmeterinstallation_input2_satisfies5b2e ON installations_tripleinputmeterinstallation_input2_satisfies1aad USING btree (dataneed_id);


--
-- Name: installations_tripleinputmeterinstallation_input2_satisfies9ee3; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_tripleinputmeterinstallation_input2_satisfies9ee3 ON installations_tripleinputmeterinstallation_input2_satisfies1aad USING btree (tripleinputmeterinstallation_id);


--
-- Name: installations_tripleinputmeterinstallation_input3_satisfies0af8; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_tripleinputmeterinstallation_input3_satisfies0af8 ON installations_tripleinputmeterinstallation_input3_satisfies9eaa USING btree (tripleinputmeterinstallation_id);


--
-- Name: installations_tripleinputmeterinstallation_input3_satisfiesc5e0; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_tripleinputmeterinstallation_input3_satisfiesc5e0 ON installations_tripleinputmeterinstallation_input3_satisfies9eaa USING btree (dataneed_id);


--
-- Name: installations_triplepulsecollectorinstallation_gateway_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_triplepulsecollectorinstallation_gateway_id ON installations_triplepulsecollectorinstallation USING btree (gateway_id);


--
-- Name: installations_triplepulsecollectorinstallation_input1_pulsee9d7; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_triplepulsecollectorinstallation_input1_pulsee9d7 ON installations_triplepulsecollectorinstallation USING btree (input1_pulseemitterinstallation_id);


--
-- Name: installations_triplepulsecollectorinstallation_input2_pulse9609; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_triplepulsecollectorinstallation_input2_pulse9609 ON installations_triplepulsecollectorinstallation USING btree (input2_pulseemitterinstallation_id);


--
-- Name: installations_triplepulsecollectorinstallation_input3_pulse89da; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX installations_triplepulsecollectorinstallation_input3_pulse89da ON installations_triplepulsecollectorinstallation USING btree (input3_pulseemitterinstallation_id);


--
-- Name: manage_collections_collectionitem_collection_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX manage_collections_collectionitem_collection_id ON manage_collections_collectionitem USING btree (collection_id);


--
-- Name: manage_collections_item_floorplan_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX manage_collections_item_floorplan_id ON manage_collections_item USING btree (floorplan_id);


--
-- Name: manage_collections_item_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX manage_collections_item_subclass_id ON manage_collections_item USING btree (subclass_id);


--
-- Name: measurementpoints_chainlink_chain_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_chainlink_chain_id ON measurementpoints_chainlink USING btree (chain_id);


--
-- Name: measurementpoints_chainlink_data_series_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_chainlink_data_series_id ON measurementpoints_chainlink USING btree (data_series_id);


--
-- Name: measurementpoints_dataseries_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_dataseries_customer_id ON measurementpoints_dataseries USING btree (customer_id);


--
-- Name: measurementpoints_dataseries_graph_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_dataseries_graph_id ON measurementpoints_dataseries USING btree (graph_id);


--
-- Name: measurementpoints_dataseries_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_dataseries_subclass_id ON measurementpoints_dataseries USING btree (subclass_id);


--
-- Name: measurementpoints_degreedaycorrection_consumption_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_degreedaycorrection_consumption_id ON measurementpoints_degreedaycorrection USING btree (consumption_id);


--
-- Name: measurementpoints_degreedaycorrection_degreedays_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_degreedaycorrection_degreedays_id ON measurementpoints_degreedaycorrection USING btree (degreedays_id);


--
-- Name: measurementpoints_degreedaycorrection_standarddegreedays_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_degreedaycorrection_standarddegreedays_id ON measurementpoints_degreedaycorrection USING btree (standarddegreedays_id);


--
-- Name: measurementpoints_graph_collection_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_graph_collection_id ON measurementpoints_graph USING btree (collection_id);


--
-- Name: measurementpoints_heatingdegreedays_derived_from_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_heatingdegreedays_derived_from_id ON measurementpoints_heatingdegreedays USING btree (derived_from_id);


--
-- Name: measurementpoints_indexcalculation_consumption_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_indexcalculation_consumption_id ON measurementpoints_indexcalculation USING btree (consumption_id);


--
-- Name: measurementpoints_indexcalculation_index_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_indexcalculation_index_id ON measurementpoints_indexcalculation USING btree (index_id);


--
-- Name: measurementpoints_link_target_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_link_target_id ON measurementpoints_link USING btree (target_id);


--
-- Name: measurementpoints_meantemperaturechange_energy_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_meantemperaturechange_energy_id ON measurementpoints_meantemperaturechange USING btree (energy_id);


--
-- Name: measurementpoints_meantemperaturechange_volume_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_meantemperaturechange_volume_id ON measurementpoints_meantemperaturechange USING btree (volume_id);


--
-- Name: measurementpoints_multiplication_source_data_series_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_multiplication_source_data_series_id ON measurementpoints_multiplication USING btree (source_data_series_id);


--
-- Name: measurementpoints_piecewiseconstantintegral_data_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_piecewiseconstantintegral_data_id ON measurementpoints_piecewiseconstantintegral USING btree (data_id);


--
-- Name: measurementpoints_rateconversion_consumption_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_rateconversion_consumption_id ON measurementpoints_rateconversion USING btree (consumption_id);


--
-- Name: measurementpoints_simplelinearregression_data_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_simplelinearregression_data_id ON measurementpoints_simplelinearregression USING btree (data_id);


--
-- Name: measurementpoints_storeddata_data_series_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_storeddata_data_series_id ON measurementpoints_storeddata USING btree (data_series_id);


--
-- Name: measurementpoints_storeddata_ef4a2464; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_storeddata_ef4a2464 ON measurementpoints_storeddata USING btree (data_series_id, "timestamp");


--
-- Name: measurementpoints_summationterm_data_series_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_summationterm_data_series_id ON measurementpoints_summationterm USING btree (data_series_id);


--
-- Name: measurementpoints_summationterm_summation_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_summationterm_summation_id ON measurementpoints_summationterm USING btree (summation_id);


--
-- Name: measurementpoints_utilization_consumption_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_utilization_consumption_id ON measurementpoints_utilization USING btree (consumption_id);


--
-- Name: measurementpoints_utilization_needs_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX measurementpoints_utilization_needs_id ON measurementpoints_utilization USING btree (needs_id);


--
-- Name: opportunities_opportunity_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX opportunities_opportunity_customer_id ON opportunities_opportunity USING btree (customer_id);


--
-- Name: processperiods_processperiod_accepted_opportunities_opportu6525; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX processperiods_processperiod_accepted_opportunities_opportu6525 ON processperiods_processperiod_accepted_opportunities USING btree (opportunity_id);


--
-- Name: processperiods_processperiod_accepted_opportunities_process3386; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX processperiods_processperiod_accepted_opportunities_process3386 ON processperiods_processperiod_accepted_opportunities USING btree (processperiod_id);


--
-- Name: processperiods_processperiod_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX processperiods_processperiod_customer_id ON processperiods_processperiod USING btree (customer_id);


--
-- Name: processperiods_processperiod_enpis_energyperformance_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX processperiods_processperiod_enpis_energyperformance_id ON processperiods_processperiod_enpis USING btree (energyperformance_id);


--
-- Name: processperiods_processperiod_enpis_processperiod_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX processperiods_processperiod_enpis_processperiod_id ON processperiods_processperiod_enpis USING btree (processperiod_id);


--
-- Name: processperiods_processperiod_rejected_opportunities_opportu3691; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX processperiods_processperiod_rejected_opportunities_opportu3691 ON processperiods_processperiod_rejected_opportunities USING btree (opportunity_id);


--
-- Name: processperiods_processperiod_rejected_opportunities_processb6ee; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX processperiods_processperiod_rejected_opportunities_processb6ee ON processperiods_processperiod_rejected_opportunities USING btree (processperiod_id);


--
-- Name: processperiods_processperiod_significant_energyuses_energyu3a33; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX processperiods_processperiod_significant_energyuses_energyu3a33 ON processperiods_processperiod_significant_energyuses USING btree (energyuse_id);


--
-- Name: processperiods_processperiod_significant_energyuses_processfec0; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX processperiods_processperiod_significant_energyuses_processfec0 ON processperiods_processperiod_significant_energyuses USING btree (processperiod_id);


--
-- Name: processperiods_processperiodgoal_energyperformance_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX processperiods_processperiodgoal_energyperformance_id ON processperiods_processperiodgoal USING btree (energyperformance_id);


--
-- Name: processperiods_processperiodgoal_processperiod_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX processperiods_processperiodgoal_processperiod_id ON processperiods_processperiodgoal USING btree (processperiod_id);


--
-- Name: productions_nonpulseperiod_datasource_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX productions_nonpulseperiod_datasource_id ON productions_nonpulseperiod USING btree (datasource_id);


--
-- Name: productions_period_datasequence_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX productions_period_datasequence_id ON productions_period USING btree (datasequence_id);


--
-- Name: productions_period_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX productions_period_subclass_id ON productions_period USING btree (subclass_id);


--
-- Name: productions_production_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX productions_production_customer_id ON productions_production USING btree (customer_id);


--
-- Name: productions_production_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX productions_production_subclass_id ON productions_production USING btree (subclass_id);


--
-- Name: productions_productiongroup_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX productions_productiongroup_customer_id ON productions_productiongroup USING btree (customer_id);


--
-- Name: productions_productiongroup_productions_production_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX productions_productiongroup_productions_production_id ON productions_productiongroup_productions USING btree (production_id);


--
-- Name: productions_productiongroup_productions_productiongroup_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX productions_productiongroup_productions_productiongroup_id ON productions_productiongroup_productions USING btree (productiongroup_id);


--
-- Name: productions_pulseperiod_datasource_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX productions_pulseperiod_datasource_id ON productions_pulseperiod USING btree (datasource_id);


--
-- Name: products_historicalproduct_category_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX products_historicalproduct_category_id ON products_historicalproduct USING btree (category_id);


--
-- Name: products_historicalproduct_installation_type_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX products_historicalproduct_installation_type_id ON products_historicalproduct USING btree (installation_type_id);


--
-- Name: products_historicalproduct_product_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX products_historicalproduct_product_id ON products_historicalproduct USING btree (product_id);


--
-- Name: products_historicalproduct_provider_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX products_historicalproduct_provider_id ON products_historicalproduct USING btree (provider_id);


--
-- Name: products_historicalproduct_supplier_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX products_historicalproduct_supplier_id ON products_historicalproduct USING btree (supplier_id);


--
-- Name: products_historicalproduct_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX products_historicalproduct_user_id ON products_historicalproduct USING btree (user_id);


--
-- Name: products_product_category_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX products_product_category_id ON products_product USING btree (category_id);


--
-- Name: products_product_installation_type_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX products_product_installation_type_id ON products_product USING btree (installation_type_id);


--
-- Name: products_product_provider_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX products_product_provider_id ON products_product USING btree (provider_id);


--
-- Name: products_product_supplier_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX products_product_supplier_id ON products_product USING btree (supplier_id);


--
-- Name: products_productcategory_provider_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX products_productcategory_provider_id ON products_productcategory USING btree (provider_id);


--
-- Name: projects_additionalsaving_project_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX projects_additionalsaving_project_id ON projects_additionalsaving USING btree (project_id);


--
-- Name: projects_benchmarkproject_baseline_measurement_points_bench8fcb; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX projects_benchmarkproject_baseline_measurement_points_bench8fcb ON projects_benchmarkproject_baseline_measurement_points USING btree (benchmarkproject_id);


--
-- Name: projects_benchmarkproject_baseline_measurement_points_consu517f; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX projects_benchmarkproject_baseline_measurement_points_consu517f ON projects_benchmarkproject_baseline_measurement_points USING btree (consumptionmeasurementpoint_id);


--
-- Name: projects_benchmarkproject_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX projects_benchmarkproject_customer_id ON projects_benchmarkproject USING btree (customer_id);


--
-- Name: projects_benchmarkproject_result_measurement_points_benchma7ca9; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX projects_benchmarkproject_result_measurement_points_benchma7ca9 ON projects_benchmarkproject_result_measurement_points USING btree (benchmarkproject_id);


--
-- Name: projects_benchmarkproject_result_measurement_points_consump8f9b; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX projects_benchmarkproject_result_measurement_points_consump8f9b ON projects_benchmarkproject_result_measurement_points USING btree (consumptionmeasurementpoint_id);


--
-- Name: projects_cost_project_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX projects_cost_project_id ON projects_cost USING btree (project_id);


--
-- Name: provider_datasources_providerdatasource_provider_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX provider_datasources_providerdatasource_provider_id ON provider_datasources_providerdatasource USING btree (provider_id);


--
-- Name: reports_report_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX reports_report_customer_id ON reports_report USING btree (customer_id);


--
-- Name: rules_dateexception_rule_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX rules_dateexception_rule_id ON rules_dateexception USING btree (rule_id);


--
-- Name: rules_emailaction_rule_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX rules_emailaction_rule_id ON rules_emailaction USING btree (rule_id);


--
-- Name: rules_indexinvariant_index_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX rules_indexinvariant_index_id ON rules_indexinvariant USING btree (index_id);


--
-- Name: rules_indexinvariant_rule_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX rules_indexinvariant_rule_id ON rules_indexinvariant USING btree (rule_id);


--
-- Name: rules_inputinvariant_data_series_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX rules_inputinvariant_data_series_id ON rules_inputinvariant USING btree (data_series_id);


--
-- Name: rules_inputinvariant_rule_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX rules_inputinvariant_rule_id ON rules_inputinvariant USING btree (rule_id);


--
-- Name: rules_minimizerule_index_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX rules_minimizerule_index_id ON rules_minimizerule USING btree (index_id);


--
-- Name: rules_phoneaction_rule_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX rules_phoneaction_rule_id ON rules_phoneaction USING btree (rule_id);


--
-- Name: rules_relayaction_meter_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX rules_relayaction_meter_id ON rules_relayaction USING btree (meter_id);


--
-- Name: rules_relayaction_rule_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX rules_relayaction_rule_id ON rules_relayaction USING btree (rule_id);


--
-- Name: rules_userrule_content_type_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX rules_userrule_content_type_id ON rules_userrule USING btree (content_type_id);


--
-- Name: rules_userrule_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX rules_userrule_customer_id ON rules_userrule USING btree (customer_id);


--
-- Name: salesopportunities_activityentry_creator_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_activityentry_creator_id ON salesopportunities_activityentry USING btree (creator_id);


--
-- Name: salesopportunities_activityentry_salesopportunity_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_activityentry_salesopportunity_id ON salesopportunities_activityentry USING btree (salesopportunity_id);


--
-- Name: salesopportunities_industrytypesavings_industry_type_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_industrytypesavings_industry_type_id ON salesopportunities_industrytypesavings USING btree (industry_type_id);


--
-- Name: salesopportunities_industrytypeusedistribution_industry_type_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_industrytypeusedistribution_industry_type_id ON salesopportunities_industrytypeusedistribution USING btree (industry_type_id);


--
-- Name: salesopportunities_salesopportunity_created_by_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_salesopportunity_created_by_id ON salesopportunities_salesopportunity USING btree (created_by_id);


--
-- Name: salesopportunities_salesopportunity_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_salesopportunity_customer_id ON salesopportunities_salesopportunity USING btree (customer_id);


--
-- Name: salesopportunities_salesopportunity_floorplans_floorplan_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_salesopportunity_floorplans_floorplan_id ON salesopportunities_salesopportunity_floorplans USING btree (floorplan_id);


--
-- Name: salesopportunities_salesopportunity_floorplans_salesopportue3b6; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_salesopportunity_floorplans_salesopportue3b6 ON salesopportunities_salesopportunity_floorplans USING btree (salesopportunity_id);


--
-- Name: salesopportunities_salesopportunity_industry_type_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_salesopportunity_industry_type_id ON salesopportunities_salesopportunity USING btree (industry_type_id);


--
-- Name: salesopportunities_salesopportunity_sales_officer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_salesopportunity_sales_officer_id ON salesopportunities_salesopportunity USING btree (sales_officer_id);


--
-- Name: salesopportunities_salesopportunity_sizing_officer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_salesopportunity_sizing_officer_id ON salesopportunities_salesopportunity USING btree (sizing_officer_id);


--
-- Name: salesopportunities_salesopportunitysavings_sales_opportunity_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_salesopportunitysavings_sales_opportunity_id ON salesopportunities_salesopportunitysavings USING btree (sales_opportunity_id);


--
-- Name: salesopportunities_salesopportunityusedistribution_sales_op24c0; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_salesopportunityusedistribution_sales_op24c0 ON salesopportunities_salesopportunityusedistribution USING btree (sales_opportunity_id);


--
-- Name: salesopportunities_surveyinstruction_sales_opportunity_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_surveyinstruction_sales_opportunity_id ON salesopportunities_surveyinstruction USING btree (sales_opportunity_id);


--
-- Name: salesopportunities_task_assigned_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_task_assigned_id ON salesopportunities_task USING btree (assigned_id);


--
-- Name: salesopportunities_task_sales_opportunity_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX salesopportunities_task_sales_opportunity_id ON salesopportunities_task USING btree (sales_opportunity_id);


--
-- Name: suppliers_supplier_provider_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX suppliers_supplier_provider_id ON suppliers_supplier USING btree (provider_id);


--
-- Name: system_health_site_healthreport_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX system_health_site_healthreport_customer_id ON system_health_site_healthreport USING btree (customer_id);


--
-- Name: tariffs_period_datasequence_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX tariffs_period_datasequence_id ON tariffs_period USING btree (datasequence_id);


--
-- Name: tariffs_period_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX tariffs_period_subclass_id ON tariffs_period USING btree (subclass_id);


--
-- Name: tariffs_spotpriceperiod_spotprice_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX tariffs_spotpriceperiod_spotprice_id ON tariffs_spotpriceperiod USING btree (spotprice_id);


--
-- Name: tariffs_tariff_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX tariffs_tariff_customer_id ON tariffs_tariff USING btree (customer_id);


--
-- Name: tariffs_tariff_subclass_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX tariffs_tariff_subclass_id ON tariffs_tariff USING btree (subclass_id);


--
-- Name: token_auth_tokendata_key_like; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX token_auth_tokendata_key_like ON token_auth_tokendata USING btree (key varchar_pattern_ops);


--
-- Name: users_user_customer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX users_user_customer_id ON users_user USING btree (customer_id);


--
-- Name: users_user_provider_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX users_user_provider_id ON users_user USING btree (provider_id);


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: benchmarkproject_id_refs_id_2357c266; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projects_benchmarkproject_baseline_measurement_points
    ADD CONSTRAINT benchmarkproject_id_refs_id_2357c266 FOREIGN KEY (benchmarkproject_id) REFERENCES projects_benchmarkproject(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: benchmarkproject_id_refs_id_35a2b907; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projects_benchmarkproject_result_measurement_points
    ADD CONSTRAINT benchmarkproject_id_refs_id_35a2b907 FOREIGN KEY (benchmarkproject_id) REFERENCES projects_benchmarkproject(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: co2conversions_co2conversion_mainconsumption_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY co2conversions_co2conversion
    ADD CONSTRAINT co2conversions_co2conversion_mainconsumption_id_fkey FOREIGN KEY (mainconsumption_id) REFERENCES consumptions_mainconsumption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: co2conversions_dynamicco2conversion_co2conversion_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY co2conversions_dynamicco2conversion
    ADD CONSTRAINT co2conversions_dynamicco2conversion_co2conversion_ptr_id_fkey FOREIGN KEY (co2conversion_ptr_id) REFERENCES co2conversions_co2conversion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: co2conversions_dynamicco2conversion_datasource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY co2conversions_dynamicco2conversion
    ADD CONSTRAINT co2conversions_dynamicco2conversion_datasource_id_fkey FOREIGN KEY (datasource_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: co2conversions_fixedco2conversion_co2conversion_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY co2conversions_fixedco2conversion
    ADD CONSTRAINT co2conversions_fixedco2conversion_co2conversion_ptr_id_fkey FOREIGN KEY (co2conversion_ptr_id) REFERENCES co2conversions_co2conversion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptiongroup_id_refs_id_5a3f2c8c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_consumptiongroup_consumptions
    ADD CONSTRAINT consumptiongroup_id_refs_id_5a3f2c8c FOREIGN KEY (consumptiongroup_id) REFERENCES consumptions_consumptiongroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_consumption_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_consumption
    ADD CONSTRAINT consumptions_consumption_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_consumption_volumetoenergyconversion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_consumption
    ADD CONSTRAINT consumptions_consumption_volumetoenergyconversion_id_fkey FOREIGN KEY (volumetoenergyconversion_id) REFERENCES datasequences_energypervolumedatasequence(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_consumptiongroup_consumptions_consumption_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_consumptiongroup_consumptions
    ADD CONSTRAINT consumptions_consumptiongroup_consumptions_consumption_id_fkey FOREIGN KEY (consumption_id) REFERENCES consumptions_consumption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_consumptiongroup_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_consumptiongroup
    ADD CONSTRAINT consumptions_consumptiongroup_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_consumptiongroup_mainconsumption_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_consumptiongroup
    ADD CONSTRAINT consumptions_consumptiongroup_mainconsumption_id_fkey FOREIGN KEY (mainconsumption_id) REFERENCES consumptions_mainconsumption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_mainconsumption_consumptions_consumption_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_mainconsumption_consumptions
    ADD CONSTRAINT consumptions_mainconsumption_consumptions_consumption_id_fkey FOREIGN KEY (consumption_id) REFERENCES consumptions_consumption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_mainconsumption_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_mainconsumption
    ADD CONSTRAINT consumptions_mainconsumption_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_nonpulseperiod_datasource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_nonpulseperiod
    ADD CONSTRAINT consumptions_nonpulseperiod_datasource_id_fkey FOREIGN KEY (datasource_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_nonpulseperiod_period_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_nonpulseperiod
    ADD CONSTRAINT consumptions_nonpulseperiod_period_ptr_id_fkey FOREIGN KEY (period_ptr_id) REFERENCES consumptions_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_offlinetolerance_datasequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_offlinetolerance
    ADD CONSTRAINT consumptions_offlinetolerance_datasequence_id_fkey FOREIGN KEY (datasequence_id) REFERENCES consumptions_consumption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_period_datasequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_period
    ADD CONSTRAINT consumptions_period_datasequence_id_fkey FOREIGN KEY (datasequence_id) REFERENCES consumptions_consumption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_pulseperiod_datasource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_pulseperiod
    ADD CONSTRAINT consumptions_pulseperiod_datasource_id_fkey FOREIGN KEY (datasource_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_pulseperiod_period_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_pulseperiod
    ADD CONSTRAINT consumptions_pulseperiod_period_ptr_id_fkey FOREIGN KEY (period_ptr_id) REFERENCES consumptions_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: consumptions_singlevalueperiod_period_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_singlevalueperiod
    ADD CONSTRAINT consumptions_singlevalueperiod_period_ptr_id_fkey FOREIGN KEY (period_ptr_id) REFERENCES consumptions_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_442a446d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_userrule
    ADD CONSTRAINT content_type_id_refs_id_442a446d FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_88c9f6f6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY encryption_encryptionkey
    ADD CONSTRAINT content_type_id_refs_id_88c9f6f6 FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_d043b34a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_d043b34a FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cost_compensation_id_refs_id_9a4b788b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_mainconsumption
    ADD CONSTRAINT cost_compensation_id_refs_id_9a4b788b FOREIGN KEY (cost_compensation_id) REFERENCES cost_compensations_costcompensation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cost_compensation_id_refs_id_aaf44a7b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_consumptiongroup
    ADD CONSTRAINT cost_compensation_id_refs_id_aaf44a7b FOREIGN KEY (cost_compensation_id) REFERENCES cost_compensations_costcompensation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cost_compensations_costcompensation_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cost_compensations_costcompensation
    ADD CONSTRAINT cost_compensations_costcompensation_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cost_compensations_fixedcompensationperiod_period_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cost_compensations_fixedcompensationperiod
    ADD CONSTRAINT cost_compensations_fixedcompensationperiod_period_ptr_id_fkey FOREIGN KEY (period_ptr_id) REFERENCES cost_compensations_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cost_compensations_period_datasequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cost_compensations_period
    ADD CONSTRAINT cost_compensations_period_datasequence_id_fkey FOREIGN KEY (datasequence_id) REFERENCES cost_compensations_costcompensation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customer_datasources_customerdatasource_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customer_datasources_customerdatasource
    ADD CONSTRAINT customer_datasources_customerdatasource_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customer_datasources_customerdatasource_datasource_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customer_datasources_customerdatasource
    ADD CONSTRAINT customer_datasources_customerdatasource_datasource_ptr_id_fkey FOREIGN KEY (datasource_ptr_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customer_id_refs_id_28b953d5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_user
    ADD CONSTRAINT customer_id_refs_id_28b953d5 FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customer_id_refs_id_2c1235cc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_customer_industry_types
    ADD CONSTRAINT customer_id_refs_id_2c1235cc FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_collection_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_collection
    ADD CONSTRAINT customers_collection_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_collection_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_collection
    ADD CONSTRAINT customers_collection_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES customers_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_customer_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_customer
    ADD CONSTRAINT customers_customer_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES users_user(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_location_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_location
    ADD CONSTRAINT customers_location_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_location_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_location
    ADD CONSTRAINT customers_location_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES customers_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_userprofile_collections_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_userprofile_collections
    ADD CONSTRAINT customers_userprofile_collections_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES customers_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_userprofile_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_userprofile
    ADD CONSTRAINT customers_userprofile_user_id_fkey FOREIGN KEY (user_id) REFERENCES users_user(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dataneeds_dataneed_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dataneeds_dataneed
    ADD CONSTRAINT dataneeds_dataneed_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dataneeds_energyusedataneed_dataneed_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dataneeds_energyusedataneed
    ADD CONSTRAINT dataneeds_energyusedataneed_dataneed_ptr_id_fkey FOREIGN KEY (dataneed_ptr_id) REFERENCES dataneeds_dataneed(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dataneeds_mainconsumptiondataneed_dataneed_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dataneeds_mainconsumptiondataneed
    ADD CONSTRAINT dataneeds_mainconsumptiondataneed_dataneed_ptr_id_fkey FOREIGN KEY (dataneed_ptr_id) REFERENCES dataneeds_dataneed(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dataneeds_mainconsumptiondataneed_mainconsumption_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dataneeds_mainconsumptiondataneed
    ADD CONSTRAINT dataneeds_mainconsumptiondataneed_mainconsumption_id_fkey FOREIGN KEY (mainconsumption_id) REFERENCES consumptions_mainconsumption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dataneeds_productiongroupdataneed_dataneed_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dataneeds_productiongroupdataneed
    ADD CONSTRAINT dataneeds_productiongroupdataneed_dataneed_ptr_id_fkey FOREIGN KEY (dataneed_ptr_id) REFERENCES dataneeds_dataneed(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dataneeds_productiongroupdataneed_productiongroup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dataneeds_productiongroupdataneed
    ADD CONSTRAINT dataneeds_productiongroupdataneed_productiongroup_id_fkey FOREIGN KEY (productiongroup_id) REFERENCES productions_productiongroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequence_adapters_consumptionaccumul_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequence_adapters_consumptionaccumulationadapter
    ADD CONSTRAINT datasequence_adapters_consumptionaccumul_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequence_adapters_consumptionaccumulat_datasequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequence_adapters_consumptionaccumulationadapter
    ADD CONSTRAINT datasequence_adapters_consumptionaccumulat_datasequence_id_fkey FOREIGN KEY (datasequence_id) REFERENCES consumptions_consumption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequence_adapters_nonaccumulationada_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequence_adapters_nonaccumulationadapter
    ADD CONSTRAINT datasequence_adapters_nonaccumulationada_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequence_adapters_nonaccumulationadapt_datasequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequence_adapters_nonaccumulationadapter
    ADD CONSTRAINT datasequence_adapters_nonaccumulationadapt_datasequence_id_fkey FOREIGN KEY (datasequence_id) REFERENCES datasequences_nonaccumulationdatasequence(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequence_adapters_productionaccumula_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequence_adapters_productionaccumulationadapter
    ADD CONSTRAINT datasequence_adapters_productionaccumula_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequence_adapters_productionaccumulati_datasequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequence_adapters_productionaccumulationadapter
    ADD CONSTRAINT datasequence_adapters_productionaccumulati_datasequence_id_fkey FOREIGN KEY (datasequence_id) REFERENCES productions_production(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequences_energypervolumedatasequence_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_energypervolumedatasequence
    ADD CONSTRAINT datasequences_energypervolumedatasequence_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequences_energypervolumeperiod_datasequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_energypervolumeperiod
    ADD CONSTRAINT datasequences_energypervolumeperiod_datasequence_id_fkey FOREIGN KEY (datasequence_id) REFERENCES datasequences_energypervolumedatasequence(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequences_energypervolumeperiod_datasource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_energypervolumeperiod
    ADD CONSTRAINT datasequences_energypervolumeperiod_datasource_id_fkey FOREIGN KEY (datasource_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequences_nonaccumulationdatasequence_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_nonaccumulationdatasequence
    ADD CONSTRAINT datasequences_nonaccumulationdatasequence_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequences_nonaccumulationofflinetolera_datasequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_nonaccumulationofflinetolerance
    ADD CONSTRAINT datasequences_nonaccumulationofflinetolera_datasequence_id_fkey FOREIGN KEY (datasequence_id) REFERENCES datasequences_nonaccumulationdatasequence(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequences_nonaccumulationperiod_datasequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_nonaccumulationperiod
    ADD CONSTRAINT datasequences_nonaccumulationperiod_datasequence_id_fkey FOREIGN KEY (datasequence_id) REFERENCES datasequences_nonaccumulationdatasequence(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasequences_nonaccumulationperiod_datasource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_nonaccumulationperiod
    ADD CONSTRAINT datasequences_nonaccumulationperiod_datasource_id_fkey FOREIGN KEY (datasource_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dataseries_ptr_id_refs_id_113779b3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_index
    ADD CONSTRAINT dataseries_ptr_id_refs_id_113779b3 FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasource_id_refs_id_2434756f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY condensing_houraccumulateddata
    ADD CONSTRAINT datasource_id_refs_id_2434756f FOREIGN KEY (datasource_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasource_id_refs_id_60d85b99; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY condensing_fiveminuteaccumulateddata
    ADD CONSTRAINT datasource_id_refs_id_60d85b99 FOREIGN KEY (datasource_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datasources_rawdata_datasource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasources_rawdata
    ADD CONSTRAINT datasources_rawdata_datasource_id_fkey FOREIGN KEY (datasource_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: devices_agent_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_agent
    ADD CONSTRAINT devices_agent_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: devices_agent_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_agent
    ADD CONSTRAINT devices_agent_location_id_fkey FOREIGN KEY (location_id) REFERENCES customers_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: devices_agentevent_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_agentevent
    ADD CONSTRAINT devices_agentevent_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES devices_agent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: devices_agentstatechange_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_agentstatechange
    ADD CONSTRAINT devices_agentstatechange_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES devices_agent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: devices_meter_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_meter
    ADD CONSTRAINT devices_meter_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES devices_agent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: devices_meter_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_meter
    ADD CONSTRAINT devices_meter_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: devices_meter_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_meter
    ADD CONSTRAINT devices_meter_location_id_fkey FOREIGN KEY (location_id) REFERENCES customers_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: devices_meterstatechange_meter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_meterstatechange
    ADD CONSTRAINT devices_meterstatechange_meter_id_fkey FOREIGN KEY (meter_id) REFERENCES devices_meter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: devices_physicalinput_customerdatasource_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_physicalinput
    ADD CONSTRAINT devices_physicalinput_customerdatasource_ptr_id_fkey FOREIGN KEY (customerdatasource_ptr_id) REFERENCES customer_datasources_customerdatasource(datasource_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: devices_physicalinput_meter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY devices_physicalinput
    ADD CONSTRAINT devices_physicalinput_meter_id_fkey FOREIGN KEY (meter_id) REFERENCES devices_meter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: display_widgets_dashboardwidget_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY display_widgets_dashboardwidget
    ADD CONSTRAINT display_widgets_dashboardwidget_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES customers_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: display_widgets_dashboardwidget_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY display_widgets_dashboardwidget
    ADD CONSTRAINT display_widgets_dashboardwidget_user_id_fkey FOREIGN KEY (user_id) REFERENCES users_user(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djcelery_periodictask_crontab_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_periodictask
    ADD CONSTRAINT djcelery_periodictask_crontab_id_fkey FOREIGN KEY (crontab_id) REFERENCES djcelery_crontabschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djcelery_periodictask_interval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_periodictask
    ADD CONSTRAINT djcelery_periodictask_interval_id_fkey FOREIGN KEY (interval_id) REFERENCES djcelery_intervalschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djcelery_taskstate_worker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY djcelery_taskstate
    ADD CONSTRAINT djcelery_taskstate_worker_id_fkey FOREIGN KEY (worker_id) REFERENCES djcelery_workerstate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: electricity_tariff_id_refs_id_a3d5f060; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_customer
    ADD CONSTRAINT electricity_tariff_id_refs_id_a3d5f060 FOREIGN KEY (electricity_tariff_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_districtheatingconsu_salesopportunity_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_districtheatingconsumptionarea
    ADD CONSTRAINT energy_breakdown_districtheatingconsu_salesopportunity_id_fkey1 FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_districtheatingconsum_salesopportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_districtheatingconsumptiontotal
    ADD CONSTRAINT energy_breakdown_districtheatingconsum_salesopportunity_id_fkey FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_districtheatingconsumpti_energyusearea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_districtheatingconsumptionarea
    ADD CONSTRAINT energy_breakdown_districtheatingconsumpti_energyusearea_id_fkey FOREIGN KEY (energyusearea_id) REFERENCES installation_surveys_energyusearea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_electricityconsumpti_salesopportunity_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_electricityconsumptionarea
    ADD CONSTRAINT energy_breakdown_electricityconsumpti_salesopportunity_id_fkey1 FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_electricityconsumptio_salesopportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_electricityconsumptiontotal
    ADD CONSTRAINT energy_breakdown_electricityconsumptio_salesopportunity_id_fkey FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_electricityconsumptionar_energyusearea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_electricityconsumptionarea
    ADD CONSTRAINT energy_breakdown_electricityconsumptionar_energyusearea_id_fkey FOREIGN KEY (energyusearea_id) REFERENCES installation_surveys_energyusearea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_fuelconsumptionarea_energyusearea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_fuelconsumptionarea
    ADD CONSTRAINT energy_breakdown_fuelconsumptionarea_energyusearea_id_fkey FOREIGN KEY (energyusearea_id) REFERENCES installation_surveys_energyusearea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_fuelconsumptionarea_salesopportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_fuelconsumptionarea
    ADD CONSTRAINT energy_breakdown_fuelconsumptionarea_salesopportunity_id_fkey FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_fuelconsumptiontotal_salesopportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_fuelconsumptiontotal
    ADD CONSTRAINT energy_breakdown_fuelconsumptiontotal_salesopportunity_id_fkey FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_proposedaction_energyusearea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_proposedaction
    ADD CONSTRAINT energy_breakdown_proposedaction_energyusearea_id_fkey FOREIGN KEY (energyusearea_id) REFERENCES installation_surveys_energyusearea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_proposedaction_salesopportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_proposedaction
    ADD CONSTRAINT energy_breakdown_proposedaction_salesopportunity_id_fkey FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_waterconsumptionarea_energyusearea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_waterconsumptionarea
    ADD CONSTRAINT energy_breakdown_waterconsumptionarea_energyusearea_id_fkey FOREIGN KEY (energyusearea_id) REFERENCES installation_surveys_energyusearea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_waterconsumptionarea_salesopportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_waterconsumptionarea
    ADD CONSTRAINT energy_breakdown_waterconsumptionarea_salesopportunity_id_fkey FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_breakdown_waterconsumptiontotal_salesopportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_breakdown_waterconsumptiontotal
    ADD CONSTRAINT energy_breakdown_waterconsumptiontotal_salesopportunity_id_fkey FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_driver_id_refs_id_54d03831; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY enpi_reports_enpiusearea
    ADD CONSTRAINT energy_driver_id_refs_id_54d03831 FOREIGN KEY (energy_driver_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_use_reports_energyusea_consumptionmeasurementpoint__fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_use_reports_energyusearea_measurement_points
    ADD CONSTRAINT energy_use_reports_energyusea_consumptionmeasurementpoint__fkey FOREIGN KEY (consumptionmeasurementpoint_id) REFERENCES customers_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_use_reports_energyusearea_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_use_reports_energyusearea
    ADD CONSTRAINT energy_use_reports_energyusearea_report_id_fkey FOREIGN KEY (report_id) REFERENCES energy_use_reports_energyusereport(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_use_reports_energyuser_consumptionmeasurementpoint__fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_use_reports_energyusereport_main_measurement_points
    ADD CONSTRAINT energy_use_reports_energyuser_consumptionmeasurementpoint__fkey FOREIGN KEY (consumptionmeasurementpoint_id) REFERENCES customers_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energy_use_reports_energyusereport_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_use_reports_energyusereport
    ADD CONSTRAINT energy_use_reports_energyusereport_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energyperformances_energyperformance_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_energyperformance
    ADD CONSTRAINT energyperformances_energyperformance_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energyperformances_productionener_energyperformance_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_productionenergyperformance
    ADD CONSTRAINT energyperformances_productionener_energyperformance_ptr_id_fkey FOREIGN KEY (energyperformance_ptr_id) REFERENCES energyperformances_energyperformance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energyperformances_productionenergyper_consumptiongroup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_productionenergyperformance_consumptiong23ca
    ADD CONSTRAINT energyperformances_productionenergyper_consumptiongroup_id_fkey FOREIGN KEY (consumptiongroup_id) REFERENCES consumptions_consumptiongroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energyperformances_productionenergyperf_productiongroup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_productionenergyperformance_productiongroups
    ADD CONSTRAINT energyperformances_productionenergyperf_productiongroup_id_fkey FOREIGN KEY (productiongroup_id) REFERENCES productions_productiongroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energyperformances_timeenergyperf_energyperformance_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_timeenergyperformance
    ADD CONSTRAINT energyperformances_timeenergyperf_energyperformance_ptr_id_fkey FOREIGN KEY (energyperformance_ptr_id) REFERENCES energyperformances_energyperformance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energyperformances_timeenergyperforman_consumptiongroup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_timeenergyperformance_consumptiongroups
    ADD CONSTRAINT energyperformances_timeenergyperforman_consumptiongroup_id_fkey FOREIGN KEY (consumptiongroup_id) REFERENCES consumptions_consumptiongroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energyuse_id_refs_consumptiongroup_ptr_id_44725248; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dataneeds_energyusedataneed
    ADD CONSTRAINT energyuse_id_refs_consumptiongroup_ptr_id_44725248 FOREIGN KEY (energyuse_id) REFERENCES energyuses_energyuse(consumptiongroup_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energyusearea_id_refs_id_6f4dd6ef; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_use_reports_energyusearea_measurement_points
    ADD CONSTRAINT energyusearea_id_refs_id_6f4dd6ef FOREIGN KEY (energyusearea_id) REFERENCES energy_use_reports_energyusearea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energyusereport_id_refs_id_f5b16fa2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energy_use_reports_energyusereport_main_measurement_points
    ADD CONSTRAINT energyusereport_id_refs_id_f5b16fa2 FOREIGN KEY (energyusereport_id) REFERENCES energy_use_reports_energyusereport(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: energyuses_energyuse_consumptiongroup_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyuses_energyuse
    ADD CONSTRAINT energyuses_energyuse_consumptiongroup_ptr_id_fkey FOREIGN KEY (consumptiongroup_ptr_id) REFERENCES consumptions_consumptiongroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: enpi_reports_enpireport_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY enpi_reports_enpireport
    ADD CONSTRAINT enpi_reports_enpireport_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: enpi_reports_enpiusearea_meas_consumptionmeasurementpoint__fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY enpi_reports_enpiusearea_measurement_points
    ADD CONSTRAINT enpi_reports_enpiusearea_meas_consumptionmeasurementpoint__fkey FOREIGN KEY (consumptionmeasurementpoint_id) REFERENCES customers_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: enpi_reports_enpiusearea_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY enpi_reports_enpiusearea
    ADD CONSTRAINT enpi_reports_enpiusearea_report_id_fkey FOREIGN KEY (report_id) REFERENCES enpi_reports_enpireport(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: enpiusearea_id_refs_id_cc2e42ae; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY enpi_reports_enpiusearea_measurement_points
    ADD CONSTRAINT enpiusearea_id_refs_id_cc2e42ae FOREIGN KEY (enpiusearea_id) REFERENCES enpi_reports_enpiusearea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gas_tariff_id_refs_id_a3d5f060; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_customer
    ADD CONSTRAINT gas_tariff_id_refs_id_a3d5f060 FOREIGN KEY (gas_tariff_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: global_datasources_globaldatasource_datasource_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY global_datasources_globaldatasource
    ADD CONSTRAINT global_datasources_globaldatasource_datasource_ptr_id_fkey FOREIGN KEY (datasource_ptr_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_f4b32aac; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_f4b32aac FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: heat_tariff_id_refs_id_a3d5f060; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_customer
    ADD CONSTRAINT heat_tariff_id_refs_id_a3d5f060 FOREIGN KEY (heat_tariff_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: index_id_refs_dataseries_ptr_id_70090a01; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energinet_co2_modelbinding
    ADD CONSTRAINT index_id_refs_dataseries_ptr_id_70090a01 FOREIGN KEY (index_id) REFERENCES indexes_index(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: index_id_refs_dataseries_ptr_id_f5ca3ee7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY display_widgets_dashboardwidget
    ADD CONSTRAINT index_id_refs_dataseries_ptr_id_f5ca3ee7 FOREIGN KEY (index_id) REFERENCES indexes_index(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: indexes_datasourceindexadapter_datasource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_datasourceindexadapter
    ADD CONSTRAINT indexes_datasourceindexadapter_datasource_id_fkey FOREIGN KEY (datasource_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: indexes_datasourceindexadapter_index_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_datasourceindexadapter
    ADD CONSTRAINT indexes_datasourceindexadapter_index_ptr_id_fkey FOREIGN KEY (index_ptr_id) REFERENCES indexes_index(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: indexes_derivedindexperiod_index_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_derivedindexperiod
    ADD CONSTRAINT indexes_derivedindexperiod_index_id_fkey FOREIGN KEY (index_id) REFERENCES indexes_index(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: indexes_derivedindexperiod_other_index_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_derivedindexperiod
    ADD CONSTRAINT indexes_derivedindexperiod_other_index_id_fkey FOREIGN KEY (other_index_id) REFERENCES indexes_index(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: indexes_entry_index_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_entry
    ADD CONSTRAINT indexes_entry_index_id_fkey FOREIGN KEY (index_id) REFERENCES indexes_index(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: indexes_index_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_index
    ADD CONSTRAINT indexes_index_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES customers_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: indexes_seasonindexperiod_index_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_seasonindexperiod
    ADD CONSTRAINT indexes_seasonindexperiod_index_id_fkey FOREIGN KEY (index_id) REFERENCES indexes_index(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: indexes_spotmapping_index_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_spotmapping
    ADD CONSTRAINT indexes_spotmapping_index_id_fkey FOREIGN KEY (index_id) REFERENCES indexes_index(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: indexes_standardmonthindex_index_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indexes_standardmonthindex
    ADD CONSTRAINT indexes_standardmonthindex_index_ptr_id_fkey FOREIGN KEY (index_ptr_id) REFERENCES indexes_index(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: industrytype_id_refs_id_04f579e5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_customer_industry_types
    ADD CONSTRAINT industrytype_id_refs_id_04f579e5 FOREIGN KEY (industrytype_id) REFERENCES salesopportunities_industrytype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installation_surveys_billingmeter_salesopportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installation_surveys_billingmeter
    ADD CONSTRAINT installation_surveys_billingmeter_salesopportunity_id_fkey FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installation_surveys_billingmeterappendix_billingmeter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installation_surveys_billingmeterappendix
    ADD CONSTRAINT installation_surveys_billingmeterappendix_billingmeter_id_fkey FOREIGN KEY (billingmeter_id) REFERENCES installation_surveys_billingmeter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installation_surveys_energyusearea_salesopportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installation_surveys_energyusearea
    ADD CONSTRAINT installation_surveys_energyusearea_salesopportunity_id_fkey FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installation_surveys_proposedaction_energyusearea_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installation_surveys_proposedaction
    ADD CONSTRAINT installation_surveys_proposedaction_energyusearea_id_fkey FOREIGN KEY (energyusearea_id) REFERENCES installation_surveys_energyusearea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installation_surveys_proposedaction_salesopportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installation_surveys_proposedaction
    ADD CONSTRAINT installation_surveys_proposedaction_salesopportunity_id_fkey FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installation_surveys_workhours_salesopportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installation_surveys_workhours
    ADD CONSTRAINT installation_surveys_workhours_salesopportunity_id_fkey FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installation_type_id_refs_id_02a9b2e2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_historicalproduct
    ADD CONSTRAINT installation_type_id_refs_id_02a9b2e2 FOREIGN KEY (installation_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installation_type_id_refs_id_68d35f9e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_product
    ADD CONSTRAINT installation_type_id_refs_id_68d35f9e FOREIGN KEY (installation_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_floorplan_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_floorplan
    ADD CONSTRAINT installations_floorplan_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_gatewayinstallati_productinstallation_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_gatewayinstallation
    ADD CONSTRAINT installations_gatewayinstallati_productinstallation_ptr_id_fkey FOREIGN KEY (productinstallation_ptr_id) REFERENCES installations_productinstallation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_installationphoto_installation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_installationphoto
    ADD CONSTRAINT installations_installationphoto_installation_id_fkey FOREIGN KEY (installation_id) REFERENCES installations_productinstallation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_meterinstallation_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_meterinstallation
    ADD CONSTRAINT installations_meterinstallation_gateway_id_fkey FOREIGN KEY (gateway_id) REFERENCES installations_gatewayinstallation(productinstallation_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_meterinstallation_input_satisfie_dataneed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_meterinstallation_input_satisfies_dataneeds
    ADD CONSTRAINT installations_meterinstallation_input_satisfie_dataneed_id_fkey FOREIGN KEY (dataneed_id) REFERENCES dataneeds_dataneed(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_meterinstallation_productinstallation_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_meterinstallation
    ADD CONSTRAINT installations_meterinstallation_productinstallation_ptr_id_fkey FOREIGN KEY (productinstallation_ptr_id) REFERENCES installations_productinstallation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_productinstallation_floorplan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_productinstallation
    ADD CONSTRAINT installations_productinstallation_floorplan_id_fkey FOREIGN KEY (floorplan_id) REFERENCES installations_floorplan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_pulseemitterinsta_productinstallation_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_pulseemitterinstallation
    ADD CONSTRAINT installations_pulseemitterinsta_productinstallation_ptr_id_fkey FOREIGN KEY (productinstallation_ptr_id) REFERENCES installations_productinstallation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_pulseemitterinstallation_input_s_dataneed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_pulseemitterinstallation_input_satisfies_data7b36
    ADD CONSTRAINT installations_pulseemitterinstallation_input_s_dataneed_id_fkey FOREIGN KEY (dataneed_id) REFERENCES dataneeds_dataneed(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_repeaterinstallat_productinstallation_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_repeaterinstallation
    ADD CONSTRAINT installations_repeaterinstallat_productinstallation_ptr_id_fkey FOREIGN KEY (productinstallation_ptr_id) REFERENCES installations_productinstallation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_repeaterinstallation_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_repeaterinstallation
    ADD CONSTRAINT installations_repeaterinstallation_gateway_id_fkey FOREIGN KEY (gateway_id) REFERENCES installations_gatewayinstallation(productinstallation_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_tripleinputmeteri_productinstallation_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation
    ADD CONSTRAINT installations_tripleinputmeteri_productinstallation_ptr_id_fkey FOREIGN KEY (productinstallation_ptr_id) REFERENCES installations_productinstallation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_tripleinputmeterinstallation_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation
    ADD CONSTRAINT installations_tripleinputmeterinstallation_gateway_id_fkey FOREIGN KEY (gateway_id) REFERENCES installations_gatewayinstallation(productinstallation_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_tripleinputmeterinstallation_in_dataneed_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input2_satisfies1aad
    ADD CONSTRAINT installations_tripleinputmeterinstallation_in_dataneed_id_fkey1 FOREIGN KEY (dataneed_id) REFERENCES dataneeds_dataneed(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_tripleinputmeterinstallation_in_dataneed_id_fkey2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input1_satisfies0539
    ADD CONSTRAINT installations_tripleinputmeterinstallation_in_dataneed_id_fkey2 FOREIGN KEY (dataneed_id) REFERENCES dataneeds_dataneed(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_tripleinputmeterinstallation_inp_dataneed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input3_satisfies9eaa
    ADD CONSTRAINT installations_tripleinputmeterinstallation_inp_dataneed_id_fkey FOREIGN KEY (dataneed_id) REFERENCES dataneeds_dataneed(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_triplepulsecoll_input1_pulseemitterinstallat_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_triplepulsecollectorinstallation
    ADD CONSTRAINT installations_triplepulsecoll_input1_pulseemitterinstallat_fkey FOREIGN KEY (input1_pulseemitterinstallation_id) REFERENCES installations_pulseemitterinstallation(productinstallation_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_triplepulsecoll_input2_pulseemitterinstallat_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_triplepulsecollectorinstallation
    ADD CONSTRAINT installations_triplepulsecoll_input2_pulseemitterinstallat_fkey FOREIGN KEY (input2_pulseemitterinstallation_id) REFERENCES installations_pulseemitterinstallation(productinstallation_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_triplepulsecoll_input3_pulseemitterinstallat_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_triplepulsecollectorinstallation
    ADD CONSTRAINT installations_triplepulsecoll_input3_pulseemitterinstallat_fkey FOREIGN KEY (input3_pulseemitterinstallation_id) REFERENCES installations_pulseemitterinstallation(productinstallation_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_triplepulsecollec_productinstallation_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_triplepulsecollectorinstallation
    ADD CONSTRAINT installations_triplepulsecollec_productinstallation_ptr_id_fkey FOREIGN KEY (productinstallation_ptr_id) REFERENCES installations_productinstallation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: installations_triplepulsecollectorinstallation_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_triplepulsecollectorinstallation
    ADD CONSTRAINT installations_triplepulsecollectorinstallation_gateway_id_fkey FOREIGN KEY (gateway_id) REFERENCES installations_gatewayinstallation(productinstallation_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mainconsumption_id_refs_id_315024c6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_mainconsumption_consumptions
    ADD CONSTRAINT mainconsumption_id_refs_id_315024c6 FOREIGN KEY (mainconsumption_id) REFERENCES consumptions_mainconsumption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: manage_collections_collectionitem_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY manage_collections_collectionitem
    ADD CONSTRAINT manage_collections_collectionitem_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES customers_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: manage_collections_collectionitem_item_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY manage_collections_collectionitem
    ADD CONSTRAINT manage_collections_collectionitem_item_ptr_id_fkey FOREIGN KEY (item_ptr_id) REFERENCES manage_collections_item(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: manage_collections_floorplan_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY manage_collections_floorplan
    ADD CONSTRAINT manage_collections_floorplan_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES customers_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: manage_collections_infoitem_item_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY manage_collections_infoitem
    ADD CONSTRAINT manage_collections_infoitem_item_ptr_id_fkey FOREIGN KEY (item_ptr_id) REFERENCES manage_collections_item(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: manage_collections_item_floorplan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY manage_collections_item
    ADD CONSTRAINT manage_collections_item_floorplan_id_fkey FOREIGN KEY (floorplan_id) REFERENCES manage_collections_floorplan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: manual_reporting_manuallyreportedconsum_consumption_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY manual_reporting_manuallyreportedconsumption
    ADD CONSTRAINT manual_reporting_manuallyreportedconsum_consumption_ptr_id_fkey FOREIGN KEY (consumption_ptr_id) REFERENCES consumptions_consumption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: manual_reporting_manuallyreportedproduct_production_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY manual_reporting_manuallyreportedproduction
    ADD CONSTRAINT manual_reporting_manuallyreportedproduct_production_ptr_id_fkey FOREIGN KEY (production_ptr_id) REFERENCES productions_production(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_chain_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_chain
    ADD CONSTRAINT measurementpoints_chain_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_chainlink_chain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_chainlink
    ADD CONSTRAINT measurementpoints_chainlink_chain_id_fkey FOREIGN KEY (chain_id) REFERENCES measurementpoints_chain(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_chainlink_data_series_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_chainlink
    ADD CONSTRAINT measurementpoints_chainlink_data_series_id_fkey FOREIGN KEY (data_series_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_dataseries_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_dataseries
    ADD CONSTRAINT measurementpoints_dataseries_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_dataseries_graph_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_dataseries
    ADD CONSTRAINT measurementpoints_dataseries_graph_id_fkey FOREIGN KEY (graph_id) REFERENCES measurementpoints_graph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_degreedaycorrectio_standarddegreedays_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_degreedaycorrection
    ADD CONSTRAINT measurementpoints_degreedaycorrectio_standarddegreedays_id_fkey FOREIGN KEY (standarddegreedays_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_degreedaycorrection_consumption_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_degreedaycorrection
    ADD CONSTRAINT measurementpoints_degreedaycorrection_consumption_id_fkey FOREIGN KEY (consumption_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_degreedaycorrection_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_degreedaycorrection
    ADD CONSTRAINT measurementpoints_degreedaycorrection_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_degreedaycorrection_degreedays_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_degreedaycorrection
    ADD CONSTRAINT measurementpoints_degreedaycorrection_degreedays_id_fkey FOREIGN KEY (degreedays_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_graph_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_graph
    ADD CONSTRAINT measurementpoints_graph_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES customers_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_heatingdegreedays_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_heatingdegreedays
    ADD CONSTRAINT measurementpoints_heatingdegreedays_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_heatingdegreedays_derived_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_heatingdegreedays
    ADD CONSTRAINT measurementpoints_heatingdegreedays_derived_from_id_fkey FOREIGN KEY (derived_from_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_indexcalculation_consumption_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_indexcalculation
    ADD CONSTRAINT measurementpoints_indexcalculation_consumption_id_fkey FOREIGN KEY (consumption_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_indexcalculation_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_indexcalculation
    ADD CONSTRAINT measurementpoints_indexcalculation_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_indexcalculation_index_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_indexcalculation
    ADD CONSTRAINT measurementpoints_indexcalculation_index_id_fkey FOREIGN KEY (index_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_link_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_link
    ADD CONSTRAINT measurementpoints_link_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_link_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_link
    ADD CONSTRAINT measurementpoints_link_target_id_fkey FOREIGN KEY (target_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_meantemperaturechange_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_meantemperaturechange
    ADD CONSTRAINT measurementpoints_meantemperaturechange_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_meantemperaturechange_energy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_meantemperaturechange
    ADD CONSTRAINT measurementpoints_meantemperaturechange_energy_id_fkey FOREIGN KEY (energy_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_meantemperaturechange_volume_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_meantemperaturechange
    ADD CONSTRAINT measurementpoints_meantemperaturechange_volume_id_fkey FOREIGN KEY (volume_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_multiplication_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_multiplication
    ADD CONSTRAINT measurementpoints_multiplication_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_multiplication_source_data_series_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_multiplication
    ADD CONSTRAINT measurementpoints_multiplication_source_data_series_id_fkey FOREIGN KEY (source_data_series_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_piecewiseconstantinteg_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_piecewiseconstantintegral
    ADD CONSTRAINT measurementpoints_piecewiseconstantinteg_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_piecewiseconstantintegral_data_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_piecewiseconstantintegral
    ADD CONSTRAINT measurementpoints_piecewiseconstantintegral_data_id_fkey FOREIGN KEY (data_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_rateconversion_consumption_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_rateconversion
    ADD CONSTRAINT measurementpoints_rateconversion_consumption_id_fkey FOREIGN KEY (consumption_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_rateconversion_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_rateconversion
    ADD CONSTRAINT measurementpoints_rateconversion_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_simplelinearregression_data_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_simplelinearregression
    ADD CONSTRAINT measurementpoints_simplelinearregression_data_id_fkey FOREIGN KEY (data_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_simplelinearregression_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_simplelinearregression
    ADD CONSTRAINT measurementpoints_simplelinearregression_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_storeddata_data_series_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_storeddata
    ADD CONSTRAINT measurementpoints_storeddata_data_series_id_fkey FOREIGN KEY (data_series_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_summation_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_summation
    ADD CONSTRAINT measurementpoints_summation_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_summationterm_data_series_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_summationterm
    ADD CONSTRAINT measurementpoints_summationterm_data_series_id_fkey FOREIGN KEY (data_series_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_summationterm_summation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_summationterm
    ADD CONSTRAINT measurementpoints_summationterm_summation_id_fkey FOREIGN KEY (summation_id) REFERENCES measurementpoints_summation(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_utilization_consumption_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_utilization
    ADD CONSTRAINT measurementpoints_utilization_consumption_id_fkey FOREIGN KEY (consumption_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_utilization_dataseries_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_utilization
    ADD CONSTRAINT measurementpoints_utilization_dataseries_ptr_id_fkey FOREIGN KEY (dataseries_ptr_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurementpoints_utilization_needs_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_utilization
    ADD CONSTRAINT measurementpoints_utilization_needs_id_fkey FOREIGN KEY (needs_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: meterinstallation_id_refs_productinstallation_ptr_id_8284d35c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_meterinstallation_input_satisfies_dataneeds
    ADD CONSTRAINT meterinstallation_id_refs_productinstallation_ptr_id_8284d35c FOREIGN KEY (meterinstallation_id) REFERENCES installations_meterinstallation(productinstallation_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oil_tariff_id_refs_id_a3d5f060; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_customer
    ADD CONSTRAINT oil_tariff_id_refs_id_a3d5f060 FOREIGN KEY (oil_tariff_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: opportunities_opportunity_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY opportunities_opportunity
    ADD CONSTRAINT opportunities_opportunity_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: opportunity_id_refs_id_913cb336; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod_accepted_opportunities
    ADD CONSTRAINT opportunity_id_refs_id_913cb336 FOREIGN KEY (opportunity_id) REFERENCES opportunities_opportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: opportunity_id_refs_id_99faf1f6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod_rejected_opportunities
    ADD CONSTRAINT opportunity_id_refs_id_99faf1f6 FOREIGN KEY (opportunity_id) REFERENCES opportunities_opportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: processperiod_id_refs_id_4b57cac2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod_rejected_opportunities
    ADD CONSTRAINT processperiod_id_refs_id_4b57cac2 FOREIGN KEY (processperiod_id) REFERENCES processperiods_processperiod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: processperiod_id_refs_id_705e3baf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod_accepted_opportunities
    ADD CONSTRAINT processperiod_id_refs_id_705e3baf FOREIGN KEY (processperiod_id) REFERENCES processperiods_processperiod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: processperiod_id_refs_id_7d85d570; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod_significant_energyuses
    ADD CONSTRAINT processperiod_id_refs_id_7d85d570 FOREIGN KEY (processperiod_id) REFERENCES processperiods_processperiod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: processperiod_id_refs_id_e0c4840d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod_enpis
    ADD CONSTRAINT processperiod_id_refs_id_e0c4840d FOREIGN KEY (processperiod_id) REFERENCES processperiods_processperiod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: processperiods_processperiod_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod
    ADD CONSTRAINT processperiods_processperiod_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: processperiods_processperiod_enpis_energyperformance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod_enpis
    ADD CONSTRAINT processperiods_processperiod_enpis_energyperformance_id_fkey FOREIGN KEY (energyperformance_id) REFERENCES energyperformances_energyperformance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: processperiods_processperiod_significant_ener_energyuse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiod_significant_energyuses
    ADD CONSTRAINT processperiods_processperiod_significant_ener_energyuse_id_fkey FOREIGN KEY (energyuse_id) REFERENCES energyuses_energyuse(consumptiongroup_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: processperiods_processperiodgoal_energyperformance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiodgoal
    ADD CONSTRAINT processperiods_processperiodgoal_energyperformance_id_fkey FOREIGN KEY (energyperformance_id) REFERENCES energyperformances_energyperformance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: processperiods_processperiodgoal_processperiod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY processperiods_processperiodgoal
    ADD CONSTRAINT processperiods_processperiodgoal_processperiod_id_fkey FOREIGN KEY (processperiod_id) REFERENCES processperiods_processperiod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: product_id_refs_id_f48346e6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_productinstallation
    ADD CONSTRAINT product_id_refs_id_f48346e6 FOREIGN KEY (product_id) REFERENCES products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productionenergyperformance_id_refs_energyperformance_ptr_i5694; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_productionenergyperformance_productiongroups
    ADD CONSTRAINT productionenergyperformance_id_refs_energyperformance_ptr_i5694 FOREIGN KEY (productionenergyperformance_id) REFERENCES energyperformances_productionenergyperformance(energyperformance_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productionenergyperformance_id_refs_energyperformance_ptr_i5745; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_productionenergyperformance_consumptiong23ca
    ADD CONSTRAINT productionenergyperformance_id_refs_energyperformance_ptr_i5745 FOREIGN KEY (productionenergyperformance_id) REFERENCES energyperformances_productionenergyperformance(energyperformance_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productiongroup_id_refs_id_962fb0fc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_productiongroup_productions
    ADD CONSTRAINT productiongroup_id_refs_id_962fb0fc FOREIGN KEY (productiongroup_id) REFERENCES productions_productiongroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productions_nonpulseperiod_datasource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_nonpulseperiod
    ADD CONSTRAINT productions_nonpulseperiod_datasource_id_fkey FOREIGN KEY (datasource_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productions_nonpulseperiod_period_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_nonpulseperiod
    ADD CONSTRAINT productions_nonpulseperiod_period_ptr_id_fkey FOREIGN KEY (period_ptr_id) REFERENCES productions_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productions_offlinetolerance_datasequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_offlinetolerance
    ADD CONSTRAINT productions_offlinetolerance_datasequence_id_fkey FOREIGN KEY (datasequence_id) REFERENCES productions_production(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productions_period_datasequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_period
    ADD CONSTRAINT productions_period_datasequence_id_fkey FOREIGN KEY (datasequence_id) REFERENCES productions_production(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productions_production_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_production
    ADD CONSTRAINT productions_production_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productions_productiongroup_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_productiongroup
    ADD CONSTRAINT productions_productiongroup_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productions_productiongroup_productions_production_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_productiongroup_productions
    ADD CONSTRAINT productions_productiongroup_productions_production_id_fkey FOREIGN KEY (production_id) REFERENCES productions_production(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productions_pulseperiod_datasource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_pulseperiod
    ADD CONSTRAINT productions_pulseperiod_datasource_id_fkey FOREIGN KEY (datasource_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productions_pulseperiod_period_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_pulseperiod
    ADD CONSTRAINT productions_pulseperiod_period_ptr_id_fkey FOREIGN KEY (period_ptr_id) REFERENCES productions_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: productions_singlevalueperiod_period_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_singlevalueperiod
    ADD CONSTRAINT productions_singlevalueperiod_period_ptr_id_fkey FOREIGN KEY (period_ptr_id) REFERENCES productions_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_historicalproduct_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_historicalproduct
    ADD CONSTRAINT products_historicalproduct_category_id_fkey FOREIGN KEY (category_id) REFERENCES products_productcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_historicalproduct_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_historicalproduct
    ADD CONSTRAINT products_historicalproduct_product_id_fkey FOREIGN KEY (product_id) REFERENCES products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_historicalproduct_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_historicalproduct
    ADD CONSTRAINT products_historicalproduct_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES providers_provider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_historicalproduct_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_historicalproduct
    ADD CONSTRAINT products_historicalproduct_user_id_fkey FOREIGN KEY (user_id) REFERENCES users_user(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_product
    ADD CONSTRAINT products_product_category_id_fkey FOREIGN KEY (category_id) REFERENCES products_productcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_product
    ADD CONSTRAINT products_product_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES providers_provider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_productcategory_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_productcategory
    ADD CONSTRAINT products_productcategory_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES providers_provider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_additionalsaving_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projects_additionalsaving
    ADD CONSTRAINT projects_additionalsaving_project_id_fkey FOREIGN KEY (project_id) REFERENCES projects_benchmarkproject(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_benchmarkproject_bas_consumptionmeasurementpoint__fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projects_benchmarkproject_baseline_measurement_points
    ADD CONSTRAINT projects_benchmarkproject_bas_consumptionmeasurementpoint__fkey FOREIGN KEY (consumptionmeasurementpoint_id) REFERENCES customers_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_benchmarkproject_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projects_benchmarkproject
    ADD CONSTRAINT projects_benchmarkproject_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_benchmarkproject_res_consumptionmeasurementpoint__fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projects_benchmarkproject_result_measurement_points
    ADD CONSTRAINT projects_benchmarkproject_res_consumptionmeasurementpoint__fkey FOREIGN KEY (consumptionmeasurementpoint_id) REFERENCES customers_collection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: projects_cost_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY projects_cost
    ADD CONSTRAINT projects_cost_project_id_fkey FOREIGN KEY (project_id) REFERENCES projects_benchmarkproject(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: provider_datasources_providerdatasource_datasource_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY provider_datasources_providerdatasource
    ADD CONSTRAINT provider_datasources_providerdatasource_datasource_ptr_id_fkey FOREIGN KEY (datasource_ptr_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: provider_datasources_providerdatasource_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY provider_datasources_providerdatasource
    ADD CONSTRAINT provider_datasources_providerdatasource_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES providers_provider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: provider_id_refs_id_9a36e572; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_customer
    ADD CONSTRAINT provider_id_refs_id_9a36e572 FOREIGN KEY (provider_id) REFERENCES providers_provider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: provider_id_refs_id_ff8566f3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_user
    ADD CONSTRAINT provider_id_refs_id_ff8566f3 FOREIGN KEY (provider_id) REFERENCES providers_provider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pulseemitterinstallation_id_refs_productinstallation_ptr_id7855; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_pulseemitterinstallation_input_satisfies_data7b36
    ADD CONSTRAINT pulseemitterinstallation_id_refs_productinstallation_ptr_id7855 FOREIGN KEY (pulseemitterinstallation_id) REFERENCES installations_pulseemitterinstallation(productinstallation_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: relay_id_refs_id_4dc04d6b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_collection
    ADD CONSTRAINT relay_id_refs_id_4dc04d6b FOREIGN KEY (relay_id) REFERENCES devices_meter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_report_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY reports_report
    ADD CONSTRAINT reports_report_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_dateexception_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_dateexception
    ADD CONSTRAINT rules_dateexception_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES rules_userrule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_emailaction_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_emailaction
    ADD CONSTRAINT rules_emailaction_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES rules_userrule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_indexinvariant_index_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_indexinvariant
    ADD CONSTRAINT rules_indexinvariant_index_id_fkey FOREIGN KEY (index_id) REFERENCES indexes_index(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_indexinvariant_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_indexinvariant
    ADD CONSTRAINT rules_indexinvariant_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES rules_triggeredrule(userrule_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_inputinvariant_data_series_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_inputinvariant
    ADD CONSTRAINT rules_inputinvariant_data_series_id_fkey FOREIGN KEY (data_series_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_inputinvariant_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_inputinvariant
    ADD CONSTRAINT rules_inputinvariant_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES rules_triggeredrule(userrule_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_minimizerule_index_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_minimizerule
    ADD CONSTRAINT rules_minimizerule_index_id_fkey FOREIGN KEY (index_id) REFERENCES indexes_index(dataseries_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_minimizerule_userrule_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_minimizerule
    ADD CONSTRAINT rules_minimizerule_userrule_ptr_id_fkey FOREIGN KEY (userrule_ptr_id) REFERENCES rules_userrule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_phoneaction_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_phoneaction
    ADD CONSTRAINT rules_phoneaction_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES rules_userrule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_relayaction_meter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_relayaction
    ADD CONSTRAINT rules_relayaction_meter_id_fkey FOREIGN KEY (meter_id) REFERENCES devices_meter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_relayaction_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_relayaction
    ADD CONSTRAINT rules_relayaction_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES rules_userrule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_triggeredrule_userrule_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_triggeredrule
    ADD CONSTRAINT rules_triggeredrule_userrule_ptr_id_fkey FOREIGN KEY (userrule_ptr_id) REFERENCES rules_userrule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rules_userrule_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rules_userrule
    ADD CONSTRAINT rules_userrule_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_activityentry_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_activityentry
    ADD CONSTRAINT salesopportunities_activityentry_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES users_user(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_activityentry_salesopportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_activityentry
    ADD CONSTRAINT salesopportunities_activityentry_salesopportunity_id_fkey FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_industrytypesavings_industry_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_industrytypesavings
    ADD CONSTRAINT salesopportunities_industrytypesavings_industry_type_id_fkey FOREIGN KEY (industry_type_id) REFERENCES salesopportunities_industrytype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_industrytypeusedistrib_industry_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_industrytypeusedistribution
    ADD CONSTRAINT salesopportunities_industrytypeusedistrib_industry_type_id_fkey FOREIGN KEY (industry_type_id) REFERENCES salesopportunities_industrytype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_salesopportunity_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunity
    ADD CONSTRAINT salesopportunities_salesopportunity_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES users_user(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_salesopportunity_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunity
    ADD CONSTRAINT salesopportunities_salesopportunity_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_salesopportunity_floorplan_floorplan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunity_floorplans
    ADD CONSTRAINT salesopportunities_salesopportunity_floorplan_floorplan_id_fkey FOREIGN KEY (floorplan_id) REFERENCES installations_floorplan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_salesopportunity_industry_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunity
    ADD CONSTRAINT salesopportunities_salesopportunity_industry_type_id_fkey FOREIGN KEY (industry_type_id) REFERENCES salesopportunities_industrytype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_salesopportunity_sales_officer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunity
    ADD CONSTRAINT salesopportunities_salesopportunity_sales_officer_id_fkey FOREIGN KEY (sales_officer_id) REFERENCES users_user(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_salesopportunity_sizing_officer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunity
    ADD CONSTRAINT salesopportunities_salesopportunity_sizing_officer_id_fkey FOREIGN KEY (sizing_officer_id) REFERENCES users_user(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_salesopportunitysa_sales_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunitysavings
    ADD CONSTRAINT salesopportunities_salesopportunitysa_sales_opportunity_id_fkey FOREIGN KEY (sales_opportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_salesopportunityus_sales_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunityusedistribution
    ADD CONSTRAINT salesopportunities_salesopportunityus_sales_opportunity_id_fkey FOREIGN KEY (sales_opportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_surveyinstruction_sales_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_surveyinstruction
    ADD CONSTRAINT salesopportunities_surveyinstruction_sales_opportunity_id_fkey FOREIGN KEY (sales_opportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_task_assigned_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_task
    ADD CONSTRAINT salesopportunities_task_assigned_id_fkey FOREIGN KEY (assigned_id) REFERENCES users_user(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunities_task_sales_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_task
    ADD CONSTRAINT salesopportunities_task_sales_opportunity_id_fkey FOREIGN KEY (sales_opportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: salesopportunity_id_refs_id_b057c298; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY salesopportunities_salesopportunity_floorplans
    ADD CONSTRAINT salesopportunity_id_refs_id_b057c298 FOREIGN KEY (salesopportunity_id) REFERENCES salesopportunities_salesopportunity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_252df082; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dataneeds_dataneed
    ADD CONSTRAINT subclass_id_refs_id_252df082 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_36bbd919; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_production
    ADD CONSTRAINT subclass_id_refs_id_36bbd919 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_3e55e98c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY productions_period
    ADD CONSTRAINT subclass_id_refs_id_3e55e98c FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_43653351; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY manage_collections_item
    ADD CONSTRAINT subclass_id_refs_id_43653351 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_458bbaae; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tariffs_period
    ADD CONSTRAINT subclass_id_refs_id_458bbaae FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_48fcc896; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY co2conversions_co2conversion
    ADD CONSTRAINT subclass_id_refs_id_48fcc896 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_515845a1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_period
    ADD CONSTRAINT subclass_id_refs_id_515845a1 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_5d4fffa0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cost_compensations_period
    ADD CONSTRAINT subclass_id_refs_id_5d4fffa0 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_8730fac0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_nonaccumulationdatasequence
    ADD CONSTRAINT subclass_id_refs_id_8730fac0 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_8dfae410; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tariffs_tariff
    ADD CONSTRAINT subclass_id_refs_id_8dfae410 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_9af44991; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasources_datasource
    ADD CONSTRAINT subclass_id_refs_id_9af44991 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_c451520d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_collection
    ADD CONSTRAINT subclass_id_refs_id_c451520d FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_cde24dc2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_productinstallation
    ADD CONSTRAINT subclass_id_refs_id_cde24dc2 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_d9ec15d7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_consumption
    ADD CONSTRAINT subclass_id_refs_id_d9ec15d7 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_e384db2e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cost_compensations_costcompensation
    ADD CONSTRAINT subclass_id_refs_id_e384db2e FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_eaa70ec4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_energyperformance
    ADD CONSTRAINT subclass_id_refs_id_eaa70ec4 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_f3a019e1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY measurementpoints_dataseries
    ADD CONSTRAINT subclass_id_refs_id_f3a019e1 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subclass_id_refs_id_fc54e199; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY datasequences_energypervolumedatasequence
    ADD CONSTRAINT subclass_id_refs_id_fc54e199 FOREIGN KEY (subclass_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplier_id_refs_id_afb6d5cc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_historicalproduct
    ADD CONSTRAINT supplier_id_refs_id_afb6d5cc FOREIGN KEY (supplier_id) REFERENCES suppliers_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: supplier_id_refs_id_d355c514; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY products_product
    ADD CONSTRAINT supplier_id_refs_id_d355c514 FOREIGN KEY (supplier_id) REFERENCES suppliers_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: suppliers_supplier_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY suppliers_supplier
    ADD CONSTRAINT suppliers_supplier_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES providers_provider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: system_health_site_healthreport_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY system_health_site_healthreport
    ADD CONSTRAINT system_health_site_healthreport_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tariff_id_refs_id_b89a61de; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY consumptions_mainconsumption
    ADD CONSTRAINT tariff_id_refs_id_b89a61de FOREIGN KEY (tariff_id) REFERENCES tariffs_tariff(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tariffs_energytariff_tariff_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tariffs_energytariff
    ADD CONSTRAINT tariffs_energytariff_tariff_ptr_id_fkey FOREIGN KEY (tariff_ptr_id) REFERENCES tariffs_tariff(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tariffs_fixedpriceperiod_period_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tariffs_fixedpriceperiod
    ADD CONSTRAINT tariffs_fixedpriceperiod_period_ptr_id_fkey FOREIGN KEY (period_ptr_id) REFERENCES tariffs_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tariffs_period_datasequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tariffs_period
    ADD CONSTRAINT tariffs_period_datasequence_id_fkey FOREIGN KEY (datasequence_id) REFERENCES tariffs_tariff(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tariffs_spotpriceperiod_period_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tariffs_spotpriceperiod
    ADD CONSTRAINT tariffs_spotpriceperiod_period_ptr_id_fkey FOREIGN KEY (period_ptr_id) REFERENCES tariffs_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tariffs_spotpriceperiod_spotprice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tariffs_spotpriceperiod
    ADD CONSTRAINT tariffs_spotpriceperiod_spotprice_id_fkey FOREIGN KEY (spotprice_id) REFERENCES datasources_datasource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tariffs_tariff_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tariffs_tariff
    ADD CONSTRAINT tariffs_tariff_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tariffs_volumetariff_tariff_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tariffs_volumetariff
    ADD CONSTRAINT tariffs_volumetariff_tariff_ptr_id_fkey FOREIGN KEY (tariff_ptr_id) REFERENCES tariffs_tariff(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: timeenergyperformance_id_refs_energyperformance_ptr_id_4c0c0b40; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY energyperformances_timeenergyperformance_consumptiongroups
    ADD CONSTRAINT timeenergyperformance_id_refs_energyperformance_ptr_id_4c0c0b40 FOREIGN KEY (timeenergyperformance_id) REFERENCES energyperformances_timeenergyperformance(energyperformance_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: token_auth_tokendata_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY token_auth_tokendata
    ADD CONSTRAINT token_auth_tokendata_user_id_fkey FOREIGN KEY (user_id) REFERENCES users_user(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tripleinputmeterinstallation_id_refs_productinstallation_pt03ca; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input2_satisfies1aad
    ADD CONSTRAINT tripleinputmeterinstallation_id_refs_productinstallation_pt03ca FOREIGN KEY (tripleinputmeterinstallation_id) REFERENCES installations_tripleinputmeterinstallation(productinstallation_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tripleinputmeterinstallation_id_refs_productinstallation_pt99e5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input1_satisfies0539
    ADD CONSTRAINT tripleinputmeterinstallation_id_refs_productinstallation_pt99e5 FOREIGN KEY (tripleinputmeterinstallation_id) REFERENCES installations_tripleinputmeterinstallation(productinstallation_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tripleinputmeterinstallation_id_refs_productinstallation_ptefc7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY installations_tripleinputmeterinstallation_input3_satisfies9eaa
    ADD CONSTRAINT tripleinputmeterinstallation_id_refs_productinstallation_ptefc7 FOREIGN KEY (tripleinputmeterinstallation_id) REFERENCES installations_tripleinputmeterinstallation(productinstallation_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_40c41112; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT user_id_refs_id_40c41112 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_4dc23c39; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_4dc23c39 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_7022b859; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY encryption_encryptionkey
    ADD CONSTRAINT user_id_refs_id_7022b859 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_ptr_id_refs_id_5d020fd9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users_user
    ADD CONSTRAINT user_ptr_id_refs_id_5d020fd9 FOREIGN KEY (user_ptr_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: userprofile_id_refs_id_730c079b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_userprofile_collections
    ADD CONSTRAINT userprofile_id_refs_id_730c079b FOREIGN KEY (userprofile_id) REFERENCES customers_userprofile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: water_tariff_id_refs_id_a3d5f060; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customers_customer
    ADD CONSTRAINT water_tariff_id_refs_id_a3d5f060 FOREIGN KEY (water_tariff_id) REFERENCES measurementpoints_dataseries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

